
let DATA=null,SUBJ=null,LIVE=null;const FORCE=new Set();
const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const store={get(k){try{return localStorage.getItem(k)}catch(e){return null}},set(k,v){try{localStorage.setItem(k,v)}catch(e){}}};
let KEY='',byId=new Map();
let filtered=[],order=[],current=0,selected=null,shuffled=false,submitted=false,elapsed=0,timer=null,mode='practice',retryIds=null,search='',fontScale=+(store.get('pq-font')||1)||1;
let paused=false;
const answers=new Map(),flags=new Set(),spent=new Map();
const examFilter=$('examFilter'),groupFilter=$('groupFilter'),yearFilter=$('yearFilter'),viewFilter=$('viewFilter'),card=$('questionCard'),navList=$('navList');


const stateFor=q=>answers.get(q.id)||null,currentQ=()=>order[current]||null,revealed=a=>!!a&&a.grade!=='pending';
/* reflow: PDF-extracted text has hard line breaks every ~60 chars. Join them so text fills the width,
   but keep numbered/lettered items, table rows and real paragraph ends on their own lines. */
const WORDS=new Set();
function buildWords(){WORDS.clear();if(!SUBJ.reflow)return;const re=/[a-z]{3,}/g;for(const q of DATA.questions){for(const s of [q.prompt,q.explanation,...q.options.map(o=>o.text)]){if(!s)continue;const t=s.toLowerCase();let m;re.lastIndex=0;while((m=re.exec(t)))WORDS.add(m[0]);}}}
const START=/^\s*(\d{1,2}\s*[.)]|\(?[a-zA-Z]{1,3}\)\s|\(?[ivxIVX]{1,4}[.)]\s|[A-Da-d][.)]\s|[-•●▪*–]\s|(Statement|Assertion|Reason|Codes?|Select|Choose|Consider|Which of|Match|List)\b)/;
const tabbed=s=>/\t/.test(s.replace(/^[^\t]{1,24}(\t\s*:?\s*)+/,''));
function reflow(t){
 if(!t||t.indexOf('\n')<0)return t||'';
 const L=t.split('\n');let max=0;for(const l of L)if(l.length>max)max=l.length;
 let out='',prev='',brk=false,rigid=false;
 for(const raw of L){
  const s=raw.trim();
  if(!s){brk=true;continue;}
  let sep=' ';
  if(!out)sep='';
  else if(brk)sep='\n\n';
  else{
   const table=tabbed(s);
   const short=prev.length<max*.7&&/[.?!:;)”"]$/.test(prev);
   if(rigid||table||START.test(raw)||(short&&/^[A-Z“"‘'(]/.test(s)))sep='\n';
   else if(/[A-Za-z]-$/.test(prev)&&/^[a-z]/.test(s)){
    const a=(prev.match(/([A-Za-z]+)-$/)||[])[1]||'',b=(s.match(/^[a-z]+/)||[''])[0];
    if(a&&b&&WORDS.has((a+b).toLowerCase()))out=out.slice(0,-1);
    sep='';
   }
  }
  rigid=tabbed(s);
  out+=sep+s;prev=s;brk=false;
 }
 return out;
}

const keyStr=q=>q.correct.map(x=>x.toUpperCase()).join(', ');
const selKeys=a=>!a?[]:a.sel||(a.selected?[a.selected]:[]),isMulti=q=>q.correct.length>1&&q.gradeable;
function gradeOf(q,a){if(!q.gradeable)return'ungraded';const L=new Set((typeof a==='string'?[a]:selKeys(a)).map(k=>(q.options.find(o=>o.key===k)||{}).sourceLabel));return L.size===q.correct.length&&q.correct.every(c=>L.has(c))?'correct':'wrong';}
function hay(q){return q._h||(q._h=(q.prompt+' '+q.options.map(o=>o.text).join(' ')+' '+(q.explanation||'')+' '+q.chapter).toLowerCase());}
function matchQ(q){
 if(retryIds)return retryIds.has(q.id);return setupMatch(q);
}
function setupMatch(q,ignoreChapter=false){
 const ex=examFilter.value,v=viewFilter.value,gp=groupFilter.value,yr=yearFilter.value,a=answers.get(q.id);
 if(!ignoreChapter&&chosenChapters.size&&!chosenChapters.has(q.chapterNo))return false;if(gp!=='all'&&q.group!==gp)return false;
 if((ex!=='all'||yr!=='all')&&!q.examTags.some(t=>(ex==='all'||(t.family||t.label)===ex)&&(yr==='all'||yrsOf(t).includes(+yr))))return false;
 if(v==='unattempted'&&a)return false;if(v==='incorrect'&&!(a&&a.grade==='wrong'))return false;if(v==='flagged'&&!flags.has(q.id))return false;
 if(v==='due'||v==='everwrong'||v==='weak'||v==='new'||v==='noted'){const s=QS[progressStorageKey(q.id)];if(v==='due'&&!(s&&s.d<=Date.now()))return false;if(v==='everwrong'&&!(s&&s.w))return false;if(v==='weak'&&!(s&&s.a&&s.c/s.a<.6))return false;if(v==='new'&&s)return false;if(v==='noted'&&!NOTES[q.id])return false;}
 return !search||hay(q).includes(search);
}
function applyFilters(){filtered=DATA.questions.filter(matchQ);order=[...filtered];shuffled=false;current=0;selected=null;render();}
const userFilter=()=>{retryIds=null;applyFilters();};

/* persistence */
let _st;function save(){clearTimeout(_st);_st=setTimeout(saveNow,400);}
function saveNow(){clearTimeout(_st);if(!KEY)return;store.set(KEY,JSON.stringify({a:[...answers],f:[],t:[...spent],e:elapsed,s:submitted,m:mode,c:currentQ()?.id,x:sess}));}
function toast(m){const t=$('toast');t.textContent=m;t.hidden=false;clearTimeout(toast.h);toast.h=setTimeout(()=>t.hidden=true,4200);}
function restore(){
 const raw=store.get(KEY);if(!raw)return null;
 try{const s=JSON.parse(raw);if(!QM.user&&!s?.s)return null;if(s?.x?.account&&s.x.account!==QM.user?.id)return null;if(!s||!s.a||!s.a.length&&!s.e&&!s.x?.mock)return null;
  s.a.forEach(([id,a])=>{if(byId.has(id))answers.set(id,a)});(s.t||[]).forEach(([id,n])=>byId.has(id)&&spent.set(id,n));
  elapsed=s.e||0;sess=s.x||{};submitted=!!s.s;mode=s.m==='exam'?'exam':'practice';return s;}catch(e){return null;}
}

/* render */
function testRunning(){return !!(L()||(!submitted&&(sess.mock||sess.id||retryIds)));}
let leavingPage=false;
function warnUnload(e){if(!leavingPage&&testRunning()){e.preventDefault();e.returnValue='';}}
function syncExitGuard(){
 if(testRunning()){
  addEventListener('beforeunload',warnUnload);
  if(!history.state?.testGuard)history.pushState({testGuard:true},'');
 }else removeEventListener('beforeunload',warnUnload);
}
addEventListener('popstate',()=>{
 if(history.state?.testGuard||!testRunning()||leavingPage)return;
 if(!confirm('A test is running. Leave this test and go back?')){history.pushState({testGuard:true},'');return;}
 leavingPage=true;
 if(document.referrer||history.length>2)history.back();else location.assign('index.html');
});
addEventListener('pageshow',()=>{leavingPage=false;});
document.querySelector('a[aria-label="Home"]').addEventListener('click',e=>{
 if(!testRunning()||e.metaKey||e.ctrlKey||e.shiftKey)return;
 if(!confirm('A test is running. Leave this test and go home?'))e.preventDefault();
 else{logSession('in-progress');saveNow();flushPersist();leavingPage=true;setTimeout(()=>{leavingPage=false;},1000);}
});
function render(){
 const active=!submitted&&!!(retryIds||sess.mock||sess.id||L());
 const stage=active?'active':submitted?'review':'setup';
 document.body.dataset.stage=stage;
 for(const id of ['fbar','chapterShelf','studyTools'])$(id).hidden=stage!=='setup';
 $('shell').hidden=stage==='setup';
 const page=active||submitted?'test.html':'builder.html';
 const url=new URL(location.href);
 if(!url.pathname.endsWith('/'+page)){
  const fromBuilder=url.pathname.endsWith('/builder.html');
  url.pathname=url.pathname.replace(/[^/]+$/,page);
  if(active&&fromBuilder&&!history.state?.testGuard)history.pushState({testGuard:true},'',url);
  else history.replaceState(history.state,'',url);
 }
 syncExitGuard();
 $('backChapters').hidden=!submitted;
 $('backChapters').href='builder.html?s='+encodeURIComponent(SUBJ.id);
 $('testSubmit').textContent=submitted?'Summary':L()&&!L().host?'Exit test':'End test';
 if(!active&&!submitted)drawChapterShelf();
 $('examAnalysis').hidden=false;
 $('examAnalysis').href='analysis.html?s='+encodeURIComponent(SUBJ.id)+(examFilter.value==='all'?'':'&exam='+encodeURIComponent(examFilter.value));
 $('chSummary').textContent=chosenChapters.size?chosenChapters.size+' selected':'All chapters';
 if(!active&&DATA){
  const pool=DATA.questions.filter(q=>setupMatch(q)&&q.attemptable&&q.gradeable&&q.options.length);
  $('poolCount').textContent=pool.length+' eligible questions across '+new Set(pool.map(q=>q.chapterNo)).size+' chapters';
  const count=[groupFilter.value!=='all',viewFilter.value!=='all',!!search].filter(Boolean).length;
  $('moreCount').textContent=count?'('+count+')':'';
 }

 const q=currentQ();
 $('filterSummary').textContent=retryIds?(sess.mock?`${sess.live?'Live room':'Custom session'} · ${order.length} questions`:`Retrying ${order.length} missed questions`):`${order.length} of ${DATA.questions.length} questions in view`;
 $('positionPill').textContent=order.length?`Question ${current+1} / ${order.length}`:'No questions';
 $('navSummary').textContent=`${order.length} questions · ${answers.size} attempted`;
 document.querySelectorAll('#modeSeg button').forEach(b=>b.classList.toggle('on',b.dataset.mode===mode));
 renderNavigator();updateScore();syncBar(q);save();
 if(!q){card.innerHTML='<div class="empty"><h3>No questions match this view</h3><p>Change the exam, chapter, review set or search text.</p></div>';return;}
 const saved=stateFor(q)||(FORCE.has(q.id)?{grade:'timeout',sel:[],selected:null}:null),rev=revealed(saved);selected=saved?saved.selected:null;
 const mixed=mixedTest();
 $('brandSub').hidden=mixed;$('sourceNote').hidden=mixed;
 const tags=(!mixed&&q.group&&DATA.groups&&DATA.groups.length?`<span class="tag">${esc(q.group)}</span>`:'')+(q.examTags.length?q.examTags.map(t=>`<span class="tag exam">${esc(t.label)}</span>`).join(''):(SUBJ.builtin?'<span class="tag">Exam tag not recovered</span>':''));
 const mt=q.prompt?parseMatch(q.prompt):null,prompt=(q.prompt?(mt?matchHTML(mt):`<p class="prompt">${esc(rf(q.prompt))}</p>`):'')+(q.images||[]).map(u=>`<img class="qimg" src="${esc(u)}" loading="lazy" decoding="async" alt="Question figure">`).join('');
 let options;
 if(q.options.length){options='<div class="options" role="group" aria-label="Answer options">'+q.options.map(o=>{
  let cls='opt',mark='';
  if(rev){if(q.gradeable&&q.correct.includes(o.sourceLabel)){cls+=' correct';mark='✓'}else if(selKeys(saved).includes(o.key)&&q.gradeable){cls+=' wrong';mark='✗'}else if(selKeys(saved).includes(o.key))cls+=' selected';}
  else if(selKeys(saved).includes(o.key))cls+=' selected';
  return `<button class="${cls}" type="button" data-option="${esc(o.key)}" ${rev||submitted?'disabled':''}><span class="letter">${esc(o.sourceLabel.toUpperCase())}</span><span>${(mt&&optMatch(o.text,mt))?'<span class="mo">'+optMatch(o.text,mt)+'</span>':(esc(rf(o.text))||(o.image?'':'<em>[Option text not recovered]</em>'))}${o.image?`<img class="oimg" src="${esc(o.image)}" loading="lazy" decoding="async" alt="Option ${esc(o.sourceLabel)}">`:''}</span>${mark?`<span class="mark">${mark}</span>`:''}</button>`;}).join('')+'</div>';}
 else options='<div class="note" style="margin:0 0 20px">The source layout did not yield reliable separate options for this item. The extracted prompt is retained for review; it is not scored.</div>';
 const expl=(t,label,fallback)=>(t||fallback)?`<details open><summary>${label}</summary><div class="explain">${QM.studyHTML(rf(t||fallback),esc)}</div></details>`:'';
 let fb='';
 if(rev){
  if(saved.grade==='correct')fb=`<div class="fb good"><div class="fb-head"><span class="fb-ico" data-i="✓"></span><div>Correct<small>Correct option: ${keyStr(q)}</small></div></div>${expl(q.explanation,'Explanation','No separate explanation text was recovered from the source.')}</div>`;
  else if(saved.grade==='wrong')fb=`<div class="fb bad"><div class="fb-head"><span class="fb-ico" data-i="✗"></span><div>Incorrect<small>You chose ${esc(lab(q,selKeys(saved)))} · Correct option: ${keyStr(q)}</small></div></div>${expl(q.explanation,'Explanation')}</div>`;
  else if(saved.grade==='timeout')fb=`<div class="fb neutral"><div class="fb-head"><span class="fb-ico" data-i="⏱"></span><div>Time’s up<small>Correct option: ${keyStr(q)}</small></div></div>${expl(q.explanation,'Explanation','No separate explanation text was recovered from the source.')}</div>`;
  else fb=`<div class="fb neutral"><div class="fb-head"><span class="fb-ico" data-i="!"></span><div>Attempt recorded · no answer key<small>${esc(q.answerRaw||'No printed answer key line')} — the book gives no mappable keyed option, so this cannot be scored.</small></div></div>${expl(q.explanation,'Explanation / source note')}</div>`;
 }
 const exam=mode==='exam';
 const hasAns=!!(saved&&(saved.selected||(saved.sel&&saved.sel.length))),cc=((sess&&sess.confidence)||{})[q.id]||'';
 const confRow=!submitted&&active&&hasAns?`<div class="confRow" role="group" aria-label="Confidence in this answer"><span>How sure?</span>${[['Sure','Sure'],['Unsure','Not sure'],['Guess','Guess']].map(([v,l])=>`<button type="button" class="cpill c-${v.toLowerCase()}" data-conf="${v}" aria-pressed="${cc===v}">${l}</button>`).join('')}</div>`:'';
 const hint=isMulti(q)&&!rev&&!submitted&&q.attemptable?'<span>Multiple answers: select every correct option'+(mode==='practice'?', then press Check':'')+'</span>':submitted?'Test submitted — review only.':!q.attemptable?'This item is retained for source review.':exam?'<span>Exam mode: change your answer any time before you submit</span>':'<span>Tap an option to check it instantly</span><kbd class="kbdhint">A–D</kbd><span class="kbdhint">then</span><kbd class="kbdhint">Enter</kbd><span class="kbdhint">for next</span>';
 const mchk=isMulti(q)&&!rev&&!submitted&&mode==='practice'&&saved&&saved.sel&&saved.sel.length?'<div style="margin:0 28px 4px"><button class="btn primary" id="chkMulti" type="button">Check answer</button></div>':'';
 card.innerHTML=`<div class="qhead"><span class="qn">Q${mixed?current+1:esc(q.number)}</span>${mixed?'':`<span class="qch" title="${esc(q.chapter||'')}">Ch ${String(q.chapterNo).padStart(2,'0')} · ${esc(q.chapter||'')}</span>`}<div class="qacts"><button class="ib ${flags.has(q.id)?'on':''}" id="flagBtn" type="button" title="Bookmark for review (F)" aria-label="Bookmark for review" aria-pressed="${flags.has(q.id)}"><svg viewBox="0 0 24 24" width="18" height="18" fill="${flags.has(q.id)?'currentColor':'none'}" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M6 3h12v18l-6-4-6 4z"/></svg></button><button class="ib rep" id="rptBtn" type="button" title="Report a problem with this question" aria-label="Report a problem"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 21V4"/><path d="M5 4h12l-2 4 2 4H5"/></svg></button></div>${tags?`<div class="tags">${tags}</div>`:''}</div>
 <div class="qbody">${prompt}${options}${confRow}</div>
 <p class="hint">${hint}</p>${mchk}${fb}${rev&&q.revisionNote?`<p class="dnote">Revised ${esc(q.revisionDate)} · ${esc(q.revisionNote)}</p>`:''}${noteBox(q)}`;
 card.querySelectorAll('[data-option]').forEach(b=>b.addEventListener('click',()=>pick(b.dataset.option)));
 $('flagBtn').addEventListener('click',()=>toggleFlag(q));$('rptBtn').addEventListener('click',()=>{$('rptBackdrop').hidden=false;});
  const cm=$('chkMulti');if(cm)cm.addEventListener('click',checkMulti);
 const nt=$('noteTa');if(nt)nt.addEventListener('input',()=>setNote(q.id,nt.value));
}
function syncBar(q){const a=q&&stateFor(q);$('prevBtn').disabled=!q||current===0;$('nextBtn').disabled=!q||current>=order.length-1;$('clearBtn').disabled=!a||submitted;$('nextBtn').classList.toggle('primary',!!q&&(mode==='exam'||revealed(a)));}
function setPaused(p){if(submitted)p=false;paused=p;
 const q=currentQ();
 const canRead=!!(q&&!L()&&(stateFor(q)||FORCE.has(q.id)||soloPhase()?.review));
 document.body.classList.toggle('readPaused',p&&canRead);document.body.classList.toggle('paused',p);const b=$('pauseBtn');b.textContent=p?'▶':'❚❚';b.setAttribute('aria-label',p?'Resume test':'Pause test');b.title=(p?'Resume':'Pause')+' (P)';b.disabled=submitted;if(p)stopClock();else if(!submitted)startClock();}
function pick(key){
 const q=currentQ();if(!q||paused||submitted||!signedIn())return;const a=stateFor(q);if(revealed(a))return;ensureSess();startClock();
 if(isMulti(q)){let s=selKeys(a).slice();s=s.includes(key)?s.filter(x=>x!==key):[...s,key];if(!s.length)answers.delete(q.id);else answers.set(q.id,{selected:s[0],sel:s,grade:'pending'});render();return;}
 if(mode==='exam'){answers.set(q.id,{selected:key,grade:'pending'});render();return;}
 selected=key;check(q);
}
function checkMulti(){if(paused)return;const q=currentQ(),a=q&&stateFor(q);if(!a||submitted)return;const g=gradeOf(q,a);answers.set(q.id,{selected:a.selected,sel:a.sel,grade:g});recordResult(q,g);render();if(g==='wrong'&&!L()&&!((sess&&sess.confidence)||{})[q.id])confPopShow(q);}
function check(q){if(!selected||submitted||mode==='exam')return;const g=gradeOf(q,selected);answers.set(q.id,{selected,grade:g});recordResult(q,g);render();if(g==='wrong'&&!L()&&!((sess&&sess.confidence)||{})[q.id])confPopShow(q);const f=card.querySelector('.fb');if(f)f.scrollIntoView({behavior:'smooth',block:'nearest'});}
const bookmarkWrites=new Map();
async function toggleFlag(q){
 const subject=SUBJ,key=QM.bookmarkKey(subject.id,q.id);
 if(bookmarkWrites.has(key))return;
 const remove=flags.has(q.id);
 const value=remove?{ts:Date.now(),deleted:true}:QM.makeBookmark(subject,q);
 bookmarkWrites.set(key,true);
 try{await QM.kvSet(key,value);
  if(SUBJ===subject){if(remove)flags.delete(q.id);else flags.add(q.id);render();}
 }catch{toast('Bookmark could not be saved. Please try again.');}finally{bookmarkWrites.delete(key);}
}
var confPopT=0,confPopQ=null;
function confPopHide(now){clearTimeout(confPopT);const e=document.getElementById('confPop');confPopQ=null;if(!e)return;if(now){e.remove();return;}e.classList.remove('in');setTimeout(()=>e.remove(),320);}
function confPopShow(q){confPopHide(true);confPopQ=q.id;const e=document.createElement('div');e.id='confPop';e.className='cpop';e.setAttribute('role','group');e.setAttribute('aria-label','How sure were you?');
 e.innerHTML='<button type="button" class="cpill c-guess" data-conf="Guess">Guess</button><button type="button" class="cpill c-unsure" data-conf="Unsure">Not sure</button>';
 document.body.append(e);const b=document.querySelector('.bottom');e.style.bottom=((b?b.offsetHeight:72)+14)+'px';
 requestAnimationFrame(()=>requestAnimationFrame(()=>e.classList.add('in')));confPopT=setTimeout(()=>confPopHide(false),5000);}
document.addEventListener('click',e=>{const b=e.target.closest('[data-conf]');if(!b)return;const pop=!!b.closest('#confPop'),qid=pop?confPopQ:(currentQ()||{}).id;if(!qid||!sess)return;
 const cur=(sess.confidence||{})[qid],nv=(!pop&&cur===b.dataset.conf)?'':b.dataset.conf;(sess.confidence||={})[qid]=nv;save();
 if(pop)confPopHide(false);document.querySelectorAll('.confRow [data-conf]').forEach(x=>x.setAttribute('aria-pressed',String(x.dataset.conf===nv)));});
{const _rc=render;render=function(){const q=currentQ();if(confPopQ&&(!q||q.id!==confPopQ||!stateFor(q)))confPopHide(true);_rc();};}
function go(i){if(i<0||i>=order.length||paused||(L()&&!L().int))return;current=i;selected=null;confPopHide(true);render();scrollTo({top:0,behavior:'smooth'});$('side').classList.remove('open');}
function mixedTest(){return !!(sess.mock||sess.live||retryIds||document.body.dataset.stage==='active'||submitted)&&order.some(q=>q.chapterNo!==order[0].chapterNo);}
let navOrder=null,navMixed=null,navBtns=[];
function navCls(q,i){const a=stateFor(q),st=!a?'':a.grade==='correct'?' done':a.grade==='wrong'?' wrong':a.grade==='ungraded'?' ungraded':' answered';return'navitem'+(i===current?' active':'')+st+(flags.has(q.id)?' flag':'');}
navList.addEventListener('click',e=>{const b=e.target.closest('.navitem');if(b)go(+b.dataset.i);});
function renderNavigator(){
 const mixed=mixedTest();if(navOrder!==order||navMixed!==mixed){navMixed=mixed;navOrder=order;navBtns=[];const fr=document.createDocumentFragment();let prev=null;
  order.forEach((q,i)=>{if(!mixed&&!shuffled&&q.chapterNo!==prev){const g=document.createElement('div');g.className='navgrp';g.textContent=`${String(q.chapterNo).padStart(2,'0')} · ${q.chapter||''}`;fr.append(g);prev=q.chapterNo;}
   const b=document.createElement('button');b.type='button';b.dataset.i=i;b.textContent=mixed?String(i+1):`${q.chapterNo}·${q.number}`;b.title=mixed?`Question ${i+1}`:`Chapter ${q.chapterNo}, question ${q.number}`;navBtns.push(b);fr.append(b);});
  navList.replaceChildren(fr);}
 for(let i=0;i<navBtns.length;i++){const c=navCls(order[i],i);if(navBtns[i].className!==c)navBtns[i].className=c;}
 const a=navBtns[current];if(a){const r=a.getBoundingClientRect(),n=navList.getBoundingClientRect();if(r.top<n.top||r.bottom>n.bottom)navList.scrollTop+=r.top-n.top-n.height/2;}
}
function updateScore(){
 let c=0,w=0,u=0;for(const a of answers.values()){if(a.grade==='correct')c++;else if(a.grade==='wrong')w++;else if(a.grade==='ungraded')u++;}
 const hide=mode==='exam'&&!submitted;
 $('correctCount').textContent=hide?'–':c;$('incorrectCount').textContent=hide?'–':w;$('ungradedCount').textContent=hide?'–':u;$('attemptedCount').textContent=answers.size;
 const g=c+w;$('scorePercent').innerHTML=hide?'Results are revealed on submit':g?`Accuracy <b>${Math.round(c/g*100)}%</b>`:'Not started';
 $('progressBar').style.width=(order.length?Math.min(100,order.filter(q=>answers.has(q.id)).length/order.length*100):0)+'%';
}

/* stopwatch + time per question */
const pad=n=>String(n).padStart(2,'0'),fmt=s=>`${pad(Math.floor(s/3600))}:${pad(Math.floor(s%3600/60))}:${pad(s%60)}`,mmss=s=>`${Math.floor(s/60)}:${pad(s%60)}`;
function drawNext(label,remaining,duration,review,stopped){
 const button=$('nextBtn'),timed=duration>0;
 button.classList.toggle('phase-clock',timed);
 button.classList.toggle('review-clock',timed&&review);
 button.classList.toggle('phase-urgent',timed&&remaining<=10000);
 $('nextTime').hidden=!timed;
 $('nextAction').textContent=label;
 if(timed){
  button.style.setProperty('--remaining',String(Math.max(0,Math.min(1,remaining/duration))));
  $('nextTime').textContent=(stopped?'Paused':review?'Review':'Answer')+' '+mmss(Math.ceil(Math.max(0,remaining)/1000));
 }
 button.setAttribute('aria-label',timed?label+' · '+$('nextTime').textContent:'Next question');
}
function soloPhase(){
 const q=currentQ();
 if(!q||!sess.qsec||sess.live||submitted||mode!=='practice')return null;
 const review=revealed(stateFor(q))||FORCE.has(q.id);
 let phase=sess.practiceClock;
 if(!phase||phase.id!==q.id||(!phase.review&&review)){
  phase=sess.practiceClock={id:q.id,review,start:elapsed};
 }
 return phase;
}
function paint(){
 const H=L(),started=document.body.dataset.stage==='active'&&(!H||!!H.cfg?.ids&&H.ph!=='lobby');
 $('timerBox').hidden=!started;
 const liveMs=H?(H.watchMs||0)+(H.watchAnchor&&!H.pz?Date.now()-H.watchAnchor:0):0;
 $('stopwatch').textContent=fmt(H?Math.floor(Math.max(0,liveMs)/1000):Math.max(0,elapsed-(sess.eb||0)));
 if(started&&H&&H.cfg?.mode==='practice'&&['live','reveal'].includes(H.ph)){
  const review=H.ph==='reveal';
  drawNext(H.host?(review?'Next →':'Reveal →'):'Next →',H.pz?H.pr:H.end-Date.now(),1000*(review?REV:H.cfg.qsec),review,H.pz);
 }else if(started&&!H&&soloPhase()){
  const phase=sess.practiceClock,seconds=phase.review?REV:sess.qsec;
  drawNext(current===order.length-1?'Finish':'Next →',1000*(seconds-elapsed+phase.start),1000*seconds,phase.review,paused);
  $('nextBtn').disabled=paused;
 }else drawNext('Next →',0,0,false,false);
}
function advanceSoloClock(){
 const phase=!LIVE&&soloPhase();
 if(!phase||paused||elapsed-phase.start<(phase.review?REV:sess.qsec))return;
 if(!phase.review){
  FORCE.add(phase.id);
  const answer=stateFor(currentQ());
  if(answer?.grade==='pending')checkMulti();
  phase.review=true;phase.start=elapsed;render();
 }else if(current<order.length-1)go(current+1);
 else autoSubmit();
}
function startClock(){if(timer!==null||submitted)return;if(!sess.id){$('timerBox').classList.add('stopped');return;}$('timerBox').classList.remove('stopped');timer=setInterval(()=>{elapsed++;advanceSoloClock();if(submitted)return;const q=currentQ();if(q&&!revealed(stateFor(q)))spent.set(q.id,(spent.get(q.id)||0)+1);paint();if(sess.lim&&!submitted&&elapsed-(sess.eb||0)>=sess.lim){autoSubmit();return;}if(elapsed%5===0)save();},1000);}
function stopClock(){if(timer!==null){clearInterval(timer);timer=null;}$('timerBox').classList.add('stopped');save();}

/* in-page confirm (browser confirm() is blocked in many viewers) */
function ask(title,msg,ok){return new Promise(res=>{$('cTitle').textContent=title;$('cMsg').textContent=msg;$('cOk').textContent=ok;const b=$('confirmBackdrop');b.hidden=false;$('cOk').focus();
 const done=v=>{b.hidden=true;$('cOk').onclick=$('cNo').onclick=null;res(v)};$('cOk').onclick=()=>done(true);$('cNo').onclick=()=>done(false);});}

/* summary */
/* summary: see paintSummary below */

/* actions */
$('backChapters').onclick=e=>{
 if(!submitted||e.ctrlKey||e.metaKey||e.shiftKey)return;
 e.preventDefault();flushPersist();delete $('sectionRail').dataset.subject;resetAll();FORCE.clear();saveNow();
};
function resetAll(){if(LIVE)liveLeave();logSession(submitted?'submitted':'ended');stopClock();sess={};answers.clear();spent.clear();submitted=false;paused=false;document.body.classList.remove('paused');elapsed=0;paint();retryIds=null;$('testSubmit').textContent='Submit';$('summaryBackdrop').hidden=true;applyFilters();setPaused(false);startClock();}
async function setMode(m){if(m===mode)return;if(answers.size&&!await ask('Switch to '+(m==='exam'?'exam':'practice')+' mode?','Your current answers, flags and timer will be cleared so the new mode starts clean.','Switch and reset'))return;logSession(submitted?'submitted':'ended');sess={};mode=m;resetAll();toast(m==='exam'?'Exam mode: results appear after you submit.':'Practice mode: check each answer as you go.');}
$('modeSeg').addEventListener('click',e=>{const b=e.target.closest('[data-mode]');if(b)setMode(b.dataset.mode);});
$('testSubmit').addEventListener('click',async()=>{
 if(submitted){showSummary();return;}
 const room=L();
 if(room){
  const host=room.host;
  if(!await ask(host?'End this test for everyone?':'Exit this test?',host?'Everyone will see the results with the answers received so far.':'Your attempt will be saved. The other members can continue.',host?'End test':'Exit test')||L()!==room)return;
  if(host)finish();else{gradePending();liveLeave();}
  return;
 }
 const left=order.filter(q=>!answers.has(q.id)).length;
 if(!await ask('End this test?',`${left} of ${order.length} questions are unanswered. The stopwatch will stop and your answers will be saved for review.`,'End test'))return;
 gradePending();
 submitted=true;setPaused(false);stopClock();logSession('submitted');$('testSubmit').textContent='Summary';render();showSummary();
});
$('resetTest').addEventListener('click',async()=>{if(await ask('Reset the test?','All answers, flags and the stopwatch will be cleared.','Reset'))resetAll();});
$('retryBtn').addEventListener('click',()=>{
 if(!signedIn())return;
 if(summaryCtx.rec){retryFromRec(summaryCtx.rec);return;}
 const ids=new Set(order.filter(q=>answers.get(q.id)?.grade==='wrong').map(q=>q.id));if(!ids.size)return;
 ids.forEach(id=>answers.delete(id));sess={eb:elapsed};retryIds=ids;submitted=false;$('testSubmit').textContent='Submit';$('summaryBackdrop').hidden=true;applyFilters();setPaused(false);startClock();
 toast(`Retrying ${ids.size} missed questions. Change any filter to leave this set.`);
});
$('prevBtn').addEventListener('click',()=>go(current-1));$('nextBtn').addEventListener('click',()=>{if(!LIVE&&soloPhase()&&current===order.length-1)$('testSubmit').click();else go(current+1);});
$('clearBtn').addEventListener('click',()=>{const q=currentQ();if(q&&!submitted&&!paused){answers.delete(q.id);render();}});
$('pauseBtn').addEventListener('click',()=>setPaused(!paused));$('resumeBtn').addEventListener('click',()=>setPaused(false));
$('closeSummary').addEventListener('click',()=>$('summaryBackdrop').hidden=true);
$('summaryBackdrop').addEventListener('click',e=>{if(e.target===$('summaryBackdrop'))$('summaryBackdrop').hidden=true;});
examFilter.addEventListener('change',userFilter);viewFilter.addEventListener('change',userFilter);
let sh;$('searchBox').addEventListener('input',e=>{clearTimeout(sh);sh=setTimeout(()=>{search=e.target.value.trim().toLowerCase();userFilter();},220);});
$('shuffleBtn').addEventListener('click',()=>{order=[...filtered];for(let i=order.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[order[i],order[j]]=[order[j],order[i]];}shuffled=true;current=0;selected=null;render();});
function setNavC(c){$('navigator').classList.toggle('collapsed',c);const b=$('navCollapse');b.textContent=c?'‹':'›';b.setAttribute('aria-expanded',String(!c));b.setAttribute('aria-label',c?'Expand navigator':'Collapse navigator');b.title=(c?'Expand':'Collapse')+' (N)';store.set('pq-navc',c?'1':'0');roomLayout();}
function setRoomC(c){$('roomBox').classList.toggle('collapsed',c);const b=$('roomCollapse');b.textContent=c?'‹':'›';b.setAttribute('aria-expanded',String(!c));b.setAttribute('aria-label',c?'Expand room box':'Collapse room box');store.set('pq-roomc',c?'1':'0');roomLayout();}
function roomLayout(){const box=$('roomBox'),has=!box.hidden;$('side').classList.toggle('hasroom',has);
 $('shell').classList.toggle('navc',$('navigator').classList.contains('collapsed')&&(!has||box.classList.contains('collapsed')));
 const rt=$('roomToggle');rt.hidden=!has;if(!has&&$('side').dataset.open==='room')$('side').classList.remove('open');}
function sideOpen(w){const s=$('side'),was=s.classList.contains('open')&&s.dataset.open===w;s.classList.remove('open');if(!was){s.dataset.open=w;s.style.top=($('dock').getBoundingClientRect().bottom+6)+'px';s.classList.add('open');}
 $('navToggle').setAttribute('aria-expanded',String(!was&&w==='nav'));$('roomToggle').setAttribute('aria-expanded',String(!was&&w==='room'));}
$('navCollapse').addEventListener('click',()=>setNavC(!$('navigator').classList.contains('collapsed')));
$('roomCollapse').addEventListener('click',()=>setRoomC(!$('roomBox').classList.contains('collapsed')));
document.addEventListener('click',e=>{const s=$('side');if(s.classList.contains('open')&&!e.target.closest('#side,#dock'))s.classList.remove('open');});
$('navToggle').addEventListener('click',()=>sideOpen('nav'));$('roomToggle').addEventListener('click',()=>sideOpen('room'));
function applyFont(){document.documentElement.style.setProperty('--scale',fontScale.toFixed(2));store.set('pq-font',fontScale);}
function setTheme(d){document.body.classList.toggle('dark',d);$('themeBtn').textContent=d?'☀':'☾';store.set('pq-theme',d?'dark':'light');}
$('fontDown').addEventListener('click',()=>{fontScale=Math.max(.8,+(fontScale-.1).toFixed(2));applyFont();});
$('fontUp').addEventListener('click',()=>{fontScale=Math.min(1.6,+(fontScale+.1).toFixed(2));applyFont();});
$('themeBtn').addEventListener('click',()=>setTheme(!document.body.classList.contains('dark')));
document.addEventListener('keydown',e=>{
 if(document.querySelector('dialog[open]'))return;
 if(!$('confirmBackdrop').hidden){if(e.key==='Escape')$('cNo').click();return;}
 const layer=topPortalDialog();
 if(layer){
  if(e.key==='Escape'){const close={summaryBackdrop:'closeSummary',subjBackdrop:'closeSubj',mockBackdrop:'mkCancel',rptBackdrop:'rptCancel'}[layer.id];if(close)$(close).click();}
  return;
 }
 if(e.key==='Escape'){$('summaryBackdrop').hidden=true;$('subjBackdrop').hidden=true;$('mockBackdrop').hidden=true;$('side').classList.remove('open');return;}
 if(document.body.dataset.stage==='setup'||$('routeDialog').open)return;
 if(e.ctrlKey||e.metaKey||e.altKey||!$('summaryBackdrop').hidden||!$('subjBackdrop').hidden||tab!=='quiz'||!$('mockBackdrop').hidden||/SELECT|INPUT|TEXTAREA/.test(document.activeElement.tagName))return;
 const q=currentQ();if(!q)return;const k=e.key.toLowerCase();
 if(k==='p'){setPaused(!paused);return;}if(paused)return;
 if(k==='arrowright')go(current+1);else if(k==='arrowleft')go(current-1);else if(k==='f')toggleFlag(q);else if(k==='n')setNavC(!$('navigator').classList.contains('collapsed'));
 else if(k==='enter'){if(document.activeElement.tagName==='BUTTON')return;if(mode==='practice'&&!stateFor(q))return;go(current+1);}
 else if(k.length===1){const i='1234'.includes(k)?+k-1:'abcd'.indexOf(k);if(i>=0&&i<q.options.length)pick(q.options[i].key);}
});

/* ===== My PYQ Online additions: subjects · local storage · sessions · performance · import ===== */
const LS_LAST='qm-last',SUBJECTS=[];
let SESS=[],sess={},tab='quiz',pendingSubj=null;
const POLITY_SRC=$('sourceNote').innerHTML;
const fmtDate=t=>new Date(t).toLocaleString([],{day:'numeric',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'});
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,6);
const fixLig=t=>String(t||'').replace(/\b(fi|fl) (?=[a-z]{2})/g,'$1');
const rfs=(s,t)=>QM.readingText(s?.reflow?fixLig(reflow(t||'')):t);
const rf=t=>rfs(SUBJ,t);
const yrsOf=t=>t.years||(t.year?[t.year]:[]);
const fillSel=(sel,all,opts)=>{sel.innerHTML='';sel.append(new Option(all,'all'));opts.forEach(([v,t])=>sel.append(new Option(t,v)));};
const slug=s=>s.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')||'subject';
function dl(name,text){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type:'application/json'}));a.download=name;document.body.append(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove();},800);}

/* durable storage: IndexedDB (large data) with localStorage fallback */
const kv={db:null,
 open(){return this.db?Promise.resolve(this.db):new Promise(r=>{try{const q=indexedDB.open('quizmaster',1);q.onupgradeneeded=()=>q.result.createObjectStore('kv');q.onsuccess=()=>{const d=this.db=q.result;d.onclose=d.onversionchange=()=>{try{d.close()}catch(e){}this.db=null};r(d)};q.onerror=()=>r(null);}catch(e){r(null)}})},
 async run(m,fn,again){const d=await this.open();if(!d)return{ok:false};return new Promise(r=>{try{const t=d.transaction('kv',m),q=fn(t.objectStore('kv'));t.oncomplete=()=>r({ok:true,v:q&&q.result});t.onerror=t.onabort=()=>r({ok:false});}catch(e){this.db=null;r(again?{ok:false}:this.run(m,fn,1))}})},
 async get(k){const v=await QM.readStore(s=>s.get(k));if(v!==undefined)return v;try{return JSON.parse(localStorage.getItem('qmkv:'+k)||'null')}catch{return null}},
 async set(k,v){const r=await this.run('readwrite',s=>s.put(v,k));if(!r.ok)store.set('qmkv:'+k,JSON.stringify(v));return r.ok},
 async del(k){const r=await this.run('readwrite',s=>s.delete(k));if(!r.ok)try{localStorage.removeItem('qmkv:'+k)}catch(e){}},
 async keys(p){const keys=await QM.readStore(s=>s.getAllKeys());if(keys)return keys.filter(k=>k.startsWith(p));try{return Object.keys(localStorage).filter(k=>k.startsWith('qmkv:'+p)).map(k=>k.slice(5))}catch(e){return[]}}};

/* filters */
function rememberShelf(){
 if(!SUBJ||document.body.dataset.stage!=='setup')return;
 try{sessionStorage.setItem('shelf:'+SUBJ.id,JSON.stringify({query:$('chapterQuery').value,status:$('chapterStatus').value,section:shelfSection,x:$('sectionRail').scrollLeft,y:window.scrollY,returning:true}));}catch{}
}
document.addEventListener('click',e=>{if(e.target.closest('#chapterList button,#startPortal,[data-study],#examAnalysis'))rememberShelf();},true);
addEventListener('pagehide',rememberShelf);
const chosenChapters=new Set();
let shelfSection=null;
$('sectionRail').onclick=e=>{
 const button=e.target.closest('button');if(!button)return;
 shelfSection=button.hasAttribute('data-all')?null:button.dataset.group;
 drawChapterShelf();
};
function fillChapters(){
 const visible=DATA.chapters.filter(c=>groupFilter.value==='all'||c.group===groupFilter.value);
 const allowed=new Set(visible.map(c=>c.no));
 for(const n of chosenChapters)if(!allowed.has(n))chosenChapters.delete(n);
 $('mkChs').innerHTML=visible.map(c=>`<label class="chk"><input type="checkbox" value="${c.no}" ${chosenChapters.has(c.no)?'checked':''}><span>${esc(c.title)}</span></label>`).join('');
}
$('chapterQuery').oninput=$('chapterStatus').onchange=drawChapterShelf;
function drawChapterShelf(){
 if(!DATA)return;
 const groups=[...new Set(DATA.chapters.map(c=>c.group||''))];
 const rail=$('sectionRail');
 if(rail.dataset.subject!==SUBJ.id){
  rail.dataset.subject=SUBJ.id;shelfSection=null;rail.scrollLeft=0;
  let saved={};try{saved=JSON.parse(sessionStorage.getItem('shelf:'+SUBJ.id)||'{}')}catch{}
  $('chapterQuery').value=saved.query||'';$('chapterStatus').value=saved.status||'all';shelfSection=groups.includes(saved.section)?saved.section:null;
  if(saved.returning){requestAnimationFrame(()=>{scrollTo(0,saved.y||0);rail.scrollLeft=saved.x||0;});saved.returning=false;try{sessionStorage.setItem('shelf:'+SUBJ.id,JSON.stringify(saved));}catch{}}

  rail.innerHTML='<button type="button" data-all>All sections</button>'+groups.map(g=>`<button type="button" data-group="${esc(g)}">${esc(g||'Unsectioned')}</button>`).join('');
 }
 const query=$('chapterQuery').value.trim().toLowerCase(),filter=$('chapterStatus').value;
 for(const b of rail.children)b.setAttribute('aria-pressed',String(b.hasAttribute('data-all')?shelfSection===null:b.dataset.group===shelfSection));
 const counts=new Map(),latest=new Map(),earlier=earlierProgress(progressIndex,QS,SESS,SUBJ);
 for(const q of DATA.questions){
  const c=counts.get(q.chapterNo)||{total:0,eligible:0,done:0};
  c.total++;if(q.gradeable&&q.attemptable&&q.options.length)c.eligible++;if(QS[progressStorageKey(q.id)])c.done++;counts.set(q.chapterNo,c);
 }
 for(const record of SESS){
  if(record.subj!==SUBJ.id)continue;
  for(const row of record.rows||[]){
   if(row.c+row.w===0)continue;
   if(!latest.has(row.no)||latest.get(row.no).end<record.en)latest.set(row.no,{end:record.en,row,marks:record.marks||1,neg:record.neg||0});
  }
 }
 $('chapterList').innerHTML=DATA.chapters.map(ch=>{
  const {total,done,eligible}=counts.get(ch.no)||{total:0,done:0,eligible:0},last=latest.get(ch.no);
  if(shelfSection!==null&&(ch.group||'')!==shelfSection)return '';
  const prior=earlier.get(ch.no)||0;
  const status=eligible&&done>=eligible?'Complete':done||prior?'In progress':'Remaining';
  const result=last?Number((last.row.c*last.marks-last.row.w*last.neg).toFixed(2))+' / '+Number((last.row.n*last.marks).toFixed(2)):'—';
  if(filter!=='all'&&filter!==status||query&&!(ch.title+' '+(ch.group||'')).toLowerCase().includes(query))return '';
  return `<div class="chapterRow"><div class="chapterInfo"><small>${esc(ch.group||'')} · Chapter ${esc(ch.no)}</small><strong>${esc(ch.title)}</strong><small><span class="stateChip">${status}</span> </small><div class="chapterStats"><span>Attempted<b>${done+prior} / ${total}</b></span><span>Last attempt score<b>${result}</b></span></div>${prior?`<small>${prior} attempted in an earlier bank edition</small>`:''}<progress max="${eligible||1}" value="${done}" aria-label="Questions practised"></progress></div><button type="button" class="btn" data-chapter="${ch.no}" ${eligible?'':'disabled'} aria-label="Start ${esc(ch.title)}">Start →</button></div>`;
 }).join('')||'<p>No chapters match these filters.</p><button class="btn" type="button" data-clear-shelf>Clear chapter filters</button>';
}
$('chapterList').onclick=e=>{
 if(e.target.closest('[data-clear-shelf]')){shelfSection=null;$('chapterQuery').value='';$('chapterStatus').value='all';drawChapterShelf();return;}
 const b=e.target.closest('[data-chapter]');if(!b||!signedIn())return;
 $('fClear').click();$('mkSrc').value='all';chosenChapters.add(+b.dataset.chapter);
 fillChapters();userFilter();chooseRoute();
};
function populateFilters(){
 fillSel(examFilter,'All exams',[...new Set(DATA.questions.flatMap(q=>q.examTags.map(t=>t.family||t.label)).filter(Boolean))].sort((a,b)=>a.localeCompare(b)).map(x=>[x,x]));
 const ys=[...new Set(DATA.questions.flatMap(q=>q.examTags.flatMap(yrsOf)))].sort((a,b)=>a-b);
 fillSel(yearFilter,'All years',ys.map(y=>[String(y),String(y)]));yearFilter.disabled=!ys.length;
 const gs=DATA.groups||[];groupFilter.disabled=!gs.length;$('groupLbl').textContent='Section';
 fillSel(groupFilter,'All sections',gs.map(g=>[g,g]));fillChapters();
}
groupFilter.addEventListener('change',()=>{fillChapters();userFilter();});yearFilter.addEventListener('change',userFilter);

/* subjects */
async function ensureData(s){
 if(!s.data&&!navigator.onLine)s.data=await QM.kvGet('cache:offline:'+s.id);
 if(!s.data)s.data=s.builtin?await QM.deadline((window.__pre&&window.__pre.id===s.id?window.__pre.p:fetch('data/'+s.id+'.json').then(r=>r.json())),30000):s.cloud?await QM.deadline(QM.bank(s.cloud,()=>toast('Showing the saved version. Reopen this subject when the latest download is available.')),30000):await kv.get('subj:'+s.id);
 if(!s.prep){const g=new Map(s.data.chapters.map(c=>[c.no,c.group||'']));s.data.questions.forEach(q=>q.group=g.get(q.chapterNo)||'');s.data.groups=[...new Set(s.data.chapters.map(c=>c.group).filter(Boolean))];s.prep=1;}
 return s.data;}
function buildSubjectSelect(){const el=$('subjectSel');el.innerHTML='';SUBJECTS.forEach(s=>el.append(new Option(s.name,s.id)));el.append(new Option('＋ Add subject…','__add'));if(SUBJ)el.value=SUBJ.id;}
async function openSubject(id,first){
 const s=SUBJECTS.find(x=>x.id===id)||SUBJECTS[0];
 if(!first){logSession(submitted?'submitted':'in-progress');saveNow();flushPersist();stopClock();}
 if(SUBJ?.id!==s.id)chosenChapters.clear();await ensureData(s);await loadSubjData(s);SUBJ=s;DATA=s.data;KEY=s.id==='polity'?'pq-state-v2':'qm-state:'+s.id;
 byId=new Map(DATA.questions.map(q=>[q.id,q]));buildWords();
 answers.clear();spent.clear();elapsed=0;submitted=false;mode='practice';sess={};retryIds=null;search='';$('searchBox').value='';viewFilter.value='all';
 paused=false;document.body.classList.remove('paused');$('summaryBackdrop').hidden=true;
 populateFilters();store.set(LS_LAST,s.id);$('subjectSel').value=s.id;
 $('brandTitle').textContent=s.name;$('brandSub').textContent=`Master test · ${DATA.chapters.length} chapters`;document.title=s.name+' · My PYQ Online';$('sourceNote').innerHTML=s.sourceHtml||'';
 const legacy=QM.legacyFlags(s.id);
 if(legacy.length)await QM.importFlags(s,DATA.questions,legacy);
 const prefix=QM.bookmarkPrefix(s.id),keys=await QM.kvKeys(prefix);
 const savedBookmarks=await Promise.all(keys.map(key=>QM.kvGet(key)));
 flags.clear();for(const b of savedBookmarks)if(b&&!b.deleted)flags.add(b.id);
 const prior=restore();
 if(prior?.s&&location.pathname.endsWith('/builder.html')){answers.clear();spent.clear();submitted=false;sess={};elapsed=0;}
if(sess.ids)retryIds=new Set(sess.ids);const clock=prior&&sess.practiceClock;applyFilters();if(prior&&sess.ids)setOrder(sess.ids.filter(id=>byId.has(id)));if(clock){sess.practiceClock=clock;if(clock.review&&!answers.has(clock.id))FORCE.add(clock.id);}
 if(prior&&(submitted||sess.id)){const i=order.findIndex(q=>q.id===prior.c);if(i>0){current=i;render();}toast(submitted?'Restored your submitted test.':`Welcome back — restored ${answers.size} answers.`);}
 paint();$('pauseBtn').disabled=submitted;$('testSubmit').textContent=submitted?'Summary':L()&&!L().host?'Exit test':'End test';
 (submitted||tab!=='quiz')?stopClock():startClock();
}
$('subjectSel').addEventListener('change',e=>{const v=e.target.value;if(v==='__add'){e.target.value=SUBJ.id;openAdd();}else if(v!==SUBJ.id)openSubject(v);});

/* sessions (practice + tests) */
function ensureSess(){if(!sess.id){sess.id=uid();sess.st=Date.now()-(elapsed-(sess.eb||0))*1000;}}
function tally(){
 let c=0,w=0,u=0,att=0,tt=0,slow=null;const wrong=[],byCh=new Map(),items=[];
 order.forEach((q,i)=>{const a=answers.get(q.id),r=byCh.get(q.chapterNo)||{no:q.chapterNo,t:q.chapter,n:0,c:0,w:0};r.n++;byCh.set(q.chapterNo,r);if(!a)return;att++;
  const s=spent.get(q.id)||0;tt+=s;if(!slow||s>slow.s)slow={s,label:`${q.chapterNo}·${q.number}`};
  if(a.grade==='correct'){c++;r.c++}else if(a.grade==='wrong'){w++;r.w++;wrong.push({id:q.id,i,label:`${q.chapterNo}·${q.number}`,ch:q.chapter})}else if(a.grade==='ungraded')u++;
  items.push([q.id,selKeys(a).join(','),a.grade,s,sess.confidence?.[q.id]||'']);});
 return{c,w,u,att,tt,slow,wrong,total:order.length,rows:[...byCh.values()],items,marks:sess.marks||1,neg:sess.neg||0,mock:!!sess.mock,lim:sess.lim||0};}
function filterDesc(){const f=[],sel=x=>x.value!=='all';if(retryIds)f.push(sess.live?'Live room':sess.mock?'Custom session':'Retry missed');if(sel(groupFilter))f.push(groupFilter.value);if(sel(examFilter))f.push(examFilter.value);if(sel(yearFilter))f.push(yearFilter.value);if(chosenChapters.size)f.push('Chapters '+[...chosenChapters].join(', '));if(sel(viewFilter))f.push(viewFilter.options[viewFilter.selectedIndex].text);if(search)f.push('“'+search+'”');return f.join(' · ')||'All questions';}
function logSession(status){
 if(!SUBJ||!sess.id||!order.length)return;const d=tally();if(!d.att&&status!=='submitted')return;
 const rec={id:sess.id,subj:SUBJ.id,subjName:SUBJ.name,mode,status,st:sess.st,en:Date.now(),dur:Math.max(0,elapsed-(sess.eb||0)),filt:filterDesc(),questionIds:order.map(q=>q.id),...d};
 if(SUBJ.id.startsWith('paper-'))rec.paperRefs=Object.fromEntries(order.map(q=>[q.id,q.origin]));
 const i=SESS.findIndex(r=>r.id===rec.id);if(i>=0)SESS[i]=rec;else SESS.push(rec);kv.set('sessions',SESS);}
document.addEventListener('visibilitychange',()=>{if(document.hidden&&SUBJ){logSession(submitted?'submitted':'in-progress');saveNow();flushPersist();}});
addEventListener('pagehide',()=>{if(SUBJ){logSession(submitted?'submitted':'in-progress');saveNow();flushPersist();}});

/* summary (live + saved sessions) */
let summaryCtx={rec:null};
function paintSummary(d,rec){
 summaryCtx={rec};const mixed=!rec&&mixedTest();const ex=d.mode==='exam';
 $('summaryTitle').textContent=rec?`${d.subjName} · ${d.mock?'Mock test':ex?'Test':'Practice'} session`:'Test summary';
 $('summaryTime').textContent=rec?`${fmtDate(d.st)} · ${fmt(d.dur)} · ${d.total} questions${d.status==='in-progress'?' · in progress':''}`:`Completed in ${fmt(elapsed)} · ${d.total} questions in this test`;
 if(d.mock||d.neg){const sc=Math.round((d.c*(d.marks||1)-d.w*d.neg)*100)/100;$('summaryTime').textContent+=` · Score ${sc} / ${d.total*(d.marks||1)}`;}$('summaryCorrect').textContent=d.c;$('summaryIncorrect').textContent=d.w;$('summaryUnattempted').textContent=d.total-d.att;$('summaryUngraded').textContent=d.u;
 $('summaryAvg').textContent=d.att?mmss(Math.round(d.tt/d.att)):'–';$('summarySlow').textContent=d.slow&&d.slow.s?mmss(d.slow.s):'–';$('summarySlowQ').textContent=d.slow&&d.slow.s&&!mixed?`Slowest · ${d.slow.label}`:'Slowest question';
 const pct=d.c+d.w?Math.round(d.c/(d.c+d.w)*100):0;$('ringPct').textContent=pct+'%';$('ringFg').style.strokeDashoffset=402.1;
 requestAnimationFrame(()=>requestAnimationFrame(()=>$('ringFg').style.strokeDashoffset=402.1*(1-pct/100)));
 const rows=d.rows.filter(r=>r.c+r.w>0).sort((a,b)=>a.c/(a.c+a.w)-b.c/(b.c+b.w));
 $('chapterRows').hidden=mixed;$('chapterRows').previousElementSibling.hidden=mixed;
 $('chapterRows').innerHTML=mixed?'':rows.map(r=>`<div class="chrow"><span title="${esc(r.t)}">${r.no} · ${esc(r.t)}</span><div class="track"><i style="width:${r.c/r.n*100}%;background:var(--ok)"></i><i style="width:${r.w/r.n*100}%;background:var(--bad)"></i></div><em>${r.c}/${r.n}</em></div>`).join('')||'<p class="dnote">No attempts to break down.</p>';
 $('weakNote').hidden=mixed||rows.length<2;if(rows.length>=2)$('weakNote').textContent=`Focus first on: ${rows.slice(0,3).map(r=>`${r.no} · ${r.t}`).join(', ')}`;
 $('incorrectCountSummary').textContent=`(${d.wrong.length})`;$('retryBtn').disabled=!d.wrong.length;$('reviewMistakes').hidden=!d.wrong.length;$('reviewMistakes').onclick=()=>$('incorrectList').querySelector('button')?.click();$('reviewBox').innerHTML='';
 $('incorrectList').innerHTML=d.wrong.length?d.wrong.map((x,k)=>`<button type="button" data-k="${k}"><b>${mixed?'Q'+(x.i+1):x.label}</b>${mixed?'':`<span>${esc(x.ch)}</span>`}</button>`).join(''):'<p class="dnote">No incorrect answers. Nicely done.</p>';
 $('incorrectList').querySelectorAll('[data-k]').forEach(b=>b.addEventListener('click',()=>{const x=d.wrong[+b.dataset.k];if(rec)showReview(rec,x.id);else{$('summaryBackdrop').hidden=true;go(x.i);}}));
 $('summaryBackdrop').hidden=false;$('closeSummary').focus();}
function showSummary(){paintSummary({...tally(),mode},null);}
async function showReview(rec,qid){
 const s=SUBJECTS.find(x=>x.id===rec.subj),box=$('reviewBox');
 if(!s){box.innerHTML='<p class="dnote">This subject was removed, so the question can no longer be shown.</p>';return;}
 await ensureData(s);if(!s.map)s.map=new Map(s.data.questions.map(q=>[q.id,q]));
 const q=s.map.get(qid);if(!q){box.innerHTML='<p class="dnote">This question is no longer in the subject.</p>';return;}
 const it=rec.items.find(x=>x[0]===qid),sel=it&&it[1]?it[1].split(','):[];
 box.innerHTML=`<div class="review"><b>${q.chapterNo}·${q.number} · ${esc(q.chapter)}</b><p class="prompt" style="font-size:16px;margin:8px 0">${esc(rfs(s,q.prompt))}</p>`+q.options.map(o=>{const ok=q.correct.includes(o.sourceLabel),pk=sel.includes(o.key);return`<div class="opt ${ok?'correct':pk?'wrong':''}"><span class="letter">${esc(o.sourceLabel.toUpperCase())}</span><span>${esc(rfs(s,o.text))}</span><span class="mark">${ok?'✓':pk?'✗':''}</span></div>`}).join('')+(q.explanation?`<details open style="margin-top:10px"><summary><b>Explanation</b></summary><div style="font-family:var(--read);font-size:15px;line-height:1.6;white-space:pre-wrap;overflow-wrap:anywhere">${QM.studyHTML(rfs(s,q.explanation),esc)}</div></details>`:'')+'</div>';
 box.scrollIntoView({behavior:'smooth',block:'nearest'});}
async function retryFromRec(rec){
 if(!signedIn())return;
 const ids=new Set(rec.wrong.map(x=>x.id));if(!ids.size)return;
 if(SUBJ.id!==rec.subj){await openSubject(rec.subj);}
 else if(answers.size&&!await ask('Start a retry session?','Your current attempt in this subject will be ended (it stays in Performance).','Start retry'))return;
 for(const id of ids)if(!byId.has(id))ids.delete(id);
 if(!ids.size){toast('These questions are no longer in the subject.');return;}
 logSession(submitted?'submitted':'ended');sess={id:uid(),st:Date.now(),account:QM.user.id,ids:[...ids]};answers.clear();spent.clear();submitted=false;elapsed=0;mode='practice';
 $('summaryBackdrop').hidden=true;$('testSubmit').textContent='Submit';retryIds=ids;setTab('quiz');applyFilters();setPaused(false);startClock();toast(`Retrying ${ids.size} missed questions.`);}

/* performance tab */
function setTab(t){
 tab=t;document.body.classList.toggle('perfmode',t==='perf');document.querySelectorAll('#tabSeg button').forEach(b=>b.classList.toggle('on',b.dataset.tab===t));
 if(t==='perf'){logSession(submitted?'submitted':'in-progress');saveNow();flushPersist();stopClock();renderPerf();scrollTo({top:0});}
 else if(!submitted&&!paused)startClock();}
$('tabSeg').addEventListener('click',e=>{const b=e.target.closest('[data-tab]');if(b)setTab(b.dataset.tab);});
const accOf=r=>r.c+r.w?Math.round(r.c/(r.c+r.w)*100):null;
function renderPerf(){
 const sf0=$('pfSubj').value||'all',names=new Map(SESS.map(r=>[r.subj,r.subjName]));SUBJECTS.forEach(s=>names.set(s.id,s.name));
 fillSel($('pfSubj'),'All subjects',[...names]);$('pfSubj').value=names.has(sf0)?sf0:'all';
 const sf=$('pfSubj').value,mf=$('pfMode').value;
 const rows=SESS.filter(r=>(sf==='all'||r.subj===sf)&&(mf==='all'||r.mode===mf)).sort((a,b)=>b.en-a.en);
 const att=rows.reduce((n,r)=>n+r.att,0),g=rows.reduce((n,r)=>n+r.c+r.w,0),c=rows.reduce((n,r)=>n+r.c,0),t=rows.reduce((n,r)=>n+r.dur,0);
 $('pStats').innerHTML=[['Sessions',rows.length],['Questions answered',att],['Overall accuracy',g?Math.round(c/g*100)+'%':'–'],['Time practised',fmt(t)]].map(([k,v])=>`<div class="sstat"><span>${k}</span><b>${v}</b></div>`).join('');
 $('pList').innerHTML=rows.length?`<div class="prow h"><span>Date</span><span>Subject</span><span>Type</span><span>Answered</span><span>Score</span><span>Accuracy</span><span>Time</span></div>`+rows.map(r=>{const a=accOf(r);return`<button class="prow" type="button" data-id="${r.id}"><span>${fmtDate(r.st)}</span><span><b>${esc(r.subjName)}</b><br><small style="color:var(--muted)">${esc(r.filt||'')}</small></span><span><span class="chip ${r.mode==='exam'?'exam':''}">${r.mock?'Mock test':r.mode==='exam'?'Test':'Practice'}</span>${r.status==='in-progress'?' <span class="chip live">In progress</span>':''}</span><span>${r.att}/${r.total}</span><span><b style="color:var(--ok)">${r.c}✓</b> <b style="color:var(--bad)">${r.w}✗</b></span><span class="pacc"><div class="track"><span style="width:${a||0}%"></span></div><b>${a==null?'–':a+'%'}</b></span><span>${fmt(r.dur)}</span></button>`}).join('')
  :'<div class="empty"><h3>No sessions yet</h3><p>Answer a few questions in Practice or Exam mode — each attempt is saved here automatically.</p></div>';
 $('pList').querySelectorAll('[data-id]').forEach(b=>b.addEventListener('click',()=>{const r=SESS.find(x=>x.id===b.dataset.id);if(r)paintSummary(r,r);}));renderExtra(rows);}
$('pfSubj').addEventListener('change',renderPerf);$('pfMode').addEventListener('change',renderPerf);
$('resetAcct').addEventListener('click',async()=>{
 if(!await ask('Reset your account?','This permanently deletes all saved progress and every practice/test session for all subjects on this device. Imported subjects are kept (remove them from “Add subject”).','Reset everything'))return;
 sess={};try{Object.keys(localStorage).filter(k=>/^(pq-state|qm-state)/.test(k)).forEach(k=>localStorage.removeItem(k));}catch(e){}
 SESS=[];await kv.set('sessions',SESS);resetAll();renderPerf();toast('Account reset. All progress and sessions were cleared.');});
function stateKeys(){try{return Object.keys(localStorage).filter(k=>/^(pq-|qm-)/.test(k))}catch(e){return[]}}
$('bkExport').addEventListener('click',()=>{logSession(submitted?'submitted':'in-progress');saveNow();flushPersist();const st={};stateKeys().forEach(k=>st[k]=localStorage.getItem(k));const subs={};SUBJECTS.filter(s=>!s.builtin&&s.data).forEach(s=>subs[s.id]=s.data);
 dl(`quizmaster-backup-${new Date().toISOString().slice(0,10)}.json`,JSON.stringify({qmBackup:1,state:st,sessions:SESS,subjects:subs}));toast('Backup file created.');});
$('bkImport').addEventListener('click',()=>$('bkFile').click());
$('bkFile').addEventListener('change',async e=>{const f=e.target.files[0];e.target.value='';if(!f)return;
 try{const b=JSON.parse(await f.text());if(!b.qmBackup)throw 0;
  if(!await ask('Restore this backup?','Saved progress in the backup replaces matching progress on this device; sessions are merged.','Restore'))return;
  Object.entries(b.state||{}).forEach(([k,v])=>store.set(k,v));
  const m=new Map(SESS.map(r=>[r.id,r]));(b.sessions||[]).forEach(r=>m.set(r.id,r));await kv.set('sessions',[...m.values()]);
  for(const [id,d] of Object.entries(b.subjects||{}))await kv.set('subj:'+id,d);for(const [k,v] of Object.entries(b.kvs||{}))await kv.set(k,v);
  toast('Backup restored — reloading…');setTimeout(()=>location.reload(),700);
 }catch(x){toast('That file is not a valid My PYQ Online backup.');}});

/* add / import subject */
const TEMPLATE={_readme:['Replace the sample content with your own and keep this structure. Save as .json and import it from Subject → Add subject.','subject (required): name shown in the subject list. subtitle, source and groupLabel are optional.','chapters (optional): [{ "no": 1, "title": "…", "group": "…" }]. "group" powers an extra filter (e.g. Physics / Chemistry / Biology, or Ancient / Medieval / Modern).','questions (required): chapter = chapter number (or chapter title); options = 2 to 6 choices (letters a–f are assigned in order); answer = a letter such as "b", or ["a","c"] when several options are correct. Leave answer out for an unscored question.','explanation and exams (for example "UPSC CSE (Pre) 2019") are optional; exam labels with a year feed the Exam and Year filters. This _readme key is ignored.'],format:'quizmaster-subject-v1',subject:'General Science',subtitle:'NCERT based · Class 6–10',groupLabel:'Branch',chapters:[{no:1,title:'Motion and Force',group:'Physics'},{no:2,title:'Acids, Bases and Salts',group:'Chemistry'}],questions:[{chapter:1,question:'The SI unit of force is –',options:['Joule','Newton','Watt','Pascal'],answer:'b',explanation:'Force is measured in newton (N).',exams:['UPSC CSE (Pre) 2019']},{chapter:2,question:'Which of the following are acids?\n1. HCl\n2. NaOH\n3. H2SO4',options:['1 and 2','2 only','1 and 3','1, 2 and 3'],answer:'c',explanation:'NaOH is a base.',exams:[]},{chapter:1,question:'Select all vector quantities.',options:['Speed','Velocity','Displacement','Mass'],answer:['b','c'],explanation:'Velocity and displacement have direction.'}]};
function examTag(l){const ys=new Set();String(l).replace(/\b((?:19|20)\d{2})\b/g,(_,y)=>ys.add(+y));
 const fam=String(l).replace(/\b(?:19|20)\d{2}\b/g,' ').replace(/\b\d+(?:st|nd|rd|th)\b/gi,' ').replace(/\b(?:Pre|Prelims?|Mains?|Spl|Special|Re-?Exam)\b\.?/gi,' ').replace(/[()\[\],;:-]+/g,' ').replace(/\s+/g,' ').trim();
 return{label:String(l),family:fam||String(l),stage:'',year:ys.size?[...ys][0]:0,years:[...ys]};}
/* ===== v3: Excel import/export · smart revision · notes · mock tests · goals & charts ===== */
const INTERVALS=[0,1,3,7,16,35],dayKey=(t=Date.now())=>{const d=new Date(t);return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');};
let QS={},NOTES={},NTS={},DAILY={},PREFS={goal:30},_ps=null;
const h32=s=>{let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return(h>>>0).toString(36);};
const polityCatalog = {"chapters":["The Constitutional Development of India","Constituent Assembly and Making of the Constitution","Important Committees of Constituent Assembly","Sources of the Constitution","Parts of Indian Constitution","Articles of the Constitution","Schedules","The Preamble","The Governance System","National Symbols","States and Union Territories","The Citizenship","Fundamental Rights","Directive Principles of State Policy","Fundamental Duties","The President","The Vice-President","The Council of Ministers","The Attorney General and the C.A.G.","Order of Precedence","The Parliament (1)","The Parliament (2)","The Parliament (3)","Parliamentary Committees","The Parliamentary Act","The Supreme Court","The Governor","The State Legislature","The High Court","The Centre-State Relations","Emergency Provisions","The Finance Commission","The Planning Commission/NITI Aayog","Lokpal and Important Commissions","Temporary, Transitional and Special Provisions","Election Commission","Political Parties","Constitutional Amendments","Official Language","Panchayati Raj and Community Development","Special Provision for Certain Classes","Miscellaneous"],"entries":{"C01-Q001-P007":[1,"Ugc24pk"],"C01-Q001-P010":[1,"Ucpo2s2"],"C01-Q002-P007":[1,"Uc9onua"],"C01-Q002-P010":[1,"Uq90cgn"],"C01-Q003-P008":[1,"U18vf5wk"],"C01-Q003-P010":[1,"Uyw3v62"],"C01-Q004-P008":[1,"U1cvyiir"],"C01-Q004-P010":[1,"U1xgi1vk"],"C01-Q005-P008":[1,"U1ml1jn0"],"C01-Q005-P011":[1,"U1c7vohp"],"C01-Q006-P008":[1,"U17fu2n2"],"C01-Q006-P011":[1,"U1dzycbs"],"C01-Q007-P008":[1,"U74z0fe"],"C01-Q007-P011":[1,"U14u6w8"],"C01-Q008-P009":[1,"U1z0qdpa"],"C01-Q008-P011":[1,"Uhe4a5h"],"C01-Q009-P011":[1,"Uoqi1ts"],"C01-Q010-P011":[1,"U75dy47"],"C01-Q011-P012":[1,"Umq8anh"],"C01-Q012-P012":[1,"U1onczig"],"C01-Q013-P012":[1,"U10kxb0q"],"C01-Q014-P012":[1,"U1ja8ilw"],"C01-Q015-P013":[1,"U1xrzdix"],"C01-Q016-P013":[1,"U5xe509"],"C01-Q017-P013":[1,"U1ve9i5s"],"C01-Q018-P013":[1,"U1jeo2y"],"C01-Q019-P014":[1,"U1q0nplf"],"C01-Q020-P014":[1,"U1gz6ha8"],"C01-Q021-P014":[1,"U19woddv"],"C01-Q022-P014":[1,"U10yltl3"],"C01-Q023-P014":[1,"U1ci0ree"],"C01-Q024-P014":[1,"Unrnvz8"],"C01-Q025-P014":[1,"Ulozhlt"],"C01-Q026-P015":[1,"Utt9roc"],"C01-Q027-P015":[1,"U2gdzgx"],"C01-Q028-P015":[1,"U9lsi9o"],"C01-Q029-P015":[1,"U8dg3y2"],"C01-Q030-P015":[1,"U1q42ny4"],"C01-Q031-P015":[1,"U1lbmjkb"],"C01-Q032-P016":[1,"Uip3xb8"],"C01-Q033-P016":[1,"U19vw1a1"],"C01-Q034-P016":[1,"Uh0grgk"],"C01-Q035-P016":[1,"U7zt4cp"],"C01-Q036-P016":[1,"U10c65dp"],"C02-Q001-P017":[2,"U1rgh354"],"C02-Q002-P018":[2,"Uogfy2v"],"C02-Q003-P018":[2,"Upe3h1x"],"C02-Q004-P018":[2,"Uk9vd4q"],"C02-Q005-P018":[2,"U13d6d00"],"C02-Q006-P018":[2,"Uaps2da"],"C02-Q007-P018":[2,"U1ac828k"],"C02-Q008-P018":[2,"U1hr3a3t"],"C02-Q009-P019":[2,"Ubujg92"],"C02-Q010-P019":[2,"U1icelym"],"C02-Q011-P019":[2,"U1kyz13s"],"C02-Q013-P019":[2,"U1chl1uh"],"C02-Q014-P019":[2,"Uf2ml27"],"C02-Q015-P020":[2,"Uvslyq7"],"C02-Q016-P020":[2,"U1jgg2qg"],"C02-Q017-P020":[2,"U1xhucl5"],"C02-Q018-P020":[2,"U1w5zoy1"],"C02-Q019-P021":[2,"Uz7m1lk"],"C02-Q020-P021":[2,"Ux7odv1"],"C02-Q021-P021":[2,"Ud2kqcj"],"C02-Q022-P021":[2,"U17drch1"],"C02-Q023-P021":[2,"Uwry19e"],"C02-Q024-P021":[2,"U1kwy25n"],"C02-Q025-P021":[2,"U1iwjxeg"],"C02-Q026-P021":[2,"Ua83m7k"],"C02-Q027-P022":[2,"U1blfe5i"],"C02-Q028-P022":[2,"U1kji6jo"],"C02-Q029-P022":[2,"Ueiwvhr"],"C02-Q030-P022":[2,"U1ncecrk"],"C02-Q031-P022":[2,"U1f3i84o"],"C02-Q032-P022":[2,"U1k5cg0t"],"C02-Q033-P022":[2,"U1m97be1"],"C02-Q034-P022":[2,"Uou789s"],"C02-Q035-P023":[2,"U148gu3c"],"C02-Q036-P023":[2,"U3390ru"],"C02-Q037-P023":[2,"U19j4a95"],"C02-Q038-P023":[2,"U1xjdjsh"],"C02-Q040-P023":[2,"Ujhg1zn"],"C02-Q041-P023":[2,"Uenlnmb"],"C02-Q042-P023":[2,"U1524lon"],"C02-Q043-P024":[2,"Uyois95"],"C02-Q044-P024":[2,"Ukcoyz7"],"C02-Q045-P024":[2,"Ufem38c"],"C02-Q046-P024":[2,"Ufaq1ig"],"C02-Q047-P024":[2,"Us18mwc"],"C02-Q048-P025":[2,"U1sgd6ee"],"C02-Q049-P025":[2,"U1eelx1x"],"C02-Q050-P025":[2,"Uk345lj"],"C02-Q051-P025":[2,"U1lavqkn"],"C02-Q052-P025":[2,"Uyzl68u"],"C02-Q053-P025":[2,"Ukg6hpq"],"C02-Q054-P025":[2,"U1hs2od9"],"C02-Q055-P025":[2,"Up1gwz2"],"C02-Q056-P025":[2,"Uvx87yh"],"C02-Q057-P026":[2,"Uo0hsyr"],"C02-Q058-P026":[2,"Uaupu31"],"C02-Q059-P026":[2,"U1fz3pjh"],"C02-Q060-P026":[2,"U1t8ushe"],"C02-Q061-P026":[2,"U48ieco"],"C02-Q062-P027":[2,"U1qjgof7"],"C02-Q063-P027":[2,"U1wq4tcn"],"C02-Q064-P027":[2,"U1dgd8q3"],"C02-Q065-P027":[2,"Ulcry89"],"C02-Q066-P027":[2,"U1kuo8t8"],"C02-Q067-P027":[2,"U1iuv10k"],"C02-Q068-P028":[2,"Uhpfc6d"],"C02-Q069-P028":[2,"U12mm34o"],"C02-Q070-P028":[2,"Uesvhkd"],"C02-Q071-P028":[2,"Uk52ytc"],"C02-Q072-P028":[2,"Uhrpzmb"],"C02-Q073-P028":[2,"U1d4oe2f"],"C03-Q001-P029":[3,"U1hujez1"],"C03-Q002-P029":[3,"Uyhgj3v"],"C03-Q003-P029":[3,"U1ogxjde"],"C03-Q004-P030":[3,"U1k9gms0"],"C03-Q005-P030":[3,"U1oa5lo7"],"C03-Q006-P030":[3,"Utzeq92"],"C03-Q007-P030":[3,"U17v235q"],"C03-Q008-P030":[3,"U8e4gik"],"C03-Q009-P031":[3,"U213f6e"],"C03-Q010-P031":[3,"U1f1x0gh"],"C03-Q011-P031":[3,"U1mvmpyq"],"C03-Q012-P031":[3,"Uc7cy9i"],"C03-Q013-P031":[3,"Ui178a5"],"C04-Q001-P033":[4,"U1g247rj"],"C04-Q002-P033":[4,"Uniwy2b"],"C04-Q003-P033":[4,"U3oyli3"],"C04-Q004-P033":[4,"U14cj2xa"],"C04-Q005-P033":[4,"Upz7v6w"],"C04-Q006-P033":[4,"Usc5kri"],"C04-Q007-P033":[4,"U3nzpsm"],"C04-Q008-P034":[4,"Umhiql9"],"C04-Q009-P034":[4,"Ux0ukyf"],"C04-Q010-P034":[4,"U1kr0s9n"],"C04-Q011-P034":[4,"U1aro0st"],"C04-Q012-P034":[4,"U243vl5"],"C04-Q013-P034":[4,"U147xk01"],"C04-Q014-P034":[4,"U8aiojh"],"C04-Q015-P034":[4,"U1y11x7q"],"C04-Q016-P035":[4,"U6r8jlq"],"C04-Q017-P035":[4,"Uwd1031"],"C04-Q018-P035":[4,"Uod7dgk"],"C04-Q019-P035":[4,"Us3x6af"],"C04-Q020-P035":[4,"U44r6u0"],"C04-Q021-P036":[4,"U9fdo8i"],"C04-Q022-P036":[4,"U12e4721"],"C04-Q023-P036":[4,"U1n142kc"],"C04-Q024-P036":[4,"U14v3kxm"],"C04-Q025-P036":[4,"Uqueouh"],"C04-Q026-P037":[4,"U19ky0t8"],"C04-Q027-P037":[4,"U1grqse1"],"C04-Q028-P037":[4,"U1tbxnxn"],"C04-Q029-P037":[4,"U18r98y2"],"C05-Q001-P038":[5,"U1kh38p3"],"C05-Q002-P038":[5,"U1xmowg9"],"C05-Q003-P038":[5,"U1asdtl3"],"C05-Q004-P038":[5,"Uil3kxj"],"C05-Q005-P038":[5,"Ui05c6x"],"C05-Q006-P038":[5,"Uinvm4b"],"C05-Q007-P039":[5,"Ucsuyur"],"C05-Q008-P039":[5,"U1bih4w"],"C05-Q009-P039":[5,"Uhh66jq"],"C05-Q010-P039":[5,"Udv2w4n"],"C05-Q011-P039":[5,"U1q154je"],"C05-Q012-P040":[5,"U18wn8jh"],"C05-Q013-P040":[5,"U10xvpob"],"C05-Q014-P040":[5,"U1jbep4i"],"C05-Q015-P040":[5,"U7vf3pp"],"C05-Q016-P040":[5,"Uca9jpx"],"C05-Q017-P041":[5,"U10ou0yb"],"C05-Q018-P041":[5,"U23r40p"],"C05-Q019-P041":[5,"Uckokrg"],"C05-Q020-P041":[5,"Uilz8fi"],"C06-Q001-P044":[6,"Uyo9lj5"],"C06-Q002-P044":[6,"U1bsfeg"],"C06-Q003-P044":[6,"U1bihhjw"],"C06-Q004-P044":[6,"U1w0dt0j"],"C06-Q005-P044":[6,"U107jpsp"],"C06-Q006-P044":[6,"U1bd22i0"],"C06-Q007-P045":[6,"U1sszkbr"],"C06-Q008-P045":[6,"U9gqon7"],"C06-Q009-P045":[6,"U1wnyhnb"],"C06-Q010-P045":[6,"U1kn82gf"],"C06-Q011-P045":[6,"U1p8wvxi"],"C06-Q012-P045":[6,"Uqmbjbv"],"C06-Q013-P046":[6,"U1dd3jwj"],"C06-Q014-P046":[6,"U9lwpqp"],"C06-Q015-P046":[6,"U1lwrpo"],"C06-Q017-P047":[6,"U1439kkf"],"C06-Q018-P047":[6,"U1yc1vrs"],"C06-Q019-P047":[6,"Unb81i1"],"C06-Q020-P048":[6,"Uc6eq0h"],"C06-Q021-P048":[6,"U8kdisu"],"C06-Q022-P048":[6,"U167uyo9"],"C06-Q023-P048":[6,"Uqywjl0"],"C06-Q024-P049":[6,"Uul7xpv"],"C06-Q025-P049":[6,"U11nnq2a"],"C06-Q026-P049":[6,"U7thbt0"],"C06-Q027-P049":[6,"U14qq1tt"],"C06-Q028-P050":[6,"U1pxvjqn"],"C06-Q029-P050":[6,"U1brvjt4"],"C07-Q001-P051":[7,"U1eb0f39"],"C07-Q002-P051":[7,"U2vy43o"],"C07-Q003-P051":[7,"Ub00pd0"],"C07-Q004-P051":[7,"Uvccpgr"],"C07-Q005-P051":[7,"U1qpchbi"],"C07-Q006-P052":[7,"Uw395pe"],"C07-Q007-P052":[7,"U1x4l3i9"],"C07-Q008-P052":[7,"U1ibqmac"],"C07-Q009-P052":[7,"U1g5agz1"],"C07-Q010-P052":[7,"Uxuyu3n"],"C07-Q011-P053":[7,"U17dr4jn"],"C07-Q012-P053":[7,"U1sz1kpj"],"C07-Q013-P053":[7,"U10xiw9f"],"C07-Q014-P053":[7,"Ueci1a"],"C07-Q015-P054":[7,"U1taerp2"],"C07-Q016-P054":[7,"U1y72brk"],"C07-Q017-P054":[7,"U17ng40r"],"C07-Q018-P054":[7,"U1sryqie"],"C07-Q019-P054":[7,"Ua9ivmu"],"C07-Q020-P054":[7,"U1e7kxl2"],"C07-Q021-P055":[7,"Ust7ey6"],"C07-Q022-P055":[7,"U29ness"],"C07-Q023-P055":[7,"U1a6qawp"],"C07-Q024-P055":[7,"Uzvxhd4"],"C07-Q025-P055":[7,"U15xg2ur"],"C07-Q026-P055":[7,"U1j8gv0g"],"C07-Q027-P056":[7,"Ujnp9s"],"C07-Q028-P056":[7,"U3x40dy"],"C07-Q029-P056":[7,"U7hdk36"],"C07-Q030-P056":[7,"U62z3kc"],"C07-Q031-P056":[7,"U1nhlwgz"],"C07-Q032-P056":[7,"Uq3l9zv"],"C07-Q033-P057":[7,"U1360dq7"],"C07-Q034-P057":[7,"U1890v5i"],"C07-Q035-P057":[7,"Uhwe5sr"],"C07-Q036-P057":[7,"U5pjrk4"],"C07-Q037-P057":[7,"U14mw5qe"],"C07-Q038-P057":[7,"Ud4goem"],"C07-Q039-P057":[7,"Ulvnn9d"],"C07-Q040-P057":[7,"U1l9qwzr"],"C07-Q041-P058":[7,"Ufx3jej"],"C07-Q042-P058":[7,"U1in04oj"],"C07-Q043-P058":[7,"U1bu6o3d"],"C07-Q044-P058":[7,"U104skst"],"C07-Q045-P058":[7,"Uug17zv"],"C07-Q046-P058":[7,"U16b2bmu"],"C07-Q047-P058":[7,"U1v41nzz"],"C07-Q048-P059":[7,"Ujl2mc"],"C07-Q049-P059":[7,"Utp3kv1"],"C07-Q050-P059":[7,"U1db0qcr"],"C07-Q051-P059":[7,"U1sxp74d"],"C07-Q052-P059":[7,"Unsysy2"],"C07-Q053-P059":[7,"Uli3n5n"],"C07-Q054-P060":[7,"U1m4puho"],"C07-Q055-P060":[7,"U1nbkmba"],"C07-Q056-P060":[7,"U1gu1auv"],"C07-Q057-P060":[7,"Uc7l36"],"C07-Q058-P060":[7,"Ul0hbst"],"C07-Q059-P060":[7,"U2v5t4"],"C07-Q060-P061":[7,"U14aa6ps"],"C07-Q061-P061":[7,"U13eq82j"],"C07-Q062-P061":[7,"U1osynmg"],"C07-Q063-P061":[7,"U1tnj9cl"],"C07-Q064-P061":[7,"U1psgo8p"],"C08-Q001-P062":[8,"U67kbr4"],"C08-Q002-P062":[8,"Usc7y4l"],"C08-Q003-P062":[8,"U1ft531w"],"C08-Q004-P062":[8,"U1hhorzp"],"C08-Q005-P063":[8,"Ufnl1zt"],"C08-Q006-P063":[8,"U68gqu"],"C08-Q007-P063":[8,"Ucxgl3e"],"C08-Q008-P063":[8,"Uj85434"],"C08-Q009-P063":[8,"U6rmpqv"],"C08-Q010-P064":[8,"Uclv955"],"C08-Q011-P064":[8,"U1hm9nwj"],"C08-Q012-P064":[8,"U1pjtiy9"],"C08-Q013-P064":[8,"U1r1x9gx"],"C08-Q014-P064":[8,"U1pn91mi"],"C08-Q015-P064":[8,"U84tj5f"],"C08-Q016-P064":[8,"Utgxkaf"],"C08-Q017-P064":[8,"U2dn0tb"],"C08-Q018-P064":[8,"U1u1v8q4"],"C08-Q019-P065":[8,"U1qtos04"],"C08-Q020-P065":[8,"Upd8yxm"],"C08-Q021-P065":[8,"Uepgxwj"],"C08-Q022-P065":[8,"U1qypxv4"],"C08-Q023-P065":[8,"U1guggod"],"C08-Q024-P065":[8,"U1oovodf"],"C08-Q025-P065":[8,"Uov0t3w"],"C08-Q026-P066":[8,"U1dct8ul"],"C08-Q027-P066":[8,"Utmi34w"],"C08-Q028-P066":[8,"Uep18n2"],"C08-Q029-P066":[8,"Uxjyvyv"],"C08-Q030-P066":[8,"U15k34b5"],"C08-Q031-P066":[8,"U87x0al"],"C08-Q032-P066":[8,"Untcz05"],"C08-Q033-P067":[8,"U3sx8dv"],"C08-Q034-P067":[8,"Uf0969s"],"C08-Q035-P067":[8,"U2vq6l9"],"C08-Q036-P067":[8,"U59ljb5"],"C08-Q037-P067":[8,"U1eaw3u4"],"C08-Q038-P067":[8,"Uheqx68"],"C08-Q039-P068":[8,"Ukij9iu"],"C08-Q040-P068":[8,"U18fgw5d"],"C08-Q041-P068":[8,"Utsw4wv"],"C08-Q042-P068":[8,"Ukwzu3j"],"C08-Q043-P068":[8,"Uzmsyuu"],"C08-Q044-P068":[8,"Uyf0qg7"],"C08-Q045-P068":[8,"U1fpas6p"],"C08-Q046-P069":[8,"Uy663su"],"C08-Q047-P069":[8,"U1x9e44h"],"C08-Q048-P069":[8,"U1v5ijjo"],"C08-Q049-P069":[8,"Uva0d1c"],"C08-Q050-P069":[8,"U1s00jff"],"C08-Q051-P069":[8,"U14p6zb9"],"C09-Q001-P071":[9,"U1sbpxsu"],"C09-Q002-P071":[9,"Urxqz3w"],"C09-Q003-P071":[9,"Un4tqxj"],"C09-Q004-P072":[9,"U15i41kq"],"C09-Q005-P072":[9,"U3n3esg"],"C09-Q006-P072":[9,"Uae2hbc"],"C09-Q007-P072":[9,"Uh0pg2c"],"C09-Q008-P072":[9,"Upmmdxe"],"C09-Q009-P072":[9,"Upa10u9"],"C09-Q010-P072":[9,"U1i8xa7b"],"C09-Q011-P073":[9,"U2080n9"],"C09-Q012-P073":[9,"U1ar5py"],"C09-Q013-P073":[9,"U13xhfrg"],"C09-Q014-P073":[9,"Ut2vmc8"],"C09-Q015-P074":[9,"Ukh7nw4"],"C09-Q016-P074":[9,"Ug48yo1"],"C09-Q017-P074":[9,"U5aflfu"],"C09-Q018-P074":[9,"U16a1fox"],"C09-Q019-P074":[9,"Uahte5l"],"C09-Q020-P075":[9,"U6angxh"],"C09-Q021-P075":[9,"U1dcdrqe"],"C09-Q022-P075":[9,"Ujvgw3v"],"C09-Q023-P075":[9,"U1xiqb49"],"C09-Q024-P075":[9,"U1ujzpat"],"C09-Q025-P075":[9,"Uuburpn"],"C09-Q026-P076":[9,"Uo9raz2"],"C09-Q027-P076":[9,"U16iw2co"],"C09-Q028-P076":[9,"U18hudhc"],"C09-Q029-P076":[9,"U1pr7ewe"],"C09-Q030-P076":[9,"Ucp7kpc"],"C09-Q031-P076":[9,"Urpbpxe"],"C09-Q032-P076":[9,"Us939xq"],"C09-Q033-P076":[9,"Ufzog11"],"C09-Q034-P076":[9,"Un0sdti"],"C09-Q035-P077":[9,"U9rrkmd"],"C09-Q036-P077":[9,"U1bbo2vh"],"C09-Q037-P077":[9,"U1elvxgg"],"C09-Q038-P077":[9,"Ukxzk14"],"C09-Q039-P077":[9,"U12riz8w"],"C09-Q040-P077":[9,"Ufarw3g"],"C09-Q041-P078":[9,"U1fufwu0"],"C09-Q042-P078":[9,"U1sitql5"],"C09-Q043-P078":[9,"U1a9wgik"],"C09-Q044-P078":[9,"Uaf16rx"],"C09-Q045-P078":[9,"U1ad4y3e"],"C09-Q046-P079":[9,"U8advhg"],"C09-Q047-P079":[9,"U1j2suwn"],"C09-Q048-P079":[9,"U4xee3e"],"C09-Q049-P079":[9,"Utpriqw"],"C09-Q050-P080":[9,"U1ajdhbi"],"C09-Q051-P080":[9,"Urnzesj"],"C09-Q052-P080":[9,"U1tdq8j9"],"C09-Q053-P080":[9,"U1jdxvdo"],"C09-Q054-P081":[9,"U1vb8oj"],"C09-Q055-P081":[9,"Ulkleuo"],"C09-Q056-P081":[9,"Ujrifli"],"C09-Q057-P081":[9,"U1quapnk"],"C09-Q058-P082":[9,"Uw4hn2"],"C09-Q059-P082":[9,"U9fvpli"],"C09-Q060-P082":[9,"U4oytvs"],"C09-Q061-P082":[9,"U15m8i81"],"C09-Q062-P082":[9,"Uayvxd7"],"C09-Q063-P083":[9,"U6pydka"],"C09-Q064-P083":[9,"Upgq47c"],"C09-Q065-P083":[9,"U1rifh3f"],"C09-Q066-P083":[9,"Ufw6v3x"],"C09-Q067-P083":[9,"U1pf7aqa"],"C09-Q068-P083":[9,"Uccgk15"],"C09-Q069-P084":[9,"Uwscguq"],"C09-Q070-P084":[9,"U1eifrd9"],"C09-Q071-P084":[9,"Usdqb9u"],"C09-Q072-P084":[9,"U1vxa7h8"],"C09-Q073-P084":[9,"U1hmcvxd"],"C09-Q074-P085":[9,"U7ifv7i"],"C09-Q075-P085":[9,"U5nysdv"],"C09-Q076-P085":[9,"U1177jtm"],"C09-Q077-P085":[9,"Urtsq8u"],"C09-Q078-P085":[9,"U1resy3j"],"C09-Q079-P086":[9,"Umrvjly"],"C09-Q080-P086":[9,"U1ic9dul"],"C09-Q081-P086":[9,"Ufxxb2k"],"C09-Q082-P086":[9,"Uww09r7"],"C09-Q083-P086":[9,"U12fzkh1"],"C10-Q001-P087":[10,"U1dh0ybh"],"C10-Q002-P087":[10,"Uo9dayw"],"C10-Q003-P087":[10,"U174n12j"],"C10-Q004-P088":[10,"U1548wxv"],"C10-Q005-P088":[10,"Uzg2fxu"],"C10-Q006-P088":[10,"U6b3oay"],"C10-Q007-P088":[10,"U2ifyys"],"C10-Q008-P088":[10,"U1d80wqx"],"C10-Q009-P088":[10,"U10bn7bg"],"C10-Q010-P088":[10,"U1dfwnix"],"C10-Q011-P089":[10,"Uuvltsv"],"C10-Q012-P089":[10,"U1mg3ovw"],"C10-Q013-P089":[10,"U1f8m3jk"],"C10-Q014-P089":[10,"U15q87co"],"C10-Q015-P089":[10,"U7e7hbq"],"C10-Q016-P089":[10,"Uzpi3ez"],"C11-Q001-P090":[11,"U1ted91t"],"C11-Q002-P090":[11,"Uyrjfrd"],"C11-Q003-P090":[11,"U150phyg"],"C11-Q004-P091":[11,"U1n2cqpn"],"C11-Q005-P091":[11,"Ufp9o7c"],"C11-Q006-P091":[11,"U2tlwvn"],"C11-Q007-P091":[11,"U1ik17zf"],"C11-Q008-P091":[11,"Uow32ti"],"C11-Q009-P091":[11,"U1dbtiff"],"C11-Q010-P091":[11,"U21aw41"],"C11-Q011-P091":[11,"Uyrsxeo"],"C11-Q012-P092":[11,"Umqax3"],"C11-Q013-P092":[11,"U109ntnw"],"C11-Q014-P092":[11,"Uvycbzb"],"C11-Q015-P092":[11,"U4rh8zt"],"C11-Q016-P093":[11,"U15yb7b8"],"C11-Q017-P093":[11,"U11hph9u"],"C11-Q018-P093":[11,"U1sr0twb"],"C11-Q019-P093":[11,"U41ti88"],"C11-Q020-P094":[11,"U1hsu8v4"],"C11-Q021-P094":[11,"Ueopxii"],"C11-Q022-P094":[11,"U8s3azx"],"C11-Q023-P094":[11,"Untq03x"],"C11-Q024-P094":[11,"Uqgsmoh"],"C11-Q025-P094":[11,"Uva770o"],"C11-Q026-P094":[11,"U149mhmb"],"C11-Q027-P095":[11,"U1czy38b"],"C11-Q028-P095":[11,"U18lg79d"],"C11-Q029-P095":[11,"U1azbq0c"],"C11-Q030-P095":[11],"C11-Q031-P095":[11,"Ugdi8an"],"C11-Q032-P096":[11,"Uzbce37"],"C11-Q033-P096":[11,"U9szk0t"],"C11-Q034-P096":[11,"U6ow19y"],"C11-Q035-P096":[11,"U1q5wb7d"],"C11-Q036-P096":[11,"U7dq4nn"],"C11-Q037-P096":[11,"U1nd05dy"],"C11-Q038-P096":[11,"U1o9s6rq"],"C11-Q039-P097":[11,"U1ow90i7"],"C11-Q040-P097":[11,"Uxn31ad"],"C11-Q041-P097":[11,"Utsicol"],"C11-Q042-P097":[11,"U1yi62vt"],"C11-Q043-P097":[11,"U4o4gue"],"C11-Q044-P098":[11,"Ueovszs"],"C11-Q045-P098":[11,"Ugo2m2w"],"C11-Q046-P098":[11,"Uwifiph"],"C11-Q047-P098":[11,"U1hwc7r0"],"C11-Q048-P098":[11,"U1wn6vn3"],"C11-Q049-P098":[11,"U1iqpq4v"],"C11-Q050-P098":[11,"U18rdr22"],"C11-Q051-P099":[11,"U252feq"],"C11-Q052-P099":[11,"U1g2pmz"],"C11-Q053-P099":[11,"U1risr4x"],"C11-Q054-P099":[11,"U1g2wn3"],"C11-Q055-P099":[11,"U1fkz60y"],"C11-Q056-P100":[11,"U1e41og8"],"C11-Q057-P100":[11,"U109g2uj"],"C11-Q058-P100":[11,"U1moammu"],"C11-Q059-P100":[11,"U195dd9b"],"C11-Q060-P100":[11,"U1y25huo"],"C11-Q061-P100":[11,"Ur1lkp9"],"C11-Q062-P101":[11,"Uf29o53"],"C11-Q063-P101":[11,"U8ifhqu"],"C11-Q064-P101":[11,"Uoxayh1"],"C11-Q065-P101":[11,"U1vqtd38"],"C11-Q066-P101":[11,"Uw1joz0"],"C11-Q067-P101":[11,"Uww5etr"],"C12-Q001-P102":[12,"Urpfl26"],"C12-Q002-P102":[12,"U1s41dcx"],"C12-Q003-P102":[12,"U1spsio6"],"C12-Q004-P102":[12,"Uh1yhlp"],"C12-Q005-P103":[12,"U178eb"],"C12-Q006-P103":[12,"Udtdr1j"],"C12-Q007-P103":[12,"Uarrwuv"],"C12-Q008-P103":[12,"U10vnjxo"],"C12-Q009-P103":[12,"U1ehhji9"],"C12-Q010-P104":[12,"U1xfi079"],"C12-Q011-P104":[12,"U1joldaf"],"C12-Q012-P104":[12,"Uk721jm"],"C12-Q013-P104":[12,"U1kes8wo"],"C12-Q014-P105":[12,"U12w8b5p"],"C12-Q015-P105":[12,"Uw1kf0"],"C12-Q016-P105":[12,"U1qzgh5t"],"C12-Q017-P105":[12,"U1eb6imw"],"C13-Q001-P106":[13,"Ub3ad0a"],"C13-Q002-P106":[13,"Uasbm4s"],"C13-Q003-P107":[13,"Ub3y21o"],"C13-Q004-P107":[13,"U1a9c31s"],"C13-Q005-P107":[13,"U5955n2"],"C13-Q006-P107":[13,"U1d0i4tg"],"C13-Q007-P107":[13,"Usv3tvi"],"C13-Q008-P107":[13,"Ucxr0li"],"C13-Q009-P107":[13,"U1psqjsi"],"C13-Q010-P108":[13,"U8ucc6p"],"C13-Q011-P108":[13,"U1nm3q52"],"C13-Q012-P108":[13,"U2cchxv"],"C13-Q013-P108":[13,"U1souzjo"],"C13-Q014-P108":[13,"U1i0heta"],"C13-Q015-P109":[13,"U1mcjqvc"],"C13-Q016-P109":[13,"U1e6o82v"],"C13-Q017-P109":[13,"U1bg97vu"],"C13-Q018-P109":[13,"U1b4atkm"],"C13-Q019-P109":[13,"U1bgh5x3"],"C13-Q020-P109":[13,"U181hkef"],"C13-Q021-P110":[13,"U1tmdf1b"],"C13-Q022-P110":[13,"U9ux9w5"],"C13-Q023-P110":[13,"Uitxl1f"],"C13-Q024-P110":[13,"U1refcse"],"C13-Q025-P110":[13,"U567o12"],"C13-Q026-P111":[13,"U1dfg2v9"],"C13-Q027-P111":[13,"U5o10ty"],"C13-Q028-P111":[13,"U1oq0858"],"C13-Q029-P111":[13,"U14lewhn"],"C13-Q030-P112":[13],"C13-Q031-P112":[13,"U1ad5a3a"],"C13-Q032-P112":[13,"Ul8r316"],"C13-Q033-P112":[13,"U1ig9ygn"],"C13-Q034-P112":[13,"Uvtngvf"],"C13-Q035-P112":[13,"Ul0bkj2"],"C13-Q036-P112":[13,"U15x8xaa"],"C13-Q037-P113":[13,"Urabjfq"],"C13-Q038-P113":[13,"Um4m6hv"],"C13-Q039-P113":[13,"U1uepo7e"],"C13-Q040-P113":[13,"Uj20pkw"],"C13-Q041-P113":[13,"Uj5ofkx"],"C13-Q042-P114":[13,"U1tqil6r"],"C13-Q043-P114":[13,"U1l42w9n"],"C13-Q044-P114":[13,"U18ar9lf"],"C13-Q045-P114":[13,"U9mk470"],"C13-Q046-P114":[13,"U5igdxd"],"C13-Q047-P114":[13,"U1d22zho"],"C13-Q048-P115":[13],"C13-Q049-P115":[13],"C13-Q050-P115":[13,"Uybrear"],"C13-Q051-P115":[13,"Uqok9w6"],"C13-Q052-P115":[13,"Uhg9gg4"],"C13-Q053-P115":[13,"Ujqvko2"],"C13-Q054-P115":[13,"Up05844"],"C13-Q055-P116":[13,"Ua60o0y"],"C13-Q056-P116":[13,"Ukdpuw0"],"C13-Q057-P116":[13,"U117ibtj"],"C13-Q058-P116":[13,"U154goex"],"C13-Q059-P116":[13,"U1vn894e"],"C13-Q060-P117":[13,"Uy7x9mz"],"C13-Q061-P117":[13,"Uckwttf"],"C13-Q062-P117":[13,"U113zn3g"],"C13-Q063-P117":[13,"U19psria"],"C13-Q064-P117":[13,"U17w1g3h"],"C13-Q065-P118":[13,"U1ynp840"],"C13-Q066-P118":[13,"U12i96am"],"C13-Q067-P118":[13,"U4ckow5"],"C13-Q068-P118":[13,"U1492owe"],"C13-Q069-P118":[13,"Uno8i5"],"C13-Q070-P118":[13,"U1jfeopm"],"C13-Q071-P119":[13,"U13a302c"],"C13-Q072-P119":[13,"Up2mp6b"],"C13-Q073-P119":[13,"Uo5zqap"],"C13-Q074-P119":[13,"U1hvsfbe"],"C13-Q075-P119":[13,"U19cvtey"],"C13-Q076-P120":[13,"Ueiu225"],"C13-Q077-P120":[13,"Uwmhatz"],"C13-Q078-P120":[13,"U17zwj6s"],"C13-Q079-P120":[13,"Ujjizap"],"C13-Q080-P120":[13,"Utg8ikt"],"C13-Q081-P120":[13,"U175l8sa"],"C13-Q082-P120":[13,"Um8u4tb"],"C13-Q083-P120":[13,"U128n5p6"],"C13-Q084-P121":[13,"Uxxlh9f"],"C13-Q085-P121":[13,"U8reh68"],"C13-Q086-P121":[13,"Uuj8lmp"],"C13-Q087-P121":[13,"U1z0g4ww"],"C13-Q088-P122":[13,"Uulck3m"],"C13-Q089-P122":[13,"U11go9bd"],"C13-Q090-P122":[13,"U1o4gmi7"],"C13-Q091-P122":[13,"U1gxvm6l"],"C13-Q092-P122":[13,"U1osfaad"],"C13-Q093-P122":[13,"U1i05h6l"],"C13-Q094-P123":[13,"Ub1cvny"],"C13-Q095-P123":[13,"U1v77l4h"],"C13-Q096-P123":[13,"U1jzmyym"],"C13-Q097-P123":[13,"Ufny7fo"],"C13-Q098-P123":[13,"Uzhg9gi"],"C13-Q099-P124":[13,"Ufygd3x"],"C13-Q100-P124":[13,"U66qmb8"],"C13-Q101-P124":[13,"U1w24e6i"],"C13-Q102-P124":[13,"U5ile1h"],"C13-Q103-P124":[13,"Umsg3ug"],"C13-Q104-P124":[13,"Ublm2a1"],"C13-Q105-P124":[13,"U1ewf92f"],"C13-Q106-P125":[13,"Uf3ryy5"],"C13-Q107-P125":[13,"Ua2v3oa"],"C13-Q108-P125":[13,"Uee3xgv"],"C13-Q109-P125":[13,"U10gmz3"],"C13-Q110-P125":[13,"Umv0ioj"],"C13-Q111-P126":[13,"U16er3kw"],"C13-Q112-P126":[13,"Uuumrur"],"C13-Q113-P126":[13,"U1lo89cj"],"C13-Q114-P126":[13,"Uao7nio"],"C13-Q115-P126":[13,"Ux72klg"],"C13-Q116-P127":[13,"Uhxsosa"],"C13-Q117-P127":[13,"Uzco6ts"],"C13-Q118-P127":[13,"U2iy78s"],"C13-Q119-P127":[13,"U121hpsn"],"C13-Q120-P127":[13,"U1q43fik"],"C13-Q121-P127":[13,"Ul19g2f"],"C13-Q122-P128":[13,"U8uu7qq"],"C13-Q123-P128":[13,"U8rfz9q"],"C13-Q124-P128":[13,"U9h7m9z"],"C13-Q125-P128":[13,"Uxvvf1t"],"C13-Q126-P129":[13,"U1n7o1x4"],"C13-Q127-P129":[13,"U1qosvpt"],"C13-Q128-P129":[13,"U1a6coj5"],"C13-Q129-P130":[13,"Uam95vw"],"C13-Q130-P130":[13,"Uxia98"],"C13-Q131-P130":[13,"Uvpoc59"],"C13-Q132-P130":[13,"U1tvci0g"],"C13-Q133-P130":[13,"U3lrc2o"],"C13-Q134-P130":[13,"U16pg1yf"],"C13-Q135-P130":[13,"U14rgjgb"],"C13-Q136-P131":[13,"U112t9c0"],"C13-Q137-P131":[13,"U1i4esxp"],"C13-Q138-P131":[13,"U1mt13oz"],"C13-Q139-P131":[13,"U1ynfi9"],"C13-Q140-P131":[13,"Us7yz39"],"C13-Q141-P131":[13,"Uzzteek"],"C13-Q142-P131":[13,"Ukxtknc"],"C13-Q143-P131":[13,"Uk7tj2k"],"C13-Q144-P132":[13,"U1kznp0c"],"C13-Q145-P132":[13,"Utl4pe4"],"C13-Q146-P132":[13,"U1hzddgn"],"C13-Q147-P132":[13,"U1hzddgn_1"],"C13-Q148-P132":[13,"Uh77cjo"],"C13-Q149-P132":[13,"U1v7je6r"],"C13-Q150-P132":[13,"U1q9bkir"],"C13-Q151-P132":[13,"Ufqh38o"],"C13-Q152-P133":[13,"Uvbmzue"],"C13-Q153-P133":[13,"Ubd4z2v"],"C13-Q154-P133":[13,"U1ickfd4"],"C13-Q155-P133":[13,"U1gc4qsb"],"C13-Q156-P134":[13,"Ummllz9"],"C13-Q157-P134":[13,"U6nmf92"],"C13-Q158-P134":[13,"Ug53vr3"],"C13-Q159-P134":[13,"U1t6o664"],"C13-Q160-P134":[13,"U1t7fgsu"],"C13-Q161-P134":[13,"U1iw12mn"],"C13-Q162-P135":[13,"U1izr602"],"C13-Q163-P135":[13,"U173qzy6"],"C13-Q164-P135":[13,"Uv334i2"],"C13-Q165-P135":[13,"Ulj3yrh"],"C13-Q166-P135":[13,"U1pmykd4"],"C13-Q167-P135":[13,"U1kxwm0s"],"C13-Q168-P136":[13,"Uxvdap4"],"C13-Q169-P136":[13,"Uuak35b"],"C14-Q001-P138":[14,"U1145fpj"],"C14-Q002-P138":[14,"U1pjonyn"],"C14-Q003-P138":[14,"U14dp3b6"],"C14-Q004-P138":[14,"U1obq70g"],"C14-Q005-P139":[14,"U1vqdud1"],"C14-Q006-P139":[14,"Uusm8ja"],"C14-Q007-P139":[14,"U1itglnp"],"C14-Q008-P139":[14,"U1dgpn6t"],"C14-Q009-P139":[14,"U1blswh8"],"C14-Q010-P139":[14,"U1vpuiwh"],"C14-Q011-P140":[14,"U1je7mpt"],"C14-Q012-P140":[14,"U1y4010p"],"C14-Q013-P140":[14,"Ulin548"],"C14-Q014-P140":[14,"Ug4guii"],"C14-Q015-P140":[14,"U14cpg70"],"C14-Q016-P140":[14,"U1k8jycx"],"C14-Q017-P140":[14,"U1gigh9n"],"C14-Q018-P141":[14,"Ugjxzyq"],"C14-Q019-P141":[14,"Uw7nqeb"],"C14-Q020-P141":[14,"Ufqn3kl"],"C14-Q021-P141":[14,"U1kfdm1o"],"C14-Q022-P141":[14,"U1ir2fpi"],"C14-Q023-P141":[14,"U1ue5ksy"],"C14-Q024-P141":[14,"Uwyirvy"],"C14-Q025-P142":[14,"U17x05s0"],"C14-Q026-P142":[14,"Uyazlv1"],"C14-Q027-P142":[14,"Uh5sqjc"],"C14-Q028-P142":[14,"U1tglhbq"],"C14-Q029-P142":[14,"U1a7uriv"],"C14-Q030-P142":[14,"U1widrit"],"C14-Q031-P142":[14,"Utglx2i"],"C14-Q032-P143":[14,"U4u1k06"],"C14-Q033-P143":[14,"U1770r5g"],"C14-Q034-P143":[14,"U54dqwh"],"C14-Q035-P143":[14,"Ukmea25"],"C14-Q036-P144":[14,"U16ol5cp"],"C14-Q037-P144":[14,"U1r9bhgv"],"C14-Q038-P144":[14,"U104sqlj"],"C14-Q039-P144":[14,"U1w0qqp3"],"C14-Q040-P144":[14,"Uuj2xev"],"C14-Q041-P145":[14,"U1vf4xpz"],"C14-Q042-P145":[14,"U1gyyryk"],"C14-Q043-P145":[14,"Uziqcze"],"C14-Q044-P145":[14,"U1c3tajw"],"C14-Q045-P145":[14,"U1yflcmx"],"C14-Q046-P145":[14,"U9m6l24"],"C14-Q047-P145":[14,"Uuou9q6"],"C14-Q048-P146":[14,"U307nxy"],"C14-Q049-P146":[14,"Udtbd42"],"C14-Q050-P146":[14,"Uhb26c9"],"C14-Q051-P146":[14,"U1m8p301"],"C14-Q052-P146":[14,"U3zkbvc"],"C14-Q053-P146":[14,"U1gldobs"],"C14-Q054-P147":[14,"U1jtycqa"],"C14-Q055-P147":[14,"U1p1tvfx"],"C14-Q056-P147":[14,"U1ufv6oa"],"C14-Q057-P147":[14,"U1v9mbm2"],"C14-Q058-P147":[14,"Ugd1lbo"],"C14-Q059-P148":[14,"Uturyra"],"C14-Q060-P148":[14,"Uhquv3"],"C14-Q061-P148":[14,"U16p9wjm"],"C14-Q062-P149":[14,"U4wi44l"],"C14-Q063-P149":[14,"U1vcmget"],"C14-Q064-P149":[14,"U9yhso2"],"C14-Q065-P149":[14,"U1m8p301_1"],"C14-Q066-P149":[14,"U184dali"],"C14-Q067-P149":[14,"U1mom066"],"C14-Q068-P150":[14,"Uhjoy51"],"C15-Q001-P150":[15,"U1sow5te"],"C15-Q002-P151":[15,"U17zmngt"],"C15-Q003-P151":[15,"U8gunpv"],"C15-Q004-P151":[15,"U1w2gbry"],"C15-Q005-P151":[15,"U8vd41d"],"C15-Q006-P151":[15,"U1jz5muy"],"C15-Q007-P151":[15,"U1pt113i"],"C15-Q008-P151":[15,"U23rkjj"],"C15-Q009-P151":[15,"Unp9woz"],"C15-Q010-P152":[15,"Uwxwxgp"],"C15-Q011-P152":[15,"U183uiev"],"C15-Q012-P152":[15,"Uv1ncmf"],"C15-Q013-P152":[15,"U905sjn"],"C15-Q014-P152":[15,"Up5xaxx"],"C15-Q015-P152":[15,"U1xgusea"],"C15-Q016-P152":[15,"U3ygif6"],"C15-Q017-P152":[15,"U89ven6"],"C15-Q018-P153":[15,"U1d8ktpi"],"C15-Q019-P153":[15,"U11jvsek"],"C15-Q020-P153":[15,"U69vbmq"],"C15-Q021-P153":[15,"Up3nrvn"],"C15-Q022-P153":[15,"Ucb1mfh"],"C15-Q023-P153":[15,"Uahg15a"],"C15-Q024-P153":[15,"U28lt90"],"C15-Q025-P153":[15,"U8y9dep"],"C15-Q026-P154":[15,"U3c2cml"],"C15-Q027-P154":[15,"U1lwrf8u"],"C15-Q028-P154":[15,"Uf7lo57"],"C15-Q029-P154":[15,"U1fuo2be"],"C15-Q030-P154":[15,"U17b4w0g"],"C15-Q031-P155":[15,"U1c8klh"],"C15-Q032-P155":[15,"U1i20nsa"],"C15-Q033-P155":[15,"Ucny0jy"],"C15-Q034-P155":[15,"U1wwfb9y"],"C15-Q035-P155":[15,"Ulj2aed"],"C15-Q036-P155":[15,"U1ss2dae"],"C15-Q037-P155":[15,"Uzwfikp"],"C15-Q038-P155":[15,"Uvnww0s"],"C15-Q039-P156":[15,"U1k5vztr"],"C15-Q040-P156":[15,"U862nnn"],"C15-Q041-P156":[15,"U7876y8"],"C16-Q001-P157":[16,"Uyqbpjt"],"C16-Q002-P158":[16,"U148lpka"],"C16-Q003-P158":[16,"U190ud58"],"C16-Q004-P158":[16,"Uqz1xw7"],"C16-Q005-P158":[16,"U17eoghl"],"C16-Q006-P159":[16,"Uz4khpu"],"C16-Q007-P159":[16,"U196c3tn"],"C16-Q008-P159":[16,"U98khjf"],"C16-Q009-P159":[16,"U11jpf5z"],"C16-Q010-P159":[16,"U1ye40wm"],"C16-Q011-P159":[16,"U1tk60wa"],"C16-Q012-P159":[16,"U1siqmzt"],"C16-Q013-P159":[16,"U141ydbt"],"C16-Q014-P160":[16,"U1837zio"],"C16-Q015-P160":[16,"U3bsxjy"],"C16-Q016-P160":[16,"Uchotpc"],"C16-Q017-P160":[16,"Ughm0g"],"C16-Q018-P160":[16,"Ug5yu9t"],"C16-Q019-P160":[16,"Ulw9tfj"],"C16-Q020-P161":[16,"Umxrygv"],"C16-Q021-P161":[16,"Ukpsdg9"],"C16-Q022-P161":[16,"Uhex5ri"],"C16-Q023-P161":[16,"Unnjvdh"],"C16-Q024-P161":[16,"Ucru4d3"],"C16-Q025-P161":[16,"U1odyq0z"],"C16-Q026-P161":[16,"Ufedde7"],"C16-Q027-P161":[16,"Ufn8t8g"],"C16-Q028-P162":[16,"Ufoszxq"],"C16-Q029-P162":[16,"U3o3x58"],"C16-Q030-P162":[16,"Ur0tp7n"],"C16-Q031-P162":[16],"C16-Q032-P163":[16,"U1azxas2"],"C16-Q033-P163":[16,"U11wx4e0"],"C16-Q034-P164":[16,"U1jxa0i6"],"C16-Q035-P164":[16,"U13exkb2"],"C16-Q036-P164":[16,"Uv9cl0j"],"C16-Q037-P164":[16,"U1rol1et"],"C16-Q038-P164":[16,"U1li6gy9"],"C16-Q039-P165":[16,"U3qhary"],"C16-Q040-P165":[16,"U1lumwb5"],"C16-Q041-P165":[16,"U151dh7z"],"C16-Q042-P165":[16,"U1sm738j"],"C16-Q043-P165":[16,"U170tpdt"],"C16-Q044-P166":[16,"Uh5ie9o"],"C16-Q045-P166":[16,"U2kue1o"],"C16-Q046-P166":[16,"U8uob9g"],"C16-Q047-P166":[16,"U16ckhet"],"C16-Q048-P166":[16,"Ugm5rie"],"C16-Q049-P166":[16],"C16-Q050-P166":[16,"Ukqrn18"],"C16-Q051-P166":[16,"U121b8zv"],"C16-Q052-P167":[16,"U10330ee"],"C16-Q053-P167":[16,"U1xofmzj"],"C16-Q054-P167":[16,"U8fybdl"],"C16-Q055-P167":[16,"U40t25a"],"C16-Q056-P167":[16,"Ufqcpfu"],"C16-Q057-P167":[16,"U16e75q2"],"C16-Q058-P167":[16,"U75heyk"],"C16-Q059-P168":[16,"Uxh732y"],"C16-Q060-P168":[16,"U8jekla"],"C16-Q061-P168":[16,"Uqn34x7"],"C16-Q062-P168":[16,"U14gjzz6"],"C16-Q063-P168":[16,"Uij8lmy"],"C16-Q064-P168":[16,"U10ac0fb"],"C16-Q065-P168":[16,"Uo0ifrx"],"C16-Q066-P168":[16,"U16kpg19"],"C16-Q067-P169":[16,"U1c74wud"],"C16-Q068-P169":[16,"U13cf40w"],"C16-Q069-P169":[16,"U19zkxul"],"C16-Q070-P169":[16,"Uz43wox"],"C16-Q071-P169":[16,"Ufosglc"],"C16-Q072-P169":[16,"U1kha2w9"],"C16-Q073-P169":[16,"U17m86y6"],"C16-Q074-P170":[16,"Uca2tzv"],"C16-Q075-P170":[16,"Um9b4wp"],"C16-Q076-P170":[16,"U6w6c01"],"C16-Q077-P170":[16,"Us34a4f"],"C16-Q078-P170":[16,"U1p3xvzb"],"C16-Q079-P171":[16,"U1mnpu0w"],"C16-Q080-P171":[16,"U190ta7u"],"C16-Q081-P171":[16,"U1ha5xf3"],"C16-Q082-P171":[16,"Umgmmm"],"C16-Q083-P171":[16,"U17ocb4g"],"C16-Q084-P171":[16,"Uxfxi04"],"C16-Q085-P172":[16,"Uivscu"],"C16-Q086-P172":[16,"Uig8wth"],"C16-Q087-P172":[16,"Uqwx"],"C16-Q088-P172":[16,"U1n19c2h"],"C16-Q089-P172":[16,"U1g7q25k"],"C16-Q090-P173":[16,"Uxvx3ob"],"C16-Q091-P173":[16,"Ud5d8rd"],"C16-Q092-P173":[16,"Uwovwqn"],"C16-Q093-P173":[16,"U1sdt6ad"],"C16-Q094-P173":[16,"Uh8qeyq"],"C16-Q095-P174":[16,"U1mwmj5f"],"C16-Q096-P174":[16,"U14okcwa"],"C16-Q097-P174":[16,"U16g25pm"],"C16-Q098-P174":[16,"U1r14iv1"],"C16-Q099-P174":[16,"U1ot8qzd"],"C16-Q100-P174":[16,"U1aam368"],"C16-Q101-P175":[16,"U1mpzxv9"],"C16-Q102-P175":[16,"Udevfny"],"C16-Q103-P175":[16,"U5vvthl"],"C16-Q104-P175":[16,"U1y182ac"],"C16-Q105-P175":[16,"Ulucw3z"],"C16-Q106-P175":[16,"U1tf1cxh"],"C16-Q107-P175":[16,"U1b1xhsm"],"C16-Q108-P176":[16,"U164smce"],"C16-Q109-P176":[16,"U11z0ulu"],"C16-Q110-P176":[16,"U1hdq0l2"],"C16-Q111-P176":[16,"U1srq9sm"],"C16-Q112-P176":[16,"U1k0dre0"],"C16-Q113-P177":[16,"U180cwp8"],"C16-Q114-P177":[16,"Ux0j36f"],"C16-Q115-P177":[16,"U1m46j5p"],"C16-Q116-P177":[16,"U2wixp"],"C16-Q117-P177":[16,"Ubmlmny"],"C16-Q118-P177":[16,"U1k9d8xf"],"C16-Q119-P177":[16,"U1qe4q3e"],"C16-Q120-P177":[16,"U1b9hjw7"],"C16-Q121-P177":[16,"U1630oos"],"C16-Q122-P178":[16,"Uu7k7vv"],"C16-Q123-P178":[16,"U4v1xfw"],"C16-Q124-P178":[16,"Uds9eq3"],"C16-Q125-P178":[16,"U1w1uwgu"],"C16-Q126-P178":[16,"U102wvt1"],"C16-Q127-P178":[16,"U17otl9z"],"C16-Q128-P178":[16,"Uh6i0z2"],"C16-Q129-P178":[16,"U172w4vd"],"C16-Q130-P179":[16,"U1frpkqe"],"C16-Q131-P179":[16,"Uc1s2dn"],"C16-Q132-P179":[16,"Ujf9bq8"],"C16-Q133-P179":[16,"U1eihf9d"],"C16-Q134-P179":[16,"U1dehvk3"],"C16-Q135-P179":[16,"U102hu24"],"C17-Q001-P180":[17,"U1w2ff5q"],"C17-Q002-P180":[17,"U1y0fx07"],"C17-Q003-P180":[17,"U15w58mg"],"C17-Q004-P180":[17,"Ubz9393"],"C17-Q005-P180":[17,"U1squ4ot"],"C17-Q006-P181":[17,"U8lc3z2"],"C17-Q007-P181":[17,"Uhp3pbe"],"C17-Q008-P181":[17,"U148sziy"],"C17-Q009-P181":[17,"U14dtv7y"],"C17-Q010-P181":[17,"U16531yu"],"C17-Q011-P182":[17,"U2vnbou"],"C17-Q012-P182":[17,"Ujed5mw"],"C17-Q013-P182":[17,"Upc7iv9"],"C17-Q014-P182":[17,"U12vgdlr"],"C17-Q015-P182":[17,"U1d7a5e7"],"C17-Q016-P182":[17,"Uuqa7gq"],"C17-Q017-P183":[17,"U193css1"],"C17-Q018-P183":[17,"U10z127e"],"C17-Q019-P183":[17,"Uz84m8v"],"C17-Q020-P183":[17,"U18vue0k"],"C17-Q021-P183":[17,"U14ywgfq"],"C17-Q022-P183":[17,"U3x75s0"],"C17-Q023-P183":[17,"U1xnz8gu"],"C18-Q001-P184":[18,"Umw6lke"],"C18-Q002-P184":[18,"U2dlcs5"],"C18-Q003-P185":[18,"Usj3au"],"C18-Q004-P185":[18,"U1s0x9dl"],"C18-Q005-P185":[18,"U1s2o8tn"],"C18-Q006-P185":[18,"Uac62fd"],"C18-Q007-P185":[18,"Ubk2g0n"],"C18-Q008-P186":[18,"Ucumoic"],"C18-Q009-P186":[18,"U1v7k463"],"C18-Q010-P186":[18,"U15fxm5s"],"C18-Q011-P186":[18,"U1jdi06h"],"C18-Q012-P186":[18,"U1qgqt5m"],"C18-Q013-P187":[18,"U1gjqp6w"],"C18-Q014-P187":[18,"U1vvmivs"],"C18-Q015-P187":[18,"Uj0nuy5"],"C18-Q016-P187":[18,"Ulsch23"],"C18-Q017-P187":[18,"U1l3yxhy"],"C18-Q018-P187":[18,"Uuw3i2f"],"C18-Q019-P188":[18,"Uh0o2ba"],"C18-Q020-P188":[18,"Umghq0g"],"C18-Q021-P188":[18,"U1eellhv"],"C18-Q022-P188":[18,"U16xvkp4"],"C18-Q023-P188":[18,"Ui0njk3"],"C18-Q024-P188":[18,"U1hgxcqd"],"C18-Q025-P188":[18,"U1658sae"],"C18-Q026-P189":[18,"U1fdcepx"],"C18-Q027-P189":[18,"U99nk3m"],"C18-Q028-P189":[18,"Ujjgaxe"],"C18-Q029-P189":[18,"U15qi7jg"],"C18-Q030-P189":[18,"Uy7c3uu"],"C18-Q031-P189":[18,"Ub8jtv6"],"C18-Q032-P189":[18,"U1peg7v6"],"C18-Q033-P189":[18,"U1k1o6o0"],"C18-Q034-P189":[18,"U1pn6l1c"],"C18-Q035-P190":[18,"U1kjn6zr"],"C18-Q036-P190":[18,"U5q5l5w"],"C18-Q037-P190":[18,"Uynvinq"],"C18-Q038-P190":[18,"U1q6ucyj"],"C18-Q039-P190":[18,"U14rk26q"],"C18-Q040-P190":[18,"U4iepo9"],"C18-Q041-P191":[18,"U166vqj0"],"C18-Q042-P191":[18,"U16455ns"],"C18-Q043-P191":[18,"U10huqco"],"C18-Q044-P191":[18,"U6cd3hn"],"C18-Q045-P191":[18,"U4xbj3h"],"C18-Q046-P191":[18,"Ugiwv92"],"C18-Q047-P192":[18,"Ums2fja"],"C18-Q048-P192":[18,"U1ebryji"],"C18-Q049-P192":[18,"Uyg3f83"],"C18-Q050-P192":[18,"Utiu5zc"],"C18-Q051-P192":[18,"U27soea"],"C18-Q052-P192":[18,"U1q1a1eo"],"C18-Q053-P193":[18,"U8718am"],"C18-Q054-P193":[18,"U1ttr02l"],"C18-Q055-P193":[18,"U1degn4m"],"C18-Q056-P193":[18,"U4byshg"],"C18-Q057-P193":[18,"U1fznlm4"],"C18-Q058-P194":[18,"U12y3tp1"],"C18-Q059-P194":[18,"U1wv380w"],"C18-Q060-P194":[18,"U12olzsj"],"C18-Q061-P194":[18,"U1f9j9hf"],"C18-Q062-P194":[18,"U1iwh0be"],"C18-Q063-P194":[18,"U4tm0mx"],"C18-Q064-P194":[18,"U10ouq6m"],"C18-Q065-P194":[18,"U110zior"],"C18-Q066-P195":[18,"U6r352w"],"C18-Q067-P195":[18,"U9ojda7"],"C18-Q068-P195":[18,"Uf0w1p0"],"C18-Q069-P195":[18,"U1m4pood"],"C18-Q070-P195":[18,"Uvufpje"],"C18-Q071-P196":[18,"U1al6jy7"],"C18-Q072-P196":[18,"Uin9pzw"],"C18-Q073-P196":[18,"U1nbnvjs"],"C18-Q074-P196":[18,"U1r5np9u"],"C18-Q075-P196":[18,"U1rt9jb3"],"C18-Q076-P197":[18,"U1h4ddtn"],"C18-Q077-P197":[18,"Ulx1jhl"],"C18-Q078-P197":[18,"Ulsz17t"],"C18-Q079-P197":[18,"U14gx5aw"],"C18-Q080-P197":[18,"U10i4i0o"],"C18-Q081-P197":[18,"Uqpx7v1"],"C18-Q082-P198":[18,"U1i6l5iu"],"C18-Q083-P198":[18,"U4ib8is"],"C18-Q084-P198":[18,"Uiyf1z8"],"C18-Q085-P198":[18,"Us9jzg2"],"C18-Q086-P198":[18,"U1j0otzb"],"C18-Q087-P198":[18,"Utlt9jm"],"C18-Q088-P199":[18,"U1kg73kq"],"C18-Q089-P199":[18,"U1y5bluz"],"C18-Q090-P199":[18,"U1s38vaw"],"C18-Q091-P199":[18,"Ulnwy5b"],"C18-Q092-P199":[18,"Upf8z8d"],"C19-Q001-P200":[19,"Uxs05ll"],"C19-Q002-P200":[19,"U2y7kmj"],"C19-Q003-P200":[19,"Ulzkjrd"],"C19-Q004-P200":[19,"U4cbthx"],"C19-Q005-P200":[19,"U16jdavm"],"C19-Q006-P200":[19,"Uns38c"],"C19-Q007-P200":[19,"U19wus38"],"C19-Q008-P201":[19,"U1lmvg5v"],"C19-Q009-P201":[19,"U1y4rylr"],"C19-Q010-P201":[19,"U16bn7en"],"C19-Q011-P201":[19,"U1m89jsk"],"C19-Q012-P201":[19,"U1mwpb3n"],"C19-Q013-P201":[19,"U1p7vaiv"],"C19-Q014-P202":[19,"Us2febw"],"C19-Q015-P202":[19,"Uvsp05q"],"C19-Q016-P202":[19,"Uz6ipno"],"C19-Q017-P202":[19,"Ufyguh4"],"C19-Q018-P202":[19,"U1vvxo1o"],"C19-Q019-P203":[19,"U1rme768"],"C19-Q020-P203":[19,"U1hrj1tr"],"C19-Q021-P203":[19,"U182qrwo"],"C19-Q022-P203":[19,"U1lk6a51"],"C19-Q023-P203":[19,"Uug6ebj"],"C19-Q024-P203":[19,"U11h9ba5"],"C19-Q025-P203":[19,"U1leqm4f"],"C19-Q026-P204":[19,"U1smotl7"],"C19-Q027-P204":[19,"U6diaxa"],"C19-Q028-P204":[19,"U1xobqtq"],"C19-Q029-P204":[19,"Uz69fck"],"C19-Q031-P204":[19,"Ur996iu"],"C19-Q032-P204":[19,"U1xr4w61"],"C19-Q033-P204":[19,"U1sjyth7"],"C19-Q034-P205":[19,"U1rcklly"],"C19-Q035-P205":[19,"U1uqcy7y"],"C19-Q036-P205":[19,"Ulmfw11"],"C19-Q037-P205":[19,"U1g1z8wq"],"C19-Q038-P205":[19,"Uocln9w"],"C19-Q039-P205":[19,"U735eri"],"C19-Q040-P205":[19,"U7dzw4v"],"C19-Q041-P206":[19,"Ubghw21"],"C19-Q042-P206":[19,"Uf1okm1"],"C19-Q043-P206":[19,"Uuvrkgx"],"C19-Q044-P206":[19,"U1l4kw4b"],"C19-Q045-P206":[19,"U1rwd5ow"],"C19-Q046-P207":[19,"U1756elj"],"C19-Q047-P207":[19,"Ur327lr"],"C19-Q048-P207":[19,"Uh7hhbd"],"C19-Q049-P207":[19,"Uohiq94"],"C19-Q050-P207":[19,"Utt0jzt"],"C19-Q051-P207":[19,"Uwkfwwx"],"C19-Q052-P208":[19,"U8zbk2n"],"C19-Q053-P208":[19,"U1j2jcz5"],"C19-Q054-P208":[19,"U8movb7"],"C19-Q055-P208":[19,"Ucn8t06"],"C19-Q056-P208":[19,"U18tn2t9"],"C19-Q057-P209":[19,"U1ponida"],"C19-Q058-P209":[19,"U1jbqxi7"],"C19-Q059-P209":[19,"U153on2"],"C19-Q060-P209":[19,"Uivm81a"],"C19-Q061-P209":[19,"U1h98si2"],"C19-Q062-P209":[19,"Uqiodal"],"C19-Q063-P210":[19,"U1ehj33m"],"C20-Q001-P211":[20,"U19gwtbb"],"C20-Q003-P212":[20,"Uihpwhu"],"C20-Q004-P212":[20,"Ugp01c7"],"C20-Q005-P212":[20,"U1vj28af"],"C20-Q006-P212":[20,"Ubxslb1"],"C20-Q007-P212":[20,"Uxx9lt3"],"C21-Q001-P213":[21,"U4bx9do"],"C21-Q002-P213":[21,"U19vfpu5"],"C21-Q003-P214":[21,"U1erd1od"],"C21-Q004-P214":[21,"U186d3ab"],"C21-Q005-P214":[21,"U1b49yj7"],"C21-Q006-P214":[21,"U12sklgj"],"C21-Q007-P214":[21,"U1bnd8c6"],"C21-Q008-P214":[21,"U1n2lblg"],"C21-Q009-P214":[21,"Uyef52q"],"C21-Q010-P214":[21,"U1uey73s"],"C21-Q011-P215":[21,"Usmrqk"],"C21-Q012-P215":[21,"U158cjed"],"C21-Q013-P215":[21,"Uswoep8"],"C21-Q014-P215":[21,"U1qkgdqk"],"C21-Q015-P215":[21,"U1x6a5s1"],"C21-Q016-P215":[21,"U1aa3ve7"],"C21-Q017-P215":[21,"U1ffxj0h"],"C21-Q018-P216":[21,"Um9k1hx"],"C21-Q019-P216":[21,"U1lwv0iy"],"C21-Q020-P216":[21,"U1jikzfe"],"C21-Q021-P216":[21,"U1dq6f88"],"C21-Q022-P216":[21,"U1o219xw"],"C21-Q023-P216":[21,"U1jstmrr"],"C21-Q024-P217":[21,"U89h36a"],"C21-Q025-P217":[21,"Ubas7ke"],"C21-Q026-P217":[21,"U1nkx4ft"],"C21-Q027-P217":[21,"U13fttyp"],"C21-Q028-P217":[21,"Utvibs9"],"C21-Q029-P217":[21,"Uj218ni"],"C21-Q030-P217":[21,"Uwy9ze5"],"C21-Q031-P217":[21,"Uw4ixnv"],"C21-Q032-P218":[21,"Uawxe1u"],"C21-Q033-P218":[21,"U1lypklx"],"C21-Q034-P218":[21,"Ueu63e2"],"C21-Q035-P218":[21,"U8tl65e"],"C21-Q036-P218":[21,"U79ubro"],"C21-Q037-P218":[21,"U1hzz8yl"],"C21-Q038-P219":[21,"Umrrhe9"],"C21-Q039-P219":[21,"U1pjztu8"],"C21-Q040-P219":[21,"Urqc7bj"],"C21-Q041-P219":[21,"U13iic7j"],"C21-Q042-P219":[21,"Ubkdwz9"],"C21-Q043-P219":[21,"Usrh0pb"],"C21-Q044-P219":[21,"Uxbhj2v"],"C21-Q045-P219":[21,"Ugembuy"],"C21-Q046-P220":[21,"Ub5enpb"],"C21-Q047-P220":[21,"U15crc0p"],"C21-Q048-P220":[21,"Ukl93tm"],"C21-Q049-P220":[21,"U1nx8lcr"],"C21-Q050-P220":[21,"U16cca5f"],"C21-Q051-P220":[21,"Ufhhuvt"],"C21-Q052-P220":[21,"Uadv271"],"C21-Q053-P221":[21,"U18kqic9"],"C21-Q054-P221":[21,"U12fuyxu"],"C21-Q055-P221":[21,"Ujfg0vh"],"C21-Q056-P221":[21,"U1b52rx1"],"C21-Q057-P221":[21,"U1txfv6h"],"C21-Q058-P221":[21,"U1pz3slf"],"C21-Q059-P222":[21,"U1nd8akq"],"C21-Q060-P222":[21,"U1m1w36c"],"C21-Q061-P222":[21,"U11mhpm5"],"C21-Q062-P222":[21,"U10jx6t6"],"C21-Q063-P222":[21,"U13fc2np"],"C21-Q064-P222":[21,"Uwc9ow3"],"C21-Q065-P222":[21,"Uf8u0lm"],"C21-Q066-P222":[21,"U1nexis5"],"C21-Q067-P223":[21,"U1c4kcck"],"C21-Q068-P223":[21,"Uxb2tnk"],"C21-Q069-P223":[21,"U3hsptn"],"C21-Q070-P223":[21,"Ux8nngd"],"C21-Q071-P223":[21,"Ubyc6no"],"C21-Q072-P223":[21,"Uw7xhdz"],"C21-Q073-P224":[21,"Uzrv3ko"],"C21-Q074-P224":[21,"Uh9elyb"],"C21-Q075-P224":[21,"U1u7k3ux"],"C21-Q076-P224":[21,"U169klu9"],"C21-Q077-P224":[21,"U14dhlva"],"C21-Q078-P224":[21,"U1kge8q6"],"C21-Q079-P224":[21,"U1tajbr9"],"C21-Q080-P225":[21,"U4eds5d"],"C21-Q082-P225":[21,"Uxq79bx"],"C21-Q083-P225":[21,"U143z1wx"],"C21-Q084-P226":[21,"U15m57ot"],"C21-Q085-P226":[21],"C21-Q086-P226":[21,"U15h5qgg"],"C21-Q087-P226":[21,"Ur4tio7"],"C21-Q088-P227":[21,"U1i00fck"],"C21-Q089-P227":[21,"U11krjz9"],"C21-Q090-P227":[21,"Upa89j6"],"C21-Q091-P227":[21,"Uwh5v2e"],"C21-Q092-P228":[21,"U1vu7joc"],"C21-Q093-P228":[21,"Uadelae"],"C21-Q094-P228":[21,"U9ay74"],"C21-Q095-P228":[21,"Ulipgm7"],"C21-Q096-P228":[21,"U1pnh282"],"C21-Q097-P228":[21,"U2eokci"],"C21-Q098-P228":[21,"Upctmw7"],"C21-Q099-P229":[21,"U1jiyr9v"],"C21-Q100-P229":[21,"Uptzstt"],"C21-Q101-P229":[21,"Uabqdpz"],"C21-Q102-P229":[21,"Uxwal6s"],"C21-Q103-P229":[21,"U1nbdw6f"],"C21-Q104-P229":[21,"U1yo5rkp"],"C21-Q105-P230":[21,"U4uig1c"],"C21-Q106-P230":[21,"U1g8ujsc"],"C21-Q107-P230":[21,"Umfuyhh"],"C21-Q108-P230":[21,"U1iipib3"],"C22-Q001-P231":[22,"U1qxkfky"],"C22-Q002-P232":[22,"U8v5slz"],"C22-Q003-P232":[22,"U2zz3gh"],"C22-Q004-P232":[22,"U1aeybqn"],"C22-Q005-P232":[22,"U10zyjyp"],"C22-Q006-P232":[22,"U1g8laoh"],"C22-Q007-P232":[22,"U1g9qvc2"],"C22-Q008-P233":[22,"U13n22yx"],"C22-Q009-P233":[22,"U1aounv7"],"C22-Q010-P233":[22,"U1mhx58j"],"C22-Q011-P233":[22,"U9zpdvy"],"C22-Q012-P233":[22,"U4vv9ca"],"C22-Q013-P233":[22,"Uihw7ly"],"C22-Q014-P233":[22,"U1y2gbnw"],"C22-Q015-P234":[22,"Umcz94c"],"C22-Q016-P234":[22,"Uszplqs"],"C22-Q017-P234":[22,"U17smjsh"],"C22-Q018-P234":[22,"U1cl5esh"],"C22-Q019-P234":[22,"U37d4bq"],"C22-Q020-P234":[22,"U1i0dhq4"],"C22-Q021-P234":[22,"U1ogd2mb"],"C22-Q022-P234":[22,"U53wbxs"],"C22-Q023-P235":[22,"Uyxe0u1"],"C22-Q024-P235":[22,"Uscamyp"],"C22-Q025-P235":[22,"U1sb0ym6"],"C22-Q026-P235":[22,"U1pliaqf"],"C22-Q027-P235":[22,"Uv0dlxv"],"C22-Q028-P236":[22,"Uzddu70"],"C22-Q029-P236":[22,"Uo3m79r"],"C22-Q030-P236":[22,"U1hb2km0"],"C22-Q031-P236":[22,"U603enb"],"C22-Q032-P236":[22,"U1ow78gu"],"C22-Q033-P237":[22,"U1jy6haj"],"C22-Q034-P237":[22,"U3mjki"],"C22-Q035-P237":[22,"U9449tb"],"C22-Q036-P237":[22,"U14z1epr"],"C22-Q037-P238":[22,"Uem94vi"],"C22-Q038-P238":[22,"U1m8zz46"],"C22-Q039-P238":[22,"U12fcx5r"],"C22-Q040-P238":[22,"Uclhhzf"],"C22-Q041-P238":[22,"U18t8jzi"],"C22-Q042-P238":[22,"U3ydcam"],"C22-Q043-P239":[22,"Uc0vvao"],"C22-Q044-P239":[22,"U10hz361"],"C22-Q045-P239":[22,"U11wi73l"],"C22-Q046-P239":[22,"U1peoqw3"],"C22-Q047-P240":[22,"U1bmhcfi"],"C22-Q048-P240":[22,"Uanyycz"],"C22-Q049-P240":[22,"U14z2sgy"],"C22-Q050-P240":[22,"Ukhpa0o"],"C22-Q051-P240":[22,"U48kgwl"],"C22-Q052-P240":[22,"U1nbml9y"],"C22-Q053-P241":[22,"U6enf7q"],"C22-Q054-P241":[22,"Uvyw5mp"],"C22-Q055-P241":[22,"U1tqtpzl"],"C22-Q056-P241":[22,"Urk2ojl"],"C22-Q057-P241":[22,"U31if1e"],"C22-Q058-P241":[22,"U1f8w1ad"],"C22-Q059-P241":[22,"U1dlisuf"],"C22-Q060-P242":[22,"U1fmuzxa"],"C22-Q061-P242":[22,"U1ivrt0r"],"C22-Q062-P242":[22,"U10w5nl6"],"C22-Q063-P242":[22,"Um5pm7m"],"C22-Q064-P242":[22,"U1ozzxv0"],"C23-Q001-P243":[23,"Uxhg4p7"],"C23-Q002-P244":[23,"Ujofr65"],"C23-Q003-P244":[23,"Uq2236"],"C23-Q004-P244":[23,"U1ky50pd"],"C23-Q005-P244":[23,"U13oyo2w"],"C23-Q006-P245":[23,"U1idek0a"],"C23-Q007-P245":[23,"Ujt6vp1"],"C23-Q008-P245":[23,"U1j1f0qz"],"C23-Q009-P245":[23,"U15iowsg"],"C23-Q010-P245":[23,"U1c0qh59"],"C23-Q011-P245":[23,"Uvfnzz5"],"C23-Q012-P245":[23,"U1anvopd"],"C23-Q013-P245":[23,"U1ip8ymc"],"C23-Q014-P245":[23,"Upv77oy"],"C23-Q015-P246":[23,"U1u6jk8n"],"C23-Q016-P246":[23,"U2yjj5m"],"C23-Q017-P246":[23,"U4gs1hk"],"C23-Q018-P246":[23,"Uyt4ffm"],"C23-Q019-P246":[23,"U1g5m9zy"],"C23-Q020-P246":[23,"U1mwmeb7"],"C23-Q021-P246":[23,"U1yn9wdq"],"C23-Q022-P247":[23,"Uzbodhj"],"C23-Q023-P247":[23,"Un2huky"],"C23-Q024-P247":[23],"C23-Q025-P247":[23,"U1w144pe"],"C23-Q026-P247":[23,"U1ruvxr6"],"C23-Q027-P248":[23,"U14htd03"],"C23-Q028-P248":[23,"Usg19aa"],"C23-Q029-P248":[23,"U12l9jd2"],"C23-Q030-P248":[23,"U1gbme3e"],"C23-Q031-P248":[23,"U1ei9lrh"],"C23-Q032-P248":[23,"U1b8lnvo"],"C23-Q033-P249":[23,"Ui6u79h"],"C23-Q034-P249":[23,"Us6kbbn"],"C23-Q035-P249":[23,"U1623qsn"],"C23-Q036-P249":[23,"Uvfei54"],"C23-Q037-P249":[23,"Ul0r4k9"],"C23-Q038-P250":[23,"Uf433tu"],"C23-Q039-P250":[23,"U1uv3uxd"],"C23-Q040-P250":[23,"Uxxx1w3"],"C23-Q041-P250":[23,"U1ewl8f9"],"C23-Q042-P250":[23,"U4tvxvu"],"C23-Q043-P251":[23,"Ucxgfny"],"C23-Q044-P251":[23,"Us9jcks"],"C23-Q045-P251":[23,"U3oc2gk"],"C23-Q046-P251":[23,"U785g2r"],"C23-Q047-P251":[23,"Uw24b2x"],"C23-Q048-P251":[23,"U1vbh68o"],"C23-Q049-P251":[23,"U15z2gxy"],"C23-Q050-P252":[23,"U7rezqj"],"C23-Q051-P252":[23,"Uv0zkgt"],"C23-Q052-P252":[23,"Uoa8v0l"],"C23-Q053-P252":[23,"U1lzedjn"],"C23-Q054-P252":[23,"U1c7dd73"],"C23-Q055-P252":[23,"U1ga7ryv"],"C23-Q056-P253":[23,"Ufk9g6v"],"C23-Q057-P253":[23,"U1c42vhs"],"C23-Q058-P253":[23,"U1qgmep8"],"C23-Q059-P253":[23,"Uh4020e"],"C23-Q060-P253":[23,"Udelrvd"],"C23-Q061-P253":[23,"Ue88fe6"],"C23-Q062-P254":[23,"Uffu37g"],"C23-Q063-P254":[23,"U1mcems2"],"C23-Q064-P254":[23,"U1vvy0je"],"C23-Q065-P254":[23,"U1rmwdje"],"C23-Q066-P254":[23,"Uqd317l"],"C23-Q067-P255":[23,"U139jg16"],"C23-Q068-P255":[23,"U120egm1"],"C23-Q069-P255":[23,"U1o4e0is"],"C23-Q070-P255":[23,"U18dle2o"],"C23-Q071-P255":[23,"U1bj1bn6"],"C23-Q072-P255":[23,"U1vnm6gk"],"C23-Q073-P256":[23,"Uwbjwb5"],"C23-Q074-P256":[23,"U1cmzibg"],"C23-Q075-P256":[23,"Ugd7gcj"],"C23-Q076-P256":[23,"U1vyjndv"],"C23-Q077-P256":[23,"Uq8qarr"],"C23-Q078-P257":[23,"U1w7wdk9"],"C23-Q079-P257":[23,"Uhetd7x"],"C23-Q080-P257":[23,"Uufu5t7"],"C23-Q081-P257":[23,"U1sud14y"],"C23-Q082-P257":[23,"U1xqsrj1"],"C23-Q083-P257":[23,"Uw6lc2t"],"C23-Q084-P258":[23,"U18azqub"],"C23-Q085-P258":[23,"Ujgbqln"],"C23-Q086-P258":[23,"U4l1dg"],"C23-Q087-P258":[23,"U734k9k"],"C23-Q088-P258":[23,"U1tbul6a"],"C23-Q089-P259":[23,"Ukrkm13"],"C23-Q090-P259":[23,"Ukmhuxi"],"C23-Q091-P259":[23,"U196t3yh"],"C23-Q092-P259":[23,"Umc9ffv"],"C23-Q093-P259":[23,"U1bg9whc"],"C23-Q094-P259":[23,"U1pbikg9"],"C23-Q095-P260":[23,"U1b8lnvo_1"],"C23-Q096-P260":[23,"U1e61p95"],"C23-Q097-P260":[23,"U1vcyp87"],"C23-Q098-P260":[23,"U1b8lnvo_2"],"C23-Q099-P260":[23,"U18a78xz"],"C23-Q100-P260":[23,"Ubt98xq"],"C23-Q101-P261":[23,"U8n1dov"],"C23-Q102-P261":[23,"Ug2z566"],"C23-Q103-P261":[23,"U1e4gp5y"],"C23-Q104-P261":[23,"U16w1vyj"],"C23-Q105-P261":[23,"U1jh6y4n"],"C23-Q106-P261":[23,"U1soezcw"],"C23-Q107-P261":[23,"U1j0998m"],"C23-Q108-P262":[23,"Uno66lp"],"C23-Q109-P262":[23,"Umg5yyb"],"C23-Q110-P262":[23,"Unid50v"],"C23-Q111-P262":[23,"U18qy5bz"],"C23-Q112-P262":[23,"U6slrxo"],"C23-Q113-P262":[23,"U1eq4i1g"],"C23-Q114-P263":[23,"Ubbh6b2"],"C23-Q115-P263":[23,"Uqq5504"],"C23-Q116-P263":[23,"U14ngl77"],"C23-Q117-P263":[23,"U6jn5vy"],"C23-Q118-P263":[23,"U11ja5n9"],"C23-Q119-P264":[23,"U3wvl40"],"C23-Q120-P264":[23,"Uumwwo6"],"C23-Q121-P264":[23,"Uurynpe"],"C23-Q122-P264":[23,"U1e9im0a"],"C23-Q123-P264":[23,"U6trdxk"],"C23-Q124-P264":[23,"U9dwpqs"],"C23-Q125-P265":[23,"U1gx03wd"],"C23-Q126-P265":[23,"U1t6fdi2"],"C23-Q127-P265":[23,"U1gdczrm"],"C23-Q128-P265":[23,"U14f44zl"],"C23-Q129-P265":[23,"U5a7r1v"],"C23-Q130-P266":[23,"Upe3wbn"],"C23-Q131-P266":[23,"U14oclw"],"C23-Q132-P266":[23,"U13niybl"],"C23-Q133-P266":[23,"U1bgt0xz"],"C23-Q134-P266":[23,"U1dt1uea"],"C23-Q135-P267":[23,"U1dezrct"],"C23-Q136-P267":[23,"U1roa65o"],"C23-Q137-P267":[23,"Unzgach"],"C23-Q138-P267":[23,"U1jbxlm6"],"C23-Q139-P268":[23,"U1iz9r7o"],"C23-Q140-P268":[23,"Uuun850"],"C23-Q141-P268":[23,"U24o97z"],"C23-Q142-P268":[23,"U1ih840b"],"C24-Q001-P269":[24,"Ui5dy1z"],"C24-Q002-P269":[24,"Ui57ezu"],"C24-Q003-P269":[24,"U1s773o6"],"C24-Q004-P270":[24,"U1x2po4o"],"C24-Q005-P270":[24,"U1e0vuin"],"C24-Q006-P270":[24,"U2vycpx"],"C24-Q007-P270":[24,"Uzla8d6"],"C24-Q008-P271":[24,"U6arydp"],"C24-Q009-P271":[24,"Usexx3t"],"C24-Q010-P271":[24,"Uyvf66"],"C24-Q011-P271":[24,"U1rfld5u"],"C24-Q012-P271":[24,"Uzh1fb"],"C24-Q013-P272":[24,"Uwg4qsn"],"C24-Q014-P272":[24,"Upg64yx"],"C24-Q015-P272":[24,"U1ktpv4b"],"C24-Q016-P272":[24,"Uk3b553"],"C24-Q017-P272":[24,"U10ghds"],"C24-Q018-P272":[24,"U1gq4mlw"],"C24-Q019-P272":[24,"Uywas3b"],"C24-Q020-P273":[24,"U1w7loce"],"C24-Q021-P273":[24,"U5i4usj"],"C24-Q022-P273":[24,"Unenfb6"],"C24-Q023-P273":[24,"U1ebrtuf"],"C24-Q024-P273":[24,"U107d7dy"],"C24-Q025-P273":[24,"Uobv7lf"],"C24-Q026-P274":[24,"U1buiw2d"],"C24-Q027-P274":[24,"U1xislly"],"C24-Q028-P274":[24,"Ua1pbse"],"C24-Q029-P274":[24,"U8tnb16"],"C24-Q030-P275":[24,"Ux4b8b5"],"C24-Q031-P275":[24,"Ujp41i1"],"C24-Q032-P275":[24,"Ubqlms4"],"C24-Q033-P275":[24,"U1uwfg8m"],"C24-Q034-P275":[24,"Uzsk57"],"C24-Q035-P276":[24,"Uto6oq9"],"C24-Q036-P276":[24,"U1nycvgn"],"C24-Q037-P276":[24,"U87epyj"],"C24-Q038-P276":[24,"U1q02asf"],"C25-Q001-P277":[25,"U88r349"],"C25-Q002-P277":[25,"Uzm9n6n"],"C25-Q003-P277":[25,"Ut0zaq6"],"C25-Q004-P277":[25,"U3xiz12"],"C25-Q005-P278":[25,"Uq89wkj"],"C25-Q006-P278":[25,"Uz9mqv9"],"C25-Q007-P278":[25,"Us8g4hs"],"C25-Q008-P278":[25,"Uv8xyi"],"C25-Q009-P278":[25,"U7ie6c9"],"C25-Q010-P278":[25,"U1boi7zt"],"C25-Q011-P279":[25,"U1pw6z3l"],"C25-Q012-P279":[25,"U1fyn7yz"],"C25-Q013-P279":[25,"Ul9ai14"],"C25-Q014-P279":[25,"U15e92ef"],"C25-Q015-P279":[25,"U80naaq"],"C25-Q016-P279":[25,"U61o4ss"],"C25-Q017-P280":[25,"U79rmb9"],"C25-Q018-P280":[25,"Ugw6mz"],"C25-Q019-P280":[25,"Uemfj0u"],"C25-Q020-P280":[25,"Uwazs0v"],"C25-Q021-P280":[25,"U1x2ooln"],"C25-Q022-P280":[25,"U3s6b17"],"C25-Q023-P281":[25,"U3m2w27"],"C25-Q024-P281":[25,"U1e8gp01"],"C25-Q025-P281":[25,"Uoszlci"],"C25-Q026-P281":[25,"U8r4i03"],"C25-Q027-P281":[25,"U1dksx8x"],"C25-Q028-P282":[25,"U1l7mi1l"],"C25-Q029-P282":[25,"U1scak88"],"C25-Q030-P282":[25,"U1mokw9b"],"C25-Q031-P282":[25,"Ukelfqk"],"C25-Q032-P282":[25,"U5ep606"],"C25-Q033-P282":[25,"U1isdv4r"],"C25-Q034-P282":[25,"Uykq89k"],"C25-Q035-P283":[25,"U1gzqp4t"],"C25-Q036-P283":[25,"U1pey3c7"],"C25-Q037-P283":[25,"U158xbcm"],"C25-Q038-P283":[25,"U151lyb"],"C25-Q039-P283":[25,"U17g745f"],"C25-Q040-P283":[25,"U1d4soqv"],"C25-Q041-P284":[25,"U1nc4x8y"],"C25-Q042-P284":[25,"Uwejfhx"],"C25-Q043-P284":[25,"U1xdmb5i"],"C25-Q044-P284":[25,"Uuw78ce"],"C25-Q045-P284":[25,"U8uremt"],"C25-Q046-P285":[25,"U47fw77"],"C25-Q047-P285":[25,"Uqjm2k7"],"C25-Q048-P285":[25,"Umq9e1k"],"C25-Q049-P285":[25,"Uajbjjm"],"C25-Q050-P285":[25,"Ujdpaf6"],"C25-Q051-P285":[25,"Ufso5o4"],"C25-Q052-P285":[25,"Uycz6nw"],"C25-Q053-P286":[25,"Undp278"],"C25-Q054-P286":[25,"U18ptuav"],"C25-Q055-P286":[25,"Ub3qxtc"],"C25-Q056-P286":[25,"U1jg6yb5"],"C25-Q057-P287":[25,"Ukfofcx"],"C25-Q058-P287":[25,"U1ltqc3g"],"C25-Q059-P287":[25,"U5xwkzl"],"C25-Q060-P287":[25,"U17cofgk"],"C25-Q061-P287":[25,"Uk5lxo8"],"C25-Q062-P287":[25,"U1mb2e13"],"C25-Q063-P288":[25,"U1mo1cfl"],"C25-Q064-P288":[25,"U1ok8abs"],"C25-Q065-P288":[25,"U10al5qu"],"C25-Q066-P288":[25,"Uaxhga0"],"C25-Q067-P288":[25,"U1q4yiq8"],"C25-Q068-P289":[25,"Ud3cqsi"],"C25-Q069-P289":[25,"Ua479g"],"C25-Q070-P289":[25,"U19j5dm7"],"C25-Q071-P289":[25,"Usfqlsn"],"C25-Q072-P289":[25,"Urcf23q"],"C25-Q073-P290":[25,"Ud56vcm"],"C25-Q074-P290":[25,"Uxbago5"],"C25-Q075-P290":[25,"U1ydnm0b"],"C25-Q076-P290":[25,"U3n3dfx"],"C25-Q077-P291":[25,"U1c8jly4"],"C25-Q078-P291":[25,"U7b0kq4"],"C25-Q079-P291":[25,"U191t5e6"],"C25-Q080-P291":[25,"U165wmgq"],"C25-Q081-P291":[25,"Ucz6haf"],"C25-Q082-P291":[25,"Usfkxm0"],"C25-Q083-P292":[25,"U1qyg0qi"],"C25-Q084-P292":[25,"U1i2dg2r"],"C25-Q085-P292":[25,"Uqjz3sc"],"C25-Q086-P293":[25,"U1dx7cfy"],"C25-Q087-P293":[25,"Umbmymf"],"C25-Q088-P293":[25,"U4jgmp8"],"C25-Q089-P293":[25,"U9b8cs3"],"C25-Q090-P294":[25,"Uxn2clu"],"C25-Q091-P294":[25,"U11xmfiy"],"C25-Q092-P294":[25,"U1rj500"],"C25-Q093-P294":[25,"U1rj500_1"],"C26-Q001-P296":[26,"U1hwdc2u"],"C26-Q002-P296":[26,"Uxqt2du"],"C26-Q003-P296":[26,"Uoy2y24"],"C26-Q004-P296":[26,"Ufc8gsv"],"C26-Q005-P296":[26,"U1iqjwmc"],"C26-Q006-P297":[26,"U1u2cl9o"],"C26-Q007-P297":[26,"U1aols0r"],"C26-Q008-P297":[26,"Ukjodms"],"C26-Q009-P297":[26,"Uqo0ozo"],"C26-Q010-P297":[26,"U1kkz9qi"],"C26-Q011-P298":[26,"U1tfxdda"],"C26-Q012-P298":[26,"Ubmz9rc"],"C26-Q013-P298":[26,"Uk264pb"],"C26-Q014-P298":[26,"Ul50jm2"],"C26-Q015-P298":[26,"U1javu8j"],"C26-Q016-P298":[26,"U1r2irua"],"C26-Q017-P299":[26,"U1w2cztv"],"C26-Q018-P299":[26,"U514cg2"],"C26-Q019-P299":[26,"Urq10l2"],"C26-Q020-P299":[26,"U1jlay9a"],"C26-Q021-P300":[26,"U1mydpv2"],"C26-Q022-P300":[26,"U1cgmdrt"],"C26-Q023-P300":[26,"Uet288j"],"C26-Q024-P300":[26,"U1nye8zf"],"C26-Q025-P300":[26,"Uogp8v2"],"C26-Q026-P300":[26,"U1m9b48"],"C26-Q027-P301":[26,"U10xsni3"],"C26-Q028-P301":[26,"U13c4ri2"],"C26-Q029-P301":[26,"Ud351qy"],"C26-Q030-P302":[26,"U10gg3z6"],"C26-Q031-P302":[26,"Udvs9jb"],"C26-Q032-P302":[26,"U1m748de"],"C26-Q033-P302":[26,"Uh8wb35"],"C26-Q034-P302":[26,"U18rbk2i"],"C26-Q035-P302":[26,"U1jifjuu"],"C26-Q036-P303":[26,"U1lfdoqf"],"C26-Q037-P303":[26,"U1xc6ooh"],"C26-Q038-P303":[26,"U1fzs0ew"],"C26-Q039-P303":[26,"U1g8s7kg"],"C26-Q040-P303":[26,"Uq3xdju"],"C26-Q041-P303":[26,"U1sksemw"],"C26-Q042-P304":[26,"U1gfxvn9"],"C26-Q043-P304":[26,"U1acjosj"],"C26-Q045-P304":[26,"U1op123a"],"C26-Q046-P304":[26,"U1nj48sw"],"C26-Q047-P305":[26,"U1fododq"],"C26-Q048-P305":[26,"Umm96no"],"C26-Q049-P305":[26,"U1u4d1ny"],"C26-Q050-P305":[26,"Uy8ay3s"],"C26-Q051-P305":[26,"U19ce1r0"],"C26-Q052-P305":[26,"U177j9xs"],"C26-Q053-P306":[26,"U9uu6fm"],"C26-Q054-P306":[26,"U1asjvoe"],"C26-Q055-P306":[26,"Uowdoyj"],"C26-Q056-P306":[26,"U1evp2qo"],"C26-Q057-P306":[26,"U8hkoni"],"C26-Q058-P307":[26,"U1tf9oh2"],"C26-Q059-P307":[26,"U105zqj"],"C26-Q060-P307":[26,"Ukizbdd"],"C26-Q061-P307":[26,"Uz2hm7i"],"C26-Q062-P307":[26,"Uyecob0"],"C26-Q063-P308":[26,"U134hml8"],"C26-Q064-P308":[26,"Uv9g4l2"],"C26-Q065-P308":[26,"U1clqiqm"],"C26-Q066-P308":[26,"Uuw3fw"],"C26-Q067-P308":[26,"U1x5hd0e"],"C26-Q068-P308":[26,"U43fh1k"],"C26-Q069-P309":[26,"U6vc3xg"],"C26-Q070-P309":[26,"U17evta2"],"C26-Q071-P309":[26,"U1xugspg"],"C26-Q072-P309":[26,"Ubtmw"],"C26-Q073-P309":[26,"U1mjyqie"],"C26-Q074-P310":[26,"Untjz6s"],"C26-Q075-P310":[26,"U9g7c52"],"C26-Q076-P310":[26,"U7nhrs9"],"C26-Q077-P310":[26,"Unc5cfj"],"C26-Q078-P310":[26,"Uzxz5my"],"C26-Q079-P310":[26,"U1giou1x"],"C26-Q080-P310":[26,"U1feern7"],"C26-Q081-P310":[26,"U176bnho"],"C26-Q082-P311":[26,"U1o1duic"],"C26-Q083-P311":[26,"U1purkgj"],"C26-Q084-P311":[26,"U15j20be"],"C26-Q085-P311":[26,"U130533u"],"C26-Q086-P311":[26,"U1ksg1zg"],"C26-Q087-P312":[26,"Uabz61q"],"C26-Q088-P312":[26,"Utg16fd"],"C26-Q089-P312":[26,"U144unxk"],"C26-Q090-P312":[26,"U1x39p35"],"C26-Q091-P312":[26,"Uszrktj"],"C26-Q092-P313":[26,"U1h4y3rf"],"C26-Q093-P313":[26,"Uqesy8x"],"C26-Q094-P313":[26,"U4atghd"],"C26-Q095-P313":[26,"Ucs133r"],"C26-Q096-P314":[26,"Uuiuupk"],"C26-Q097-P314":[26,"U1lm5wsa"],"C26-Q098-P314":[26,"Uxh23wn"],"C26-Q099-P314":[26,"U1qooz1d"],"C26-Q100-P314":[26,"Uhl56t9"],"C26-Q101-P314":[26,"Uy6wjmj"],"C26-Q102-P315":[26,"U1e1yhc0"],"C26-Q103-P315":[26,"U14bcjm"],"C26-Q104-P315":[26,"U1mb1fnj"],"C26-Q105-P315":[26,"Ux0qnyk"],"C26-Q106-P316":[26,"U1d20t4k"],"C26-Q107-P316":[26,"Uw3aj99"],"C26-Q108-P316":[26,"U1e88owd"],"C26-Q109-P316":[26,"U1mgjowg"],"C26-Q110-P316":[26,"U1ttbbvm"],"C26-Q111-P316":[26,"U1b8v4gx"],"C26-Q112-P317":[26,"U9wqp72"],"C26-Q113-P317":[26,"U1nxlinv"],"C26-Q114-P317":[26,"U2222dv"],"C26-Q115-P317":[26,"U1bmozv1"],"C26-Q116-P317":[26,"Um1l4z"],"C26-Q117-P318":[26,"U1qccj2m"],"C26-Q118-P318":[26,"U1ra5spw"],"C26-Q119-P318":[26,"Uzpimud"],"C26-Q120-P318":[26,"Uxo3ndj"],"C26-Q121-P318":[26,"Uyezvd1"],"C26-Q122-P319":[26,"U16a072e"],"C26-Q123-P319":[26,"Uy3rhw7"],"C26-Q124-P319":[26,"Uh2hols"],"C26-Q125-P319":[26,"Ur37hdb"],"C26-Q126-P319":[26,"U1xpacmu"],"C26-Q127-P319":[26,"U1nwuz1n"],"C27-Q001-P320":[27,"Urbobyo"],"C27-Q002-P321":[27,"U52yef"],"C27-Q003-P321":[27,"Uwma8bn"],"C27-Q004-P321":[27,"U1o02611"],"C27-Q005-P321":[27,"U1w1nn0r"],"C27-Q006-P321":[27,"U3ldou5"],"C27-Q007-P321":[27,"U16zxz8j"],"C27-Q008-P321":[27,"U179w5pm"],"C27-Q009-P322":[27,"U5xg65k"],"C27-Q010-P322":[27,"U16zgpgl"],"C27-Q011-P322":[27,"U10spdqo"],"C27-Q012-P322":[27,"Uwx71oc"],"C27-Q013-P323":[27,"Uaml6np"],"C27-Q014-P323":[27,"U149amzm"],"C27-Q015-P323":[27,"U2r4x95"],"C27-Q016-P323":[27,"Uge5pq5"],"C27-Q017-P323":[27,"Ucrggnd"],"C27-Q018-P323":[27,"U1qlaney"],"C27-Q019-P324":[27,"Ulqla48"],"C27-Q020-P324":[27,"U1fai99x"],"C27-Q021-P324":[27,"U6glmdn"],"C27-Q022-P324":[27,"U4230yp"],"C27-Q023-P324":[27,"U1jh0mej"],"C27-Q024-P325":[27,"U1i7atpd"],"C27-Q025-P325":[27,"U1qg5mwo"],"C27-Q026-P325":[27,"U18muz0d"],"C27-Q027-P325":[27,"Ux8vsk4"],"C27-Q028-P326":[27,"U12uy9t4"],"C27-Q029-P326":[27,"U166nks"],"C27-Q030-P326":[27,"Ufrkfyq"],"C27-Q031-P326":[27,"Uaorw4f"],"C27-Q032-P326":[27,"Uapl088"],"C27-Q033-P326":[27,"U1t0jm17"],"C27-Q034-P327":[27,"Upsk4ii"],"C27-Q035-P327":[27,"U18plecy"],"C27-Q036-P327":[27,"Ugrwfcf"],"C27-Q037-P327":[27,"U1d2g44m"],"C27-Q038-P327":[27,"U19ro42v"],"C27-Q039-P327":[27,"Uxu3b3h"],"C27-Q040-P328":[27,"Uw6ui50"],"C27-Q041-P328":[27,"U8se2ye"],"C27-Q042-P328":[27,"U1iew1py"],"C27-Q043-P328":[27,"U1whoidp"],"C27-Q044-P329":[27,"U1hnlxe8"],"C27-Q045-P329":[27,"Ukganni"],"C27-Q046-P329":[27,"U16nm04h"],"C27-Q047-P329":[27,"U1dbjcc5"],"C27-Q048-P329":[27,"U5p0g8a"],"C27-Q049-P330":[27,"U1annva8"],"C27-Q050-P330":[27,"U3didyr"],"C27-Q051-P330":[27,"U1ka622c"],"C27-Q052-P330":[27,"U1sj9w1s"],"C27-Q053-P330":[27,"U120yyve"],"C27-Q054-P330":[27,"U16aulp3"],"C27-Q055-P331":[27,"Uwt0x65"],"C27-Q056-P331":[27,"Uumr92l"],"C28-Q001-P332":[28,"Urqzifv"],"C28-Q002-P332":[28,"U1csryj"],"C28-Q003-P332":[28,"Uivjmn0"],"C28-Q004-P333":[28,"Upgc5ts"],"C28-Q005-P333":[28,"U1d2tdt6"],"C28-Q006-P333":[28,"U1r1ax7s"],"C28-Q007-P333":[28,"U13rdzim"],"C28-Q008-P333":[28,"Ua6si61"],"C28-Q009-P333":[28,"U1x0j9jv"],"C28-Q010-P333":[28,"U9r0j8f"],"C28-Q011-P334":[28,"Uwf3rby"],"C28-Q012-P334":[28,"Uc68iyb"],"C28-Q013-P334":[28,"Ufiuqz7"],"C28-Q014-P334":[28,"U1dnw1wv"],"C28-Q015-P334":[28,"U4n8phr"],"C28-Q016-P335":[28,"Uivk65h"],"C28-Q017-P335":[28,"U1aom48p"],"C28-Q018-P335":[28,"U1vmd70p"],"C28-Q019-P335":[28,"U4sxn2q"],"C28-Q020-P335":[28,"Utjnki8"],"C28-Q021-P335":[28,"U1uzoq4z"],"C28-Q022-P335":[28,"U13x0tyh"],"C28-Q023-P336":[28,"U1cjmmj6"],"C28-Q024-P336":[28,"U1itxgih"],"C28-Q025-P336":[28,"Um49r9r"],"C28-Q026-P336":[28,"Uxqyhtr"],"C28-Q027-P336":[28,"Ut1x98b"],"C28-Q028-P336":[28,"Ucw5nlm"],"C28-Q029-P337":[28,"U1qdi7rp"],"C28-Q030-P337":[28,"U1q2omdd"],"C28-Q031-P337":[28,"U1shawwo"],"C28-Q032-P337":[28,"U86dmf9"],"C28-Q033-P337":[28,"U1ihe9aj"],"C28-Q034-P337":[28,"Uj4bgru"],"C28-Q035-P337":[28,"U1hnv2lk"],"C28-Q036-P338":[28,"U17x6qi2"],"C28-Q037-P338":[28,"Ux56mo1"],"C28-Q038-P338":[28,"U12n19hr"],"C28-Q039-P338":[28,"U1qpmr8j"],"C28-Q040-P338":[28,"Uepce03"],"C28-Q041-P338":[28,"U2ui3er"],"C28-Q042-P339":[28,"Uancg94"],"C28-Q043-P339":[28,"Uj6tiwf"],"C28-Q044-P339":[28,"U16fsafu"],"C28-Q045-P339":[28,"Ufmzace"],"C28-Q046-P339":[28,"U72ab62"],"C28-Q047-P339":[28,"U83it42"],"C28-Q048-P340":[28,"U1a241a9"],"C28-Q049-P340":[28,"U1f44bs9"],"C28-Q050-P340":[28,"U1qovkcw"],"C28-Q051-P340":[28,"Uudk72x"],"C28-Q052-P341":[28,"Ub0j0li"],"C28-Q053-P341":[28,"U1tgb862"],"C28-Q054-P341":[28,"Uj762bw"],"C28-Q055-P341":[28,"U59vj0u"],"C28-Q056-P341":[28,"U12xpg13"],"C28-Q057-P341":[28,"U6g2cc6"],"C28-Q058-P342":[28,"U1539fsq"],"C28-Q059-P342":[28,"Ui8c9hc"],"C28-Q060-P342":[28,"U1dy3zxo"],"C28-Q061-P342":[28,"Ug5drco"],"C28-Q062-P342":[28,"U1gmlyyb"],"C28-Q063-P342":[28,"U1m1cyjf"],"C28-Q064-P343":[28,"U1x88sf"],"C28-Q065-P343":[28,"U178ptxj"],"C28-Q066-P343":[28,"Udcq2ym"],"C28-Q067-P343":[28,"U9g274q"],"C28-Q068-P343":[28,"U9vsd2u"],"C28-Q069-P343":[28,"U1dew4v0"],"C28-Q070-P343":[28,"Uvenyzf"],"C28-Q071-P344":[28,"U1lwojfo"],"C28-Q072-P344":[28,"U18pyqw7"],"C28-Q073-P344":[28,"U5gu230"],"C28-Q074-P344":[28,"U3oprw0"],"C28-Q075-P345":[28,"U6f9lom"],"C28-Q076-P345":[28,"U1rolf11"],"C28-Q077-P345":[28,"Uz2a6zo"],"C28-Q078-P345":[28,"U1q22cn6"],"C28-Q079-P345":[28,"Uzz3zxf"],"C28-Q080-P345":[28,"Ug9gkqr"],"C28-Q081-P346":[28,"Utrshf0"],"C28-Q082-P346":[28,"Uk4m6xw"],"C28-Q083-P346":[28,"U1d55qmt"],"C28-Q084-P346":[28,"U1krejt2"],"C28-Q085-P346":[28,"Um46yf2"],"C28-Q086-P346":[28,"U1lhw33j"],"C29-Q001-P348":[29,"U1xj7phu"],"C29-Q002-P348":[29,"Uh9l6d"],"C29-Q003-P348":[29,"U1vo2b6y"],"C29-Q004-P348":[29,"U12cn32a"],"C29-Q005-P348":[29,"U1xmbrxt"],"C29-Q006-P349":[29,"U1tlcgru"],"C29-Q007-P349":[29,"U1benb08"],"C29-Q008-P349":[29,"Um3p73v"],"C29-Q009-P349":[29,"U170xss1"],"C29-Q010-P349":[29,"Uoi3bmn"],"C29-Q011-P349":[29,"Uvluf4u"],"C29-Q012-P349":[29,"U1eopz56"],"C29-Q013-P350":[29,"Uzmh096"],"C29-Q014-P350":[29,"U1a3il0c"],"C29-Q015-P350":[29,"U429lee"],"C29-Q016-P350":[29,"U1f4zgf5"],"C29-Q017-P350":[29,"U1z056ln"],"C29-Q018-P350":[29,"U107148m"],"C29-Q019-P350":[29,"U1vampu8"],"C29-Q020-P351":[29,"U1up3ni6"],"C29-Q021-P351":[29,"U16boite"],"C29-Q022-P351":[29,"U1s7c2u7"],"C29-Q023-P351":[29,"U1iuedq1"],"C29-Q024-P351":[29,"U1rytng"],"C29-Q025-P352":[29,"Uh7pq8l"],"C29-Q026-P352":[29,"U1urk4v9"],"C29-Q027-P352":[29,"U11jts05"],"C29-Q028-P352":[29,"U1c30awc"],"C29-Q029-P353":[29,"U4hhjl4"],"C29-Q030-P353":[29,"U1k34kt8"],"C29-Q031-P353":[29,"Ucmh3if"],"C29-Q032-P353":[29,"U1fpr07s"],"C29-Q033-P353":[29,"Up643rv"],"C29-Q034-P353":[29,"U14unxyj"],"C29-Q035-P353":[29,"Un0pki6"],"C29-Q036-P353":[29,"U1fwmpom"],"C29-Q037-P354":[29,"U135sgwc"],"C29-Q038-P354":[29,"U1afmaoq"],"C29-Q039-P354":[29,"U19ngrd7"],"C29-Q040-P355":[29,"Uncumxn"],"C29-Q041-P355":[29,"Uo3ftyu"],"C29-Q042-P355":[29,"Uhc4n4m"],"C29-Q043-P355":[29,"U5eyfx0"],"C30-Q001-P357":[30,"Ux9omf5"],"C30-Q002-P357":[30,"Uq7c19l"],"C30-Q003-P357":[30,"Uuqefyv"],"C30-Q004-P357":[30,"U1e5okat"],"C30-Q005-P357":[30,"U4miavd"],"C30-Q006-P358":[30,"Ugamtx7"],"C30-Q007-P358":[30,"Ucguri1"],"C30-Q008-P358":[30,"U1eydqc6"],"C30-Q009-P358":[30,"U1c22eix"],"C30-Q010-P358":[30,"U14478pl"],"C30-Q011-P358":[30,"Ubbuly7"],"C30-Q012-P359":[30,"U9cj7bj"],"C30-Q013-P359":[30,"U17e8de8"],"C30-Q014-P359":[30,"U1xhq12z"],"C30-Q015-P359":[30,"U5p98nk"],"C30-Q016-P359":[30,"U1vd3enu"],"C30-Q017-P359":[30,"U1vm69ro"],"C30-Q018-P359":[30,"Us15bgx"],"C30-Q019-P360":[30,"Uz59qvv"],"C30-Q020-P360":[30,"U1w0dawq"],"C30-Q021-P360":[30,"Uz25017"],"C30-Q022-P360":[30,"Ukcki7b"],"C30-Q023-P360":[30,"U1i9g2fj"],"C30-Q024-P360":[30,"Uw05lac"],"C30-Q025-P360":[30,"Umolq4f"],"C30-Q026-P361":[30,"Ujj10t6"],"C30-Q027-P361":[30,"U1iw21mq"],"C30-Q028-P361":[30,"U1nfttb2"],"C30-Q029-P362":[30,"U3gnapd"],"C30-Q030-P362":[30,"U1poq1sf"],"C30-Q031-P362":[30,"U1abheuf"],"C30-Q032-P362":[30,"U1h6qinj"],"C30-Q033-P362":[30,"U33hg38"],"C30-Q034-P362":[30,"U1g699zy"],"C30-Q035-P362":[30,"U10a05lc"],"C30-Q036-P362":[30,"U1338f5d"],"C30-Q037-P363":[30,"Udvx9bm"],"C30-Q038-P363":[30,"Ua8y70p"],"C30-Q039-P363":[30,"U1w6stbp"],"C30-Q040-P363":[30,"U8j9skh"],"C30-Q041-P364":[30,"U1euqjq"],"C30-Q042-P364":[30,"U1n0g614"],"C30-Q043-P364":[30,"U18x34ka"],"C30-Q044-P364":[30,"Uy8g55h"],"C30-Q045-P365":[30,"U13wt2ol"],"C30-Q046-P365":[30,"Ugc2n0d"],"C30-Q047-P365":[30,"U1h2e1wu"],"C30-Q048-P365":[30,"U1hn5a3y"],"C30-Q049-P365":[30,"U1wluwu1"],"C30-Q050-P365":[30,"Ulb0rao"],"C30-Q051-P366":[30,"Uti70rp"],"C30-Q052-P366":[30,"Uh5xheo"],"C30-Q053-P366":[30,"Umhtgu"],"C30-Q054-P366":[30,"U1kwhyen"],"C30-Q055-P366":[30,"Uc1c9hn"],"C30-Q056-P366":[30,"U1ewb1mp"],"C30-Q057-P367":[30,"U16ki6k8"],"C30-Q058-P367":[30,"Um2xgdw"],"C31-Q001-P368":[31,"U8v29sa"],"C31-Q002-P368":[31,"Ulxvtcu"],"C31-Q003-P369":[31,"U1n1bb5"],"C31-Q004-P369":[31,"Uvgvbp2"],"C31-Q005-P369":[31,"U4wxzu0"],"C31-Q006-P369":[31,"Ujl74nd"],"C31-Q007-P369":[31,"U19iuq82"],"C31-Q008-P369":[31,"U1t22x48"],"C31-Q009-P370":[31,"U1kq7fue"],"C31-Q010-P370":[31,"U1n9ef52"],"C31-Q011-P370":[31,"U1f61qnn"],"C31-Q012-P370":[31,"Uqyoc7d"],"C31-Q013-P370":[31,"U1jy3w1p"],"C31-Q014-P371":[31,"Uq4letz"],"C31-Q015-P371":[31,"U8evf4u"],"C31-Q016-P371":[31,"U1fz061z"],"C31-Q017-P371":[31,"U15ej9wa"],"C31-Q018-P371":[31,"Uxflnmt"],"C31-Q019-P371":[31,"U1an5h2b"],"C31-Q020-P372":[31,"U1pownw9"],"C31-Q021-P372":[31,"U15yq4zi"],"C31-Q022-P372":[31,"U1tq14ju"],"C31-Q023-P372":[31,"U1rvnaxt"],"C31-Q024-P372":[31,"U1cr55ja"],"C31-Q025-P373":[31,"Uoz8qwn"],"C31-Q026-P373":[31,"Up0cd07"],"C31-Q027-P373":[31,"U1drlall"],"C31-Q028-P373":[31,"U1shbmik"],"C31-Q029-P373":[31,"U1nzdizk"],"C31-Q030-P373":[31,"Ufnea4p"],"C31-Q031-P374":[31,"U6u4x2d"],"C31-Q032-P374":[31,"U1qjvfjd"],"C31-Q033-P374":[31,"Udzs8du"],"C31-Q034-P374":[31,"Uaaa4tq"],"C31-Q035-P374":[31,"U17ntzif"],"C31-Q036-P375":[31,"U12kyti"],"C31-Q037-P375":[31,"U4lp6vn"],"C31-Q038-P375":[31,"U7bbgqf"],"C31-Q039-P375":[31,"U1dcucav"],"C32-Q001-P376":[32,"Ujcqk6m"],"C32-Q002-P376":[32,"Uhnqg8n"],"C32-Q003-P376":[32,"U1xs6rog"],"C32-Q004-P376":[32,"U1tirre9"],"C32-Q005-P376":[32,"Uaxjrzo"],"C32-Q006-P376":[32,"Uc9ua5z"],"C32-Q007-P376":[32,"Udwqssc"],"C32-Q008-P377":[32,"U1e4frcx"],"C32-Q009-P377":[32,"U1b7p0iw"],"C32-Q010-P377":[32,"Ufiy8pe"],"C32-Q011-P377":[32,"U8vrfm0"],"C32-Q012-P377":[32,"U1qo6g6g"],"C32-Q013-P377":[32,"U19mjpd0"],"C32-Q014-P377":[32,"Uwe1uyp"],"C32-Q015-P378":[32,"U1kodo5w"],"C32-Q016-P378":[32,"U1d01pph"],"C32-Q017-P378":[32],"C32-Q018-P378":[32,"Uwli452"],"C32-Q019-P379":[32,"Ur0cau7"],"C32-Q020-P379":[32,"Ukjplvo"],"C32-Q021-P379":[32,"U64sn96"],"C32-Q022-P379":[32,"Uomt4vq"],"C32-Q023-P379":[32,"Uosnxm"],"C32-Q024-P379":[32,"Uh22t0w"],"C32-Q025-P379":[32,"U3hzsol"],"C32-Q026-P380":[32,"U151l89l"],"C32-Q027-P380":[32,"Ub42com"],"C32-Q028-P380":[32,"U1iaw67f"],"C32-Q029-P380":[32,"Ua0rfai"],"C32-Q030-P380":[32,"U1wgtn7u"],"C33-Q001-P381":[33,"Uqyn41h"],"C33-Q002-P381":[33,"U15x549z"],"C33-Q003-P381":[33,"U6q8hyk"],"C33-Q004-P381":[33,"Up5gloq"],"C33-Q005-P381":[33,"U1tmfcqc"],"C33-Q006-P381":[33,"U1k1bun5"],"C33-Q007-P382":[33,"U15odg3x"],"C33-Q008-P382":[33,"Uzrg40b"],"C33-Q009-P382":[33,"Umyloyr"],"C33-Q010-P382":[33,"U1d3jbyx"],"C33-Q011-P382":[33,"U1b5se4n"],"C33-Q012-P382":[33,"U1b5se4n_1"],"C33-Q013-P382":[33,"Un825z6"],"C33-Q014-P383":[33,"U1b5se4n_2"],"C33-Q015-P383":[33,"U6bdjea"],"C33-Q016-P383":[33,"U190r291"],"C33-Q017-P383":[33,"U1l24fx1"],"C33-Q018-P383":[33,"Uotbywg"],"C33-Q019-P383":[33,"U1d14tuu"],"C33-Q020-P383":[33,"U1mpfozk"],"C33-Q021-P383":[33,"Uglsk3f"],"C33-Q022-P384":[33,"U25nspy"],"C33-Q023-P384":[33,"U18br9mx"],"C33-Q024-P384":[33,"Ut6io15"],"C33-Q025-P384":[33,"Uoc1zpd"],"C33-Q026-P384":[33,"U12pi0k8"],"C33-Q027-P384":[33,"U1qbcich"],"C33-Q028-P385":[33,"U1rjf4nw"],"C33-Q029-P385":[33,"U1a9kyqw"],"C33-Q030-P385":[33,"U1iukaih"],"C33-Q031-P385":[33,"U305jtg"],"C33-Q032-P385":[33,"Udda5fk"],"C33-Q033-P386":[33,"U17s0glz"],"C33-Q034-P386":[33,"Ua1cgn"],"C33-Q035-P386":[33,"U1wpxpck"],"C34-Q001-P387":[34,"U139lmwk"],"C34-Q002-P387":[34,"U1wrvd0b"],"C34-Q003-P387":[34,"U9fniv4"],"C34-Q004-P388":[34,"U190kqkh"],"C34-Q005-P388":[34,"Ug9kzl4"],"C34-Q006-P388":[34,"Uplt7eu"],"C34-Q007-P388":[34,"Ugolkko"],"C34-Q008-P388":[34,"U1wvi3qh"],"C34-Q009-P389":[34,"U9tnsfn"],"C34-Q010-P389":[34,"U1hw4alf"],"C34-Q011-P389":[34,"Ukhlum4"],"C34-Q012-P389":[34,"U1l8kd7k"],"C34-Q013-P389":[34,"U1svcyv"],"C34-Q014-P389":[34,"Us7bcu1"],"C34-Q015-P389":[34,"Uq2gyfa"],"C34-Q016-P390":[34,"U102ivib"],"C34-Q017-P390":[34,"U1uqcd9i"],"C34-Q018-P390":[34,"Uni51jw"],"C34-Q019-P390":[34,"U8k224p"],"C34-Q020-P390":[34,"U1w8dhfm"],"C34-Q021-P390":[34,"Uzcvajr"],"C34-Q022-P390":[34,"U659fpy"],"C34-Q023-P391":[34,"Uihjlqh"],"C34-Q024-P391":[34,"Uc4d3ov"],"C34-Q025-P391":[34,"Uyhv3ig"],"C34-Q026-P391":[34,"Ua2doju"],"C34-Q027-P392":[34,"Ux4rnnl"],"C34-Q028-P392":[34,"U1jvtm4w"],"C34-Q029-P392":[34,"U1cyxxwl"],"C34-Q030-P392":[34,"U6kjmc"],"C34-Q031-P392":[34,"U1m4u1cg"],"C34-Q032-P392":[34,"U1nfe5gp"],"C34-Q033-P393":[34,"U11zf01m"],"C34-Q034-P393":[34,"U19j62by"],"C34-Q035-P393":[34,"Ufhfb71"],"C34-Q036-P393":[34,"U8nzros"],"C34-Q037-P393":[34,"Umod531"],"C34-Q038-P393":[34,"U1a3hvn0"],"C34-Q039-P394":[34,"U4kapxi"],"C34-Q040-P394":[34,"U1eqdpki"],"C34-Q041-P394":[34,"Uxbg9jd"],"C34-Q042-P394":[34,"Uhqa9ax"],"C34-Q043-P394":[34,"U1fnff7z"],"C34-Q044-P395":[34,"U1ucuo1b"],"C34-Q045-P395":[34,"U1lpopjh"],"C34-Q046-P395":[34,"U10080m2"],"C34-Q047-P395":[34,"Uj0wwn0"],"C34-Q048-P395":[34,"U1ikov2b"],"C34-Q049-P395":[34,"U1m79io8"],"C34-Q050-P396":[34,"U1ezsqbp"],"C34-Q051-P396":[34,"Uatnb9e"],"C34-Q052-P396":[34,"Urcx43y"],"C34-Q053-P396":[34,"Uhchrpz"],"C34-Q054-P396":[34,"U6gdu92"],"C34-Q055-P396":[34,"Uees8zd"],"C34-Q056-P397":[34,"Uo5cqon"],"C34-Q057-P397":[34,"Ubzpyxw"],"C34-Q058-P397":[34,"U1grcm1g"],"C34-Q059-P397":[34,"U1osc48q"],"C34-Q060-P397":[34,"U1tbvxn3"],"C34-Q061-P398":[34,"U4vl0aa"],"C34-Q062-P398":[34,"U2qg0q4"],"C34-Q063-P398":[34,"Uwg1iya"],"C34-Q064-P398":[34,"Uhwaxoj"],"C34-Q065-P398":[34,"U1eo1dks"],"C34-Q066-P398":[34,"U10o029j"],"C34-Q067-P399":[34,"Ul0u1iz"],"C34-Q068-P399":[34,"U1ksnben"],"C34-Q069-P399":[34,"U1iwgqsg"],"C34-Q070-P399":[34,"U8h4s9"],"C34-Q071-P399":[34,"Ut91bos"],"C34-Q072-P399":[34,"U1ia853t"],"C34-Q073-P400":[34,"U6z02sq"],"C34-Q074-P400":[34,"U1hw339q"],"C34-Q075-P400":[34,"U8gmgf8"],"C34-Q076-P400":[34,"U1orgc2v"],"C34-Q077-P400":[34,"U116htr7"],"C34-Q078-P400":[34,"Ubhvfjw"],"C34-Q079-P401":[34,"U1ah36mt"],"C34-Q080-P401":[34,"U1duax6r"],"C34-Q081-P401":[34,"U1dcdx7n"],"C34-Q082-P401":[34,"U1yqlku0"],"C34-Q083-P401":[34,"U1vrlhdp"],"C34-Q084-P401":[34,"U1wx8ipi"],"C34-Q085-P402":[34,"U10umg49"],"C34-Q086-P402":[34,"U6h6ym3"],"C34-Q087-P402":[34,"U1o33419"],"C34-Q088-P402":[34,"U1eef2bm"],"C34-Q089-P402":[34,"U1eqrv0v"],"C34-Q090-P402":[34,"U1u48ka4"],"C34-Q091-P403":[34,"Ukaf7sn"],"C34-Q092-P403":[34,"U13uuciz"],"C34-Q093-P403":[34,"Ua542cy"],"C34-Q094-P403":[34,"U17zp4uo"],"C34-Q095-P403":[34,"Uok8pt1"],"C34-Q096-P404":[34,"Uiv752z"],"C34-Q097-P404":[34,"U1muvu6m"],"C34-Q098-P404":[34,"Uf5c6lm"],"C34-Q099-P404":[34,"U1pn4d13"],"C34-Q100-P404":[34,"Ua1y6p4"],"C34-Q101-P404":[34,"Uc75d58"],"C34-Q102-P404":[34,"U17ptw58"],"C34-Q103-P405":[34,"Uaqb528"],"C34-Q104-P405":[34,"U1lpfqoe"],"C34-Q105-P405":[34,"U1ddcm4n"],"C34-Q106-P405":[34,"U1kzp3ux"],"C34-Q107-P405":[34,"U4vkte2"],"C34-Q108-P406":[34,"U1r7zvf4"],"C34-Q109-P406":[34,"U1jpu6dn"],"C34-Q110-P406":[34,"U1k5yhlf"],"C34-Q111-P406":[34,"U8vs8cg"],"C34-Q112-P406":[34,"U1pgco4l"],"C34-Q113-P406":[34,"Uac9a2j"],"C34-Q114-P406":[34,"Urkwfnl"],"C34-Q115-P407":[34,"U1v6auoz"],"C34-Q116-P407":[34,"Udq05j7"],"C34-Q117-P407":[34,"U1hf47gc"],"C34-Q118-P407":[34,"Utr2a5b"],"C34-Q119-P407":[34,"Urwobbz"],"C34-Q120-P407":[34,"U1do4ihr"],"C34-Q121-P407":[34,"U139vi9w"],"C34-Q122-P408":[34,"Ufqk3b2"],"C34-Q123-P408":[34,"Upmrda3"],"C35-Q001-P408":[35,"U1e6hv10"],"C35-Q002-P408":[35,"U1rkcqdg"],"C35-Q003-P408":[35,"Uf88flk"],"C35-Q004-P408":[35,"U1l34k0a"],"C35-Q005-P409":[35,"U7t36j2"],"C35-Q006-P409":[35,"U1akdztv"],"C35-Q007-P409":[35,"U7ofrej"],"C35-Q008-P409":[35,"U1kmxd40"],"C35-Q009-P409":[35,"Uxgfr1l"],"C35-Q010-P409":[35,"U1lh1b48"],"C35-Q011-P410":[35,"U19zzp61"],"C35-Q012-P410":[35,"U13zihf1"],"C35-Q014-P410":[35,"Uu0hrrb"],"C36-Q001-P412":[36,"U8lwonk"],"C36-Q002-P412":[36,"U1v9f4g8"],"C36-Q003-P412":[36,"U1boiy02"],"C36-Q004-P412":[36,"U1dz3onf"],"C36-Q005-P413":[36,"U1q39g6t"],"C36-Q006-P413":[36,"U95ax2d"],"C36-Q007-P413":[36,"U1t91jkp"],"C36-Q008-P414":[36,"Umtqeim"],"C36-Q009-P414":[36,"U1roz7t6"],"C36-Q010-P414":[36,"U596m81"],"C36-Q011-P414":[36,"Ul7liwr"],"C36-Q012-P414":[36,"U1bfia5x"],"C36-Q013-P415":[36,"U1p9xqjs"],"C36-Q014-P415":[36,"U11tlps4"],"C36-Q015-P415":[36,"U1e8y5ct"],"C36-Q016-P415":[36,"U1rdnftc"],"C36-Q017-P415":[36,"U1yt5rru"],"C36-Q018-P416":[36,"U1p5159o"],"C36-Q019-P416":[36,"Ugd62u1"],"C36-Q020-P416":[36,"Ueinijv"],"C36-Q021-P416":[36,"U10hxqlq"],"C36-Q022-P416":[36,"U1sb5svo"],"C36-Q023-P417":[36,"Uwvi9j6"],"C36-Q024-P417":[36,"Uh7gapt"],"C36-Q025-P417":[36,"Ulmu3fx"],"C36-Q026-P417":[36,"U142w76g"],"C36-Q027-P417":[36,"U1rti8gq"],"C36-Q028-P417":[36,"Ukpmiuc"],"C36-Q029-P418":[36,"Udssx63"],"C36-Q030-P418":[36,"Ubeypsv"],"C36-Q031-P418":[36,"U1je2kr2"],"C36-Q032-P418":[36,"Urs1vjv"],"C36-Q033-P418":[36,"U4ohypz"],"C36-Q034-P418":[36,"U1r7g430"],"C36-Q035-P419":[36,"Uq7q7pr"],"C36-Q036-P419":[36,"U3v9euq"],"C36-Q037-P419":[36,"U1e0n9i5"],"C36-Q038-P419":[36,"Utvgl5u"],"C36-Q039-P419":[36,"U13p5is7"],"C36-Q040-P419":[36,"Upon6bv"],"C36-Q041-P419":[36,"U1ary5yx"],"C36-Q042-P420":[36,"U1h8fevl"],"C36-Q043-P420":[36,"U3613ni"],"C36-Q044-P420":[36,"Ulw8qhj"],"C36-Q045-P420":[36,"Ufiqpfu"],"C36-Q046-P421":[36,"U20de90"],"C36-Q047-P421":[36,"Usmw3z4"],"C36-Q048-P421":[36,"Uwfxroz"],"C36-Q049-P421":[36,"U13opi7v"],"C36-Q050-P421":[36,"U1dv74zn"],"C36-Q051-P422":[36,"U1ceahww"],"C36-Q052-P422":[36,"Uup3t6d"],"C36-Q053-P422":[36,"U549bcm"],"C36-Q054-P422":[36,"U1qu7owq"],"C36-Q055-P423":[36,"Uxow8ge"],"C36-Q056-P423":[36,"Ujdi3wl"],"C36-Q057-P423":[36,"Uesa1l2"],"C36-Q058-P423":[36,"Uvlv8th"],"C36-Q059-P423":[36,"Utzbipq"],"C36-Q060-P424":[36,"Ukydssv"],"C36-Q061-P424":[36,"U1i1uhrx"],"C36-Q062-P424":[36,"Urw5kzu"],"C36-Q063-P424":[36,"Uatdn2j"],"C37-Q001-P424":[37,"U1c5befn"],"C37-Q002-P425":[37,"U110jxlq"],"C37-Q003-P425":[37,"U13wk3o7"],"C37-Q004-P425":[37,"Uqie21x"],"C37-Q005-P425":[37,"U1n7qklp"],"C37-Q006-P425":[37,"U1ki7ewv"],"C37-Q007-P425":[37,"Ua625rb"],"C37-Q008-P426":[37,"U1v9cxi3"],"C37-Q009-P426":[37,"U1a02c4"],"C37-Q010-P426":[37,"U1lrvt4s"],"C37-Q011-P426":[37,"U1g6wxwn"],"C37-Q012-P426":[37,"U3js0ur"],"C37-Q013-P427":[37,"U13nmp7w"],"C37-Q014-P427":[37,"Uwva07h"],"C37-Q015-P427":[37,"U1boi9qs"],"C37-Q016-P427":[37,"Uevna8e"],"C37-Q017-P427":[37,"U8u9rf8"],"C37-Q018-P427":[37,"Uc35t4u"],"C37-Q019-P427":[37,"Uai6f0f"],"C37-Q020-P427":[37,"U1ni0ddr"],"C37-Q021-P428":[37,"U1w79ylt"],"C37-Q023-P428":[37,"Usus83e"],"C37-Q024-P428":[37,"U1qd3ff4"],"C37-Q025-P429":[37,"U1k0rj0u"],"C37-Q026-P429":[37,"Ups3jo1"],"C37-Q027-P429":[37,"U1rbz3gl"],"C37-Q028-P430":[37,"U7ajlhh"],"C37-Q029-P430":[37,"U1tb2hjc"],"C37-Q030-P430":[37,"U1e6hihx"],"C37-Q031-P430":[37,"Upai6el"],"C37-Q032-P430":[37,"U1yn3f3t"],"C37-Q033-P431":[37,"Uh2lvu1"],"C37-Q034-P431":[37,"U14700pq"],"C37-Q035-P431":[37,"U15hjwny"],"C37-Q036-P431":[37,"Umpuk44"],"C37-Q037-P432":[37,"Ucfxkbt"],"C37-Q038-P432":[37,"U13e0rrv"],"C37-Q039-P432":[37,"Uyqt1xh"],"C37-Q040-P432":[37,"Ux5eldq"],"C37-Q041-P432":[37,"Uev1wjf"],"C37-Q042-P432":[37,"Ubzhf4x"],"C37-Q043-P433":[37,"U2y8uo4"],"C37-Q044-P433":[37,"Uwta262"],"C37-Q045-P433":[37,"U1lj9yif"],"C37-Q046-P433":[37,"U171qlzb"],"C37-Q047-P433":[37,"U18pmbsg"],"C37-Q048-P433":[37,"Unau3j6"],"C37-Q049-P434":[37,"U1lz593l"],"C37-Q050-P434":[37,"U1rqwm1g"],"C37-Q051-P434":[37,"U18lze5h"],"C37-Q052-P434":[37,"U16bic99"],"C37-Q053-P435":[37,"U1no6ga2"],"C37-Q054-P435":[37,"U1g2hmzg"],"C37-Q055-P435":[37,"Ub3zvjd"],"C37-Q056-P435":[37,"Ui7dy3v"],"C37-Q057-P435":[37,"U13k6oxv"],"C38-Q001-P437":[38,"U1r1sefu"],"C38-Q002-P437":[38,"U1h29f6e"],"C38-Q003-P437":[38,"U11umy84"],"C38-Q004-P437":[38,"U1l8zujf"],"C38-Q005-P437":[38,"Uk5j7px"],"C38-Q006-P438":[38,"Ubhoadw"],"C38-Q007-P438":[38,"Uqkjapj"],"C38-Q008-P438":[38,"U1xp7dds"],"C38-Q009-P438":[38,"U1y49iyi"],"C38-Q010-P438":[38,"U1q5j6bw"],"C38-Q011-P439":[38,"U2xtmzm"],"C38-Q012-P439":[38,"U1e7gt21"],"C38-Q013-P439":[38,"Uuk9ie4"],"C38-Q014-P440":[38,"U1xuysoi"],"C38-Q015-P440":[38,"U4iam6e"],"C38-Q016-P440":[38,"Uhw0t3q"],"C38-Q017-P440":[38,"U1bobbj2"],"C38-Q018-P441":[38,"Uxv7uox"],"C38-Q019-P441":[38,"U13tuzwg"],"C38-Q020-P441":[38,"U1bybspj"],"C38-Q021-P441":[38,"Uice79p"],"C38-Q022-P442":[38,"Ugzsrwe"],"C38-Q023-P442":[38,"U19y2kh7"],"C38-Q024-P442":[38,"U14qyrms"],"C38-Q025-P442":[38,"Uxockll"],"C38-Q026-P442":[38,"U7902r9"],"C38-Q027-P443":[38,"Uhxpr9r"],"C38-Q028-P443":[38,"Uritp4s"],"C38-Q029-P443":[38,"U1r2forn"],"C38-Q030-P443":[38,"Uo6xxtd"],"C38-Q031-P444":[38,"Urtwkcd"],"C38-Q032-P444":[38,"U157qyk9"],"C38-Q033-P445":[38,"Ufuddx3"],"C38-Q034-P445":[38,"U1jvh6e0"],"C38-Q035-P445":[38,"U1pfqgw1"],"C38-Q036-P445":[38,"U17cimmd"],"C38-Q037-P446":[38,"Udpbo1g"],"C38-Q038-P446":[38,"Ucyas16"],"C38-Q039-P446":[38,"U9ndkgj"],"C38-Q040-P446":[38,"U1po1v7t"],"C38-Q041-P446":[38,"Unct859"],"C38-Q042-P447":[38,"U1dd0lrf"],"C38-Q043-P447":[38,"Uo23uov"],"C38-Q044-P447":[38,"Ux0ys3i"],"C38-Q045-P447":[38,"U14uuq7l"],"C38-Q046-P447":[38,"Uvf0fbi"],"C38-Q047-P447":[38,"U1b17wn3"],"C38-Q048-P447":[38,"U17h3e69"],"C38-Q049-P447":[38,"U164u7by"],"C38-Q050-P447":[38,"U10tbb12"],"C38-Q051-P448":[38,"U1a42v70"],"C38-Q052-P448":[38,"U1u6y0th"],"C38-Q053-P448":[38,"U11w88p1"],"C38-Q054-P448":[38,"Urnnthd"],"C38-Q055-P448":[38,"U1f2zcfb"],"C38-Q056-P448":[38,"U14keckt"],"C38-Q057-P448":[38,"U5hw4yy"],"C38-Q058-P449":[38,"U1bi1jcn"],"C38-Q059-P449":[38,"U5xmycl"],"C38-Q060-P449":[38,"Uxu8dxv"],"C38-Q061-P449":[38,"U1p4mcj9"],"C38-Q062-P449":[38,"Ujbl6ya"],"C38-Q063-P449":[38,"Uacf4g5"],"C38-Q064-P449":[38,"Ufteaek"],"C38-Q065-P450":[38,"U19nvb14"],"C38-Q066-P450":[38,"Uda2fii"],"C38-Q067-P450":[38,"U11bovr7"],"C38-Q068-P450":[38,"Umz3emf"],"C38-Q069-P450":[38,"Uf36vkr"],"C38-Q070-P450":[38,"U1b90vqt"],"C38-Q071-P450":[38,"U15gh965"],"C38-Q072-P451":[38,"U1twbnlp"],"C38-Q073-P451":[38,"U5nt9il"],"C38-Q074-P451":[38,"U1yfjcq0"],"C38-Q075-P451":[38,"U1qbc1nz"],"C38-Q076-P451":[38,"Ub2yih4"],"C38-Q077-P452":[38,"U19aoboz"],"C38-Q078-P452":[38,"U19f07e5"],"C38-Q079-P452":[38,"Up29gzu"],"C38-Q080-P452":[38,"U1t9du0t"],"C38-Q081-P452":[38,"U1ovzkgu"],"C38-Q082-P452":[38,"U1yxhls2"],"C38-Q083-P452":[38,"Uive610"],"C38-Q084-P453":[38,"U1ms8rsc"],"C38-Q085-P453":[38,"U1b9317r"],"C38-Q086-P453":[38,"U1uexeq5"],"C38-Q087-P453":[38,"U15de0a5"],"C38-Q088-P454":[38,"Up7w3ur"],"C38-Q089-P454":[38,"U1llbs6g"],"C38-Q090-P454":[38,"Uvugtef"],"C39-Q001-P455":[39,"U1ttgua0"],"C39-Q002-P455":[39,"U9au1pj"],"C39-Q003-P455":[39,"U3b0tvd"],"C39-Q004-P456":[39,"Uj9yjo2"],"C39-Q005-P456":[39,"U4am1zr"],"C39-Q006-P456":[39,"U9tm1j8"],"C39-Q007-P456":[39,"U1eieq6s"],"C39-Q008-P456":[39,"U1c6jafm"],"C39-Q009-P457":[39,"U1hq1w5k"],"C39-Q010-P457":[39,"Uyowti2"],"C39-Q011-P457":[39,"U1k6ygf9"],"C39-Q012-P457":[39,"U5g7z7d"],"C39-Q013-P457":[39,"U15frykc"],"C39-Q014-P457":[39,"U1216804"],"C39-Q015-P457":[39,"U1nxvwlj"],"C39-Q016-P457":[39,"U177v7zg"],"C39-Q017-P457":[39,"U6g6lzz"],"C39-Q018-P458":[39,"U17deom2"],"C39-Q019-P458":[39,"U157his3"],"C39-Q020-P458":[39,"U18w4rzk"],"C39-Q021-P458":[39,"U1kzlg7r"],"C39-Q022-P458":[39,"U1v8b0o6"],"C39-Q023-P458":[39,"U10i1xk8"],"C39-Q024-P458":[39,"Udekr6t"],"C39-Q025-P459":[39,"U8nm0uk"],"C39-Q026-P459":[39,"U1yij522"],"C40-Q001-P460":[40,"Uf6on4m"],"C40-Q002-P460":[40,"U1sx9ww2"],"C40-Q003-P460":[40,"Uhcksq7"],"C40-Q004-P460":[40,"Urpws1x"],"C40-Q004-P473":[40,"U59ejvb"],"C40-Q005-P460":[40,"U105ca9o"],"C40-Q006-P460":[40,"Um3hs3l"],"C40-Q007-P460":[40,"U1l9x2hd"],"C40-Q008-P460":[40,"Uz9ta3c"],"C40-Q009-P461":[40,"Uhwyg29"],"C40-Q010-P461":[40,"Usc0waq"],"C40-Q011-P461":[40,"U1rfq0q"],"C40-Q012-P461":[40,"Uty386z"],"C40-Q013-P461":[40,"U19fxpsn"],"C40-Q014-P461":[40,"U1g48sr5"],"C40-Q015-P462":[40,"U11ryc7f"],"C40-Q016-P462":[40,"U13nag7u"],"C40-Q017-P462":[40,"Uqcpqjx"],"C40-Q019-P462":[40,"U1wa8zuu"],"C40-Q020-P462":[40,"Uexmeun"],"C40-Q021-P462":[40,"U1dh73tc"],"C40-Q022-P462":[40,"Un2w4xk"],"C40-Q023-P463":[40,"Ugkqj1d"],"C40-Q024-P463":[40,"Uvsffct"],"C40-Q025-P463":[40,"U2wteun"],"C40-Q026-P463":[40,"Uxci45b"],"C40-Q027-P463":[40,"Ulohl3m"],"C40-Q028-P464":[40,"U1jlvqw9"],"C40-Q029-P464":[40,"U112fept"],"C40-Q030-P464":[40,"U4ixsyl"],"C40-Q031-P464":[40,"Uxmbzb7"],"C40-Q032-P465":[40,"U16hfwhb"],"C40-Q033-P465":[40,"Ug53iby"],"C40-Q034-P465":[40,"U127zc76"],"C40-Q035-P465":[40,"U3bl347"],"C40-Q036-P466":[40,"Un8fma6"],"C40-Q037-P466":[40,"U1qo4god"],"C40-Q038-P466":[40,"Usqwi2a"],"C40-Q039-P466":[40,"Uruiru8"],"C40-Q040-P466":[40,"Uzim4k2"],"C40-Q041-P466":[40,"Ucx0ah9"],"C40-Q042-P467":[40,"U1b8g6lt"],"C40-Q043-P467":[40,"U123x9t1"],"C40-Q044-P467":[40,"U1488g6n"],"C40-Q045-P467":[40,"Urecm9i"],"C40-Q046-P467":[40,"Utfxo46"],"C40-Q047-P467":[40,"U2kqlsp"],"C40-Q048-P467":[40,"U1z0nz31"],"C40-Q049-P467":[40,"U12wpq3r"],"C40-Q050-P467":[40,"Uh0pbud"],"C40-Q051-P468":[40,"U5d94ks"],"C40-Q052-P468":[40,"U1ck89fv"],"C40-Q053-P468":[40,"U97disu"],"C40-Q054-P468":[40,"U144f839"],"C40-Q055-P468":[40,"U129uhs8"],"C40-Q056-P469":[40,"U1o5kpm1"],"C40-Q057-P469":[40,"Utyp6xr"],"C40-Q058-P469":[40,"U9zvj10"],"C40-Q059-P469":[40,"U18fgcvq"],"C40-Q060-P469":[40,"U1ra2nou"],"C40-Q061-P469":[40,"U1jprlbt"],"C40-Q062-P469":[40,"U1l7oljt"],"C40-Q063-P470":[40,"U1nhah7p"],"C40-Q064-P470":[40,"Uhnhout"],"C40-Q065-P470":[40,"Ul7ww0n"],"C40-Q066-P470":[40,"U10e182i"],"C40-Q067-P470":[40,"U19un7uq"],"C40-Q068-P470":[40,"Ui79ogo"],"C40-Q069-P470":[40,"U1oz4gmh"],"C40-Q070-P471":[40,"U1heyba0"],"C40-Q071-P471":[40,"Uksqqy3"],"C40-Q072-P471":[40,"Ui4cupf"],"C40-Q073-P471":[40,"Ui6kfu9"],"C40-Q074-P471":[40,"U13rnodo"],"C40-Q075-P472":[40,"U1maq36j"],"C40-Q076-P472":[40,"U12u37b9"],"C40-Q077-P472":[40,"U1l8uxvz"],"C40-Q078-P472":[40,"Uvhtxkm"],"C40-Q079-P473":[40,"Ukld5e4"],"C40-Q080-P473":[40,"U20s7uj"],"C40-Q081-P473":[40,"U7kzav"],"C40-Q083-P473":[40,"U1aupfs8"],"C40-Q084-P473":[40,"U17gl89r"],"C40-Q085-P473":[40,"Ubg1hbi"],"C40-Q086-P474":[40,"Uuedcgu"],"C40-Q087-P474":[40,"Uekpmqs"],"C40-Q088-P474":[40,"U1fsawn8"],"C40-Q089-P474":[40,"U1kxkhv7"],"C40-Q090-P474":[40,"U123wjcy"],"C40-Q091-P474":[40,"Ubgokdn"],"C40-Q092-P474":[40,"Uqpgz32"],"C40-Q093-P475":[40,"Uy6959g"],"C40-Q094-P475":[40,"Unfjvtq"],"C40-Q095-P475":[40,"U1x9tkfm"],"C40-Q096-P475":[40,"U1wovxgf"],"C40-Q097-P476":[40,"Up4yi0m"],"C40-Q098-P476":[40,"U13jix0f"],"C40-Q099-P476":[40,"Utvez79"],"C40-Q100-P476":[40,"U14euwcj"],"C40-Q101-P476":[40,"U4matvl"],"C40-Q102-P476":[40,"Uueq2rv"],"C40-Q103-P476":[40,"Uae5ldc"],"C40-Q104-P476":[40,"Udeeo93"],"C40-Q105-P476":[40,"U1iw8le1"],"C40-Q106-P477":[40,"U1ggsh8l"],"C40-Q107-P477":[40,"U1nc97ih"],"C40-Q108-P477":[40,"Upbbeyd"],"C40-Q109-P477":[40,"Ufpsnj"],"C40-Q110-P477":[40,"U1uq3vcj"],"C40-Q111-P478":[40,"U17632r3"],"C40-Q112-P478":[40,"U4yfv6p"],"C40-Q113-P478":[40,"Un5k6jc"],"C40-Q114-P478":[40,"Uzc9oq9"],"C40-Q115-P478":[40],"C40-Q116-P478":[40,"U1l4xtr3"],"C40-Q117-P478":[40,"U1l493h4"],"C40-Q118-P478":[40,"Uegd8q"],"C40-Q119-P478":[40,"U18sbfjj"],"C40-Q120-P478":[40,"U6t4b8"],"C40-Q121-P478":[40,"Ul52r3"],"C40-Q122-P479":[40,"Uu298dx"],"C40-Q123-P479":[40,"U1psys2p"],"C40-Q124-P479":[40,"Uzo2ygp"],"C40-Q125-P479":[40,"U17nydhg"],"C40-Q126-P479":[40,"U1kt9k5w"],"C40-Q127-P480":[40,"U1yoy62q"],"C40-Q128-P480":[40,"U1lvyoyi"],"C40-Q129-P480":[40,"Uwan5on"],"C40-Q130-P480":[40,"U34p5gf"],"C40-Q131-P480":[40,"Usuea5l"],"C40-Q132-P480":[40,"Usuea5l_1"],"C40-Q133-P480":[40,"U1b6bhtp"],"C40-Q134-P481":[40,"U1fv8pl1"],"C40-Q135-P481":[40,"U1k38zwu"],"C40-Q136-P481":[40,"Uemndpb"],"C40-Q137-P481":[40,"U1wrzubd"],"C40-Q138-P482":[40,"Uruq8ak"],"C40-Q139-P482":[40,"Uxl1oes"],"C40-Q140-P482":[40,"U2adxun"],"C40-Q141-P482":[40,"Uonxfa1"],"C40-Q142-P482":[40,"U16rocwx"],"C40-Q143-P483":[40,"U19kvr76"],"C40-Q144-P483":[40,"U133xnw6"],"C40-Q145-P483":[40,"U7oimaj"],"C40-Q146-P483":[40,"U1ui9phw"],"C40-Q147-P483":[40,"U11s9a9q"],"C40-Q148-P483":[40,"U17bvvjd"],"C40-Q149-P484":[40,"U1hts2qu"],"C40-Q150-P484":[40,"Uexbp6c"],"C40-Q151-P484":[40,"Ujcxymz"],"C40-Q152-P484":[40,"Ueipep4"],"C40-Q153-P484":[40,"U1aa5sl2"],"C40-Q154-P484":[40,"U81y3b4"],"C40-Q155-P484":[40,"U1hp3qw1"],"C40-Q156-P485":[40,"Ulmi34j"],"C40-Q157-P485":[40,"U1i9d31p"],"C40-Q158-P485":[40,"Uvxxbze"],"C40-Q159-P485":[40,"Up9v889"],"C40-Q160-P486":[40,"U1reszd"],"C40-Q161-P486":[40,"U1n8jsmo"],"C40-Q162-P486":[40,"U1amutn1"],"C40-Q163-P486":[40,"U3cehoh"],"C40-Q164-P486":[40,"Uowjyz7"],"C40-Q165-P486":[40,"Uxty2oj"],"C40-Q166-P487":[40,"Uh8avvx"],"C40-Q167-P487":[40,"U1fycm4c"],"C40-Q168-P487":[40,"U12fw85z"],"C40-Q169-P487":[40,"U1dx2wc2"],"C40-Q170-P487":[40,"U1rj1jg1"],"C40-Q171-P487":[40,"Uinvwfw"],"C40-Q172-P487":[40,"Ubji7zy"],"C40-Q173-P488":[40,"U5jtr3f"],"C40-Q174-P488":[40,"U1dk1kpa"],"C40-Q175-P488":[40,"U1gfp8pb"],"C40-Q176-P488":[40,"Uy8yfbk"],"C40-Q177-P489":[40,"Uf8nusv"],"C40-Q178-P489":[40,"U145n3iw"],"C40-Q179-P489":[40,"U1rjiosj"],"C40-Q180-P489":[40,"Uiv8w1a"],"C40-Q181-P489":[40,"Uv9br8q"],"C40-Q182-P489":[40,"Uqwhea2"],"C40-Q183-P489":[40,"Us22bk"],"C40-Q184-P490":[40,"U7pfvhu"],"C40-Q185-P490":[40,"Ul418qf"],"C40-Q186-P490":[40,"Urchkh9"],"C40-Q187-P490":[40,"U16fd8u1"],"C40-Q188-P490":[40,"U2ihvqq"],"C40-Q189-P491":[40,"Utcyr0f"],"C40-Q190-P491":[40,"Ue10f6o"],"C40-Q191-P491":[40,"Udlbxh7"],"C40-Q192-P491":[40,"U1prne1k"],"C40-Q193-P491":[40,"U13mnaku"],"C40-Q194-P491":[40,"U1b879ha"],"C40-Q195-P492":[40,"Uxk8cji"],"C40-Q196-P492":[40,"U17e2twq"],"C40-Q197-P492":[40,"U1p56e1b"],"C40-Q198-P492":[40,"Ucamzm1"],"C40-Q199-P492":[40,"Uf2xumr"],"C40-Q200-P492":[40,"U1m4xysh"],"C40-Q201-P493":[40,"U1j7ml3"],"C40-Q202-P493":[40,"Uln6rzt"],"C40-Q203-P493":[40,"U1c2tupa"],"C40-Q204-P493":[40,"U163mogw"],"C40-Q205-P493":[40,"Uej5b26"],"C40-Q206-P494":[40,"Udi3rot"],"C40-Q207-P494":[40,"U1eott8y"],"C40-Q208-P495":[40,"Uxobxic"],"C40-Q209-P495":[40,"U6xxvkp"],"C40-Q210-P495":[40,"U1mvz923"],"C40-Q211-P495":[40,"U1s8i52g"],"C40-Q212-P495":[40,"U1xzeq9i"],"C40-Q213-P496":[40,"Uudf1oa"],"C40-Q214-P496":[40,"Urg8qwb"],"C40-Q215-P496":[40,"U16cuyw4"],"C40-Q216-P496":[40,"Uy0m7kl"],"C40-Q217-P496":[40,"Uoyceot"],"C40-Q218-P496":[40,"Uxdox91"],"C40-Q219-P497":[40,"U1wtq1pd"],"C40-Q220-P497":[40,"U1khml3"],"C40-Q221-P497":[40,"U17wjlc"],"C40-Q222-P497":[40,"Upysj5b"],"C41-Q001-P498":[41,"Uqp8oxi"],"C41-Q002-P499":[41,"U1w40krk"],"C41-Q003-P499":[41,"U5z64hu"],"C41-Q004-P499":[41,"U1sri7dd"],"C41-Q005-P499":[41,"U1hdofgl"],"C41-Q006-P499":[41,"Ubziqgm"],"C41-Q007-P499":[41,"U1q8vptl"],"C41-Q008-P500":[41,"U1g1d1sa"],"C41-Q009-P500":[41,"Ujc9wfa"],"C41-Q010-P500":[41,"U10ymwdq"],"C41-Q011-P500":[41,"U1kjbqwl"],"C41-Q012-P501":[41,"U1rm2q6h"],"C41-Q013-P501":[41,"U6g464j"],"C41-Q014-P501":[41,"U14mm7fi"],"C41-Q015-P501":[41,"U1w5qn3u"],"C41-Q016-P501":[41,"Ugz7mt7"],"C41-Q017-P501":[41,"U15aqzym"],"C41-Q018-P502":[41,"U1v59ed0"],"C41-Q019-P502":[41,"U1rbhqnp"],"C41-Q020-P502":[41,"Udk5ytf"],"C41-Q021-P502":[41,"U17ovhv1"],"C41-Q022-P502":[41,"U3ww41p"],"C41-Q023-P503":[41,"U379gcx"],"C41-Q024-P503":[41,"U1ka7liq"],"C41-Q025-P503":[41,"Urfaf7c"],"C41-Q026-P503":[41,"Ungthwp"],"C41-Q027-P504":[41,"U1vxya9k"],"C41-Q028-P504":[41,"U16gjlfx"],"C41-Q029-P504":[41,"Ugej1l1"],"C42-Q001-P504":[42,"U1nr5twl"],"C42-Q002-P504":[42,"U18kp5ed"],"C42-Q003-P505":[42,"Ug05p9r"],"C42-Q004-P505":[42,"U1bdwiis"],"C42-Q005-P505":[42,"U65skea"],"C42-Q006-P505":[42,"Uzs0p1x"],"C42-Q007-P505":[42,"U1pml5nk"],"C42-Q008-P505":[42,"Ukalh48"],"C42-Q009-P506":[42,"U5wgvc3"],"C42-Q010-P506":[42,"Um0xepi"],"C42-Q011-P506":[42,"U1akfjpi"],"C42-Q012-P506":[42,"Uj7flzu"],"C42-Q013-P506":[42,"Uwzm18u"],"C42-Q014-P507":[42,"U14tbolc"],"C42-Q015-P507":[42,"U1tcn5cq"],"C42-Q016-P507":[42,"Ucp6dya"],"C42-Q017-P507":[42,"Uwarnym"],"C42-Q018-P507":[42,"Ufi54hd"],"C42-Q019-P507":[42,"U19ud7hx"],"C42-Q020-P508":[42,"U1kbkez4"],"C42-Q021-P508":[42,"U1vbpq50"],"C42-Q022-P508":[42,"Ujmwvsp"],"C42-Q023-P508":[42,"U1xm28gm"],"C42-Q024-P508":[42,"U1eivvdg"],"C42-Q025-P509":[42,"U52dadz"],"C42-Q026-P509":[42,"U3mnnxh"],"C42-Q027-P509":[42,"U1dk0y79"],"C42-Q028-P509":[42,"Ul33itx"],"C42-Q029-P509":[42,"Uonotka"],"C42-Q030-P509":[42,"U12hjzif"],"C42-Q031-P510":[42,"U8om893"],"C42-Q032-P510":[42,"U1iit5tl"],"C42-Q033-P510":[42,"U1pwtd49"],"C42-Q034-P510":[42,"U158eig"],"C42-Q035-P510":[42,"U1ti6goh"],"C42-Q036-P510":[42,"U12b971t"],"C42-Q037-P511":[42,"Ue5ao1"],"C42-Q038-P511":[42,"U7q6va6"],"C42-Q039-P511":[42,"Uh0k9v1"],"C42-Q040-P511":[42,"Uw88p9j"],"C42-Q041-P511":[42,"Ut6s0j2"],"C42-Q042-P511":[42,"U1el2g58"],"C42-Q043-P512":[42,"U1wkjeuo"],"C42-Q044-P512":[42,"U1eqz6mj"],"C42-Q045-P512":[42,"U6gbpc0"],"C42-Q046-P512":[42,"U174fsjm"],"C42-Q047-P512":[42,"U18ep2y1"],"C42-Q048-P512":[42,"Udr2uuq"],"C42-Q049-P512":[42,"U1rryat8"],"C42-Q050-P513":[42,"U1gg1ecq"],"C42-Q051-P513":[42,"U15hn8vo"],"C42-Q052-P513":[42,"U3iw2tn"],"C42-Q053-P513":[42,"U7xtqqy"],"C42-Q054-P513":[42,"Uqtbc4b"],"C42-Q055-P513":[42,"Uwe7oiw"],"C42-Q056-P513":[42,"Uqifukm"],"C42-Q057-P513":[42,"Ux68to5"],"C42-Q058-P514":[42,"Ur9wdwb"],"C42-Q059-P514":[42,"U17xpv23"],"C42-Q060-P514":[42,"U6gfyjr"],"C42-Q061-P514":[42,"Uzl2xur"],"C42-Q062-P514":[42,"U1ubaqv6"],"C42-Q063-P514":[42,"Uubxbp4"],"C42-Q064-P515":[42,"U1ueoku3"],"C42-Q065-P515":[42,"Uo36e70"],"C42-Q066-P515":[42,"U14hngw3"],"C42-Q067-P515":[42,"U1o1hwsd"],"C42-Q068-P515":[42,"U174ouc5"],"C42-Q069-P516":[42,"Ue6ug2d"],"C42-Q070-P516":[42,"U1iyubob"],"C42-Q071-P516":[42,"Uk7icbu"],"C42-Q072-P516":[42,"Ubrtyr3"],"C42-Q073-P517":[42,"U11utghf"],"C42-Q074-P517":[42,"Uafcex"],"C42-Q075-P517":[42,"U11utghf_1"],"C42-Q076-P517":[42,"Uuxnfi5"],"C42-Q077-P518":[42,"Urjxnzg"],"C42-Q078-P518":[42,"Uh1onuk"],"C42-Q079-P518":[42,"U16t4fk1"],"C42-Q080-P518":[42,"Uv6ftzu"],"C42-Q081-P519":[42,"U1ugit4i"],"C42-Q082-P519":[42,"U19o82q7"],"C42-Q083-P519":[42,"Uikgeqh"],"C42-Q084-P519":[42,"U15c0kuu"],"C42-Q085-P519":[42,"U14zbgw2"],"C42-Q086-P520":[42,"Uomcuci"],"C42-Q087-P520":[42,"U5mtp35"],"C42-Q088-P520":[42,"U193a6si"],"C42-Q089-P520":[42,"Ucprlwg"],"C42-Q090-P520":[42,"U152js60"],"C42-Q091-P521":[42,"U4rawsk"],"C42-Q092-P521":[42,"U1v25lzu"],"C42-Q093-P521":[42,"U1uw80b4"],"C42-Q094-P521":[42,"U13lkqg2"],"C42-Q095-P521":[42,"U7lz7tu"],"C42-Q096-P521":[42,"U1rl73iv"],"C42-Q097-P521":[42,"Uc9mpgj"],"C42-Q098-P522":[42,"U1slpcu4"],"C42-Q099-P522":[42,"U1qd5crf"],"C42-Q100-P522":[42,"U1pw9bd1"],"C42-Q101-P522":[42,"U1atanbs"],"C42-Q102-P522":[42,"U2i3ubq"],"C42-Q103-P522":[42,"Upvlqou"],"C42-Q104-P523":[42,"Uje8hra"],"C42-Q105-P523":[42,"U1m4syav"],"C42-Q106-P523":[42,"Uem8jrd"],"C42-Q107-P524":[42,"U1hge8gq"],"C42-Q108-P524":[42,"Urz2mu4"],"C42-Q109-P524":[42,"U1eoaz7c"],"C42-Q110-P524":[42,"U1spny9r"],"C42-Q111-P525":[42,"U64pk9m"],"C42-Q112-P525":[42,"Uczmjra"],"C42-Q113-P525":[42,"U8kc92u"],"C42-Q114-P525":[42,"U12ay42s"],"C42-Q115-P525":[42,"Uvy5i83"],"C42-Q116-P525":[42,"U1ukh5h6"],"C42-Q117-P526":[42,"Ubvmfqd"],"C42-Q118-P526":[42,"U147499n"],"C42-Q119-P526":[42,"U1qhsrcb"],"C42-Q120-P526":[42,"Us201e5"],"C42-Q121-P526":[42,"U2h03pd"],"C42-Q122-P526":[42,"U13376kr"],"C42-Q123-P527":[42,"U12l7fx2"],"C42-Q124-P527":[42,"Utl6e10"],"C42-Q125-P527":[42,"U7un5e3"],"C42-Q126-P527":[42,"U1di8hw3"],"C42-Q127-P527":[42,"Uqf5xk7"],"C42-Q128-P528":[42,"U1xcf7hl"],"C42-Q129-P528":[42,"U1rmw6z8"],"C42-Q130-P528":[42,"U1i5igsc"],"C42-Q131-P528":[42,"U1w90zky"],"C42-Q132-P529":[42,"Uqx3bgm"],"C42-Q133-P529":[42,"U1t8fhd5"],"C42-Q134-P529":[42,"Urf3giu"],"C42-Q135-P529":[42,"U1x37u7y"],"C42-Q136-P530":[42,"U76nb2x"],"C42-Q137-P530":[42,"U1ehux45"],"C42-Q138-P530":[42,"U8vm84r"],"C42-Q139-P530":[42,"U1k39o6w"],"C42-Q140-P530":[42,"Ubhx7w1"],"C42-Q141-P530":[42,"U173l4uz"]},"prints":{"1663550":"C13-Q067-P118","1n85p70":"C01-Q001-P007","idsm1c":"C01-Q001-P010","1eqcd1v":"C01-Q002-P007","2qk13y":"C01-Q002-P010","tuywa0":"C01-Q003-P008","e6d9kn":"C01-Q003-P010","1bu4mlz":"C01-Q004-P008","1dk6wyl":"C01-Q004-P010","159rocc":"C01-Q005-P008","1efptwm":"C01-Q005-P011","1qxph62":"C01-Q006-P008","11hi1p":"C01-Q006-P011","61ul0b":"C01-Q007-P008","1cmn72w":"C01-Q007-P011","t2jk1f":"C01-Q008-P009","l5vpls":"C01-Q008-P011","un25vq":"C01-Q009-P011","do4rp4":"C01-Q010-P011","y8v14":"C01-Q011-P012","geoyt2":"C01-Q012-P012","1yvzziq":"C01-Q013-P012","8cl4x9":"C01-Q014-P012","122g0r":"C01-Q015-P013","qnjwe0":"C01-Q016-P013","iwl9vf":"C01-Q017-P013","1fopkhv":"C01-Q018-P013","clrfw6":"C01-Q019-P014","xctz4h":"C01-Q020-P014","1y5f421":"C01-Q021-P014","39t2rk":"C01-Q022-P014","1voa3hw":"C01-Q023-P014","1f51j1x":"C01-Q024-P014","10diiwl":"C01-Q025-P014","1q1z1kv":"C01-Q026-P015","t3aylm":"C01-Q027-P015","1cio2ex":"C01-Q028-P015","swzjgg":"C01-Q029-P015","qesuw9":"C01-Q030-P015","lsons3":"C01-Q031-P015","1980sjq":"C01-Q032-P016","4ezump":"C01-Q033-P016","13ssmv4":"C01-Q034-P016","12tthns":"C01-Q035-P016","he9csx":"C01-Q036-P016","omqgo":"C02-Q001-P017","rj7rvn":"C02-Q002-P018","12972om":"C02-Q003-P018","qdgch8":"C02-Q004-P018","mxuxuh":"C02-Q005-P018","1ppwjh":"C02-Q006-P018","cf5sbn":"C02-Q007-P018","ddvmkk":"C02-Q008-P018","14b7l82":"C02-Q009-P019","xz0btz":"C02-Q010-P019","sg78qb":"C02-Q011-P019","hlc5xb":"C02-Q013-P019","mpg9ay":"C02-Q014-P019","shybk1":"C02-Q015-P020","1i2bhfv":"C02-Q016-P020","ca8vjj":"C02-Q017-P020","y7kd5y":"C02-Q018-P020","19hu5k9":"C02-Q019-P021","yojqm1":"C02-Q020-P021","1xvpaqn":"C02-Q021-P021","b1pkr2":"C02-Q022-P021","183b9pz":"C02-Q023-P021","hrfds3":"C02-Q024-P021","1y75j08":"C02-Q025-P021","19qeuuf":"C02-Q026-P021","11unde8":"C02-Q027-P022","8f69jx":"C02-Q028-P022","1celbmh":"C02-Q029-P022","maa18v":"C02-Q030-P022","492akk":"C02-Q031-P022","1l710kg":"C02-Q032-P022","i01cty":"C02-Q033-P022","7gqlep":"C02-Q034-P022","msj667":"C02-Q035-P023","1d30iqh":"C02-Q036-P023","iurus9":"C02-Q037-P023","eo1mvz":"C02-Q038-P023","4mnpnu":"C02-Q040-P023","1eiadcv":"C02-Q041-P023","v1jkp9":"C02-Q042-P023","8kaezb":"C02-Q043-P024","1azco6p":"C02-Q044-P024","dc68n3":"C02-Q045-P024","1lt70se":"C02-Q046-P024","jbb6rs":"C02-Q047-P024","ck1m84":"C02-Q048-P025","172mfdj":"C02-Q049-P025","w1x7z6":"C02-Q050-P025","pf5n14":"C02-Q051-P025","ijd9ra":"C02-Q052-P025","1p6sxrs":"C02-Q053-P025","1j1koy":"C02-Q054-P025","1yqybgc":"C02-Q055-P025","1qr94ys":"C02-Q056-P025","1lco6s4":"C02-Q057-P026","d66wbc":"C02-Q058-P026","1kk0ln3":"C02-Q059-P026","1buhccp":"C02-Q060-P026","129j4bq":"C02-Q061-P026","vws7v4":"C02-Q062-P027","uked97":"C02-Q063-P027","1cp4gou":"C02-Q064-P027","1dpk2ne":"C02-Q065-P027","12ywts4":"C02-Q066-P027","1nqgkgg":"C02-Q067-P027","2tqgh7":"C02-Q068-P028","1bww7tl":"C02-Q069-P028","1lvv0nk":"C02-Q070-P028","1w9btas":"C02-Q071-P028","15kz1f5":"C02-Q072-P028","1jqhvx0":"C02-Q073-P028","u6fw22":"C03-Q001-P029","q7ycpx":"C03-Q002-P029","1t6q8ne":"C03-Q003-P029","9rvi0i":"C03-Q004-P030","uvaqqz":"C03-Q005-P030","hh8z8l":"C03-Q006-P030","1869nq1":"C03-Q007-P030","1k5kyht":"C03-Q008-P030","1at06jm":"C03-Q009-P031","z17ij5":"C03-Q010-P031","1h4tczy":"C03-Q011-P031","160mfxf":"C03-Q012-P031","140mksy":"C03-Q013-P031","1qb4n0c":"C04-Q001-P033","yu1hnh":"C04-Q002-P033","n0nfh2":"C04-Q003-P033","14a5zdc":"C04-Q004-P033","15w01iw":"C04-Q005-P033","19j5vn":"C04-Q006-P033","1gvpak8":"C04-Q007-P033","1xv263b":"C04-Q008-P034","1czwfdp":"C04-Q009-P034","t6grly":"C04-Q010-P034","1cnw6s5":"C04-Q011-P034","n2lc5i":"C04-Q012-P034","h8q3q9":"C04-Q013-P034","1lpdqhi":"C04-Q014-P034","1whsyad":"C04-Q015-P034","15ndnp9":"C04-Q016-P035","b1lbdn":"C04-Q017-P035","3olbzb":"C04-Q018-P035","1lkc9vv":"C04-Q019-P035","a7ob4j":"C04-Q020-P035","xm4xxy":"C04-Q021-P036","1ekh0q6":"C04-Q022-P036","1ty7vum":"C04-Q023-P036","18igygc":"C04-Q024-P036","gv3law":"C04-Q025-P036","s3gzeo":"C04-Q026-P037","e5dtb0":"C04-Q027-P037","1xn1r73":"C04-Q028-P037","famys1":"C04-Q029-P037","thk8yc":"C05-Q001-P038","yy2b1h":"C05-Q002-P038","1ol3324":"C05-Q003-P038","cja7d":"C05-Q004-P038","14r89ku":"C05-Q005-P038","1vfaqba":"C05-Q006-P038","1p9ov8p":"C05-Q007-P039","4h3jjb":"C05-Q008-P039","1apaopv":"C05-Q009-P039","8507u4":"C05-Q010-P039","1v64x1b":"C05-Q011-P039","pul6lm":"C05-Q012-P040","9kmiyw":"C05-Q013-P040","1s8ewua":"C05-Q014-P040","30v5fe":"C05-Q015-P040","1dqoy4c":"C05-Q016-P040","1d31nri":"C05-Q017-P041","1i8co6u":"C05-Q018-P041","l61aq6":"C05-Q019-P041","fpmffs":"C05-Q020-P041","1rpcvv4":"C06-Q001-P044","185xig0":"C06-Q002-P044","xh8lnx":"C06-Q003-P044","1eefjgp":"C06-Q004-P044","18xacp8":"C06-Q005-P044","1mxiv5a":"C06-Q006-P044","1gmq79v":"C06-Q007-P045","wjgkik":"C06-Q008-P045","3upl2l":"C06-Q009-P045","1sbx6hx":"C06-Q010-P045","9de58j":"C06-Q011-P045","xvklua":"C06-Q012-P045","6wqmvh":"C06-Q013-P046","ve9x96":"C06-Q014-P046","3jg203":"C06-Q015-P046","d0l603":"C06-Q017-P047","1mlxf9t":"C06-Q018-P047","128x9sz":"C06-Q019-P047","1wyr4rb":"C06-Q020-P048","ro2xt3":"C06-Q021-P048","fcm1in":"C06-Q022-P048","b1p5ke":"C06-Q023-P048","37cpz9":"C06-Q024-P049","1tr3357":"C06-Q025-P049","3nye8w":"C06-Q026-P049","1ngk2qo":"C06-Q027-P049","1vwkj70":"C06-Q028-P050","kjompc":"C06-Q029-P050","1dhir63":"C07-Q001-P051","mkkvxm":"C07-Q002-P051","10bhqoi":"C07-Q003-P051","1yx29fn":"C07-Q004-P051","z28f86":"C07-Q005-P051","ijpd2e":"C07-Q006-P052","a0mqck":"C07-Q007-P052","u51it8":"C07-Q008-P052","j6ng3j":"C07-Q009-P052","nqhgiv":"C07-Q010-P052","bprauv":"C07-Q011-P053","18bc4i3":"C07-Q012-P053","4oi5rz":"C07-Q013-P053","1vn7y3t":"C07-Q014-P053","1u8q3gc":"C07-Q015-P054","1ppj9xz":"C07-Q016-P054","goie2":"C07-Q017-P054","1vmfprk":"C07-Q018-P054","g3vui7":"C07-Q019-P054","zv7nud":"C07-Q020-P054","92otz9":"C07-Q021-P055","1ocw06k":"C07-Q022-P055","16k9snf":"C07-Q023-P055","3qcfed":"C07-Q024-P055","1td0kux":"C07-Q025-P055","u246hv":"C07-Q026-P055","12iji3l":"C07-Q027-P056","s1pw98":"C07-Q028-P056","siqbil":"C07-Q029-P056","126q1r7":"C07-Q030-P056","11oswpp":"C07-Q031-P056","1yhopyr":"C07-Q032-P056","1e5ijjz":"C07-Q033-P057","1f5ymca":"C07-Q034-P057","1dsi9ay":"C07-Q035-P057","13xifs7":"C07-Q036-P057","1889knn":"C07-Q037-P057","1g5swsy":"C07-Q038-P057","7eqiyn":"C07-Q039-P057","rxkdu":"C07-Q040-P057","4tkfom":"C07-Q041-P058","mm7k2i":"C07-Q042-P058","14zmb15":"C07-Q043-P058","nghi6z":"C07-Q044-P058","1eascmw":"C07-Q045-P058","1etx4qe":"C07-Q046-P058","1jukrgy":"C07-Q047-P058","1xr8ia8":"C07-Q048-P059","aqhlch":"C07-Q049-P059","8ar518":"C07-Q050-P059","i5njgm":"C07-Q051-P059","jzlwun":"C07-Q052-P059","1oswulx":"C07-Q053-P059","cu7zis":"C07-Q054-P060","c8r79m":"C07-Q055-P060","1shz729":"C07-Q056-P060","1vai6vr":"C07-Q057-P060","1xv53bq":"C07-Q058-P060","19a9usc":"C07-Q059-P060","15p55g5":"C07-Q060-P061","g5wi9u":"C07-Q061-P061","gy96ua":"C07-Q062-P061","fztcd9":"C07-Q063-P061","f5ttz4":"C07-Q064-P061","1csjpga":"C08-Q001-P062","1hxvhhd":"C08-Q002-P062","762blq":"C08-Q003-P062","ugdu79":"C08-Q004-P062","166c59a":"C08-Q005-P063","amzsm5":"C08-Q006-P063","1rga195":"C08-Q007-P063","1aaunoe":"C08-Q008-P063","1uf69t6":"C08-Q009-P063","1qp83t5":"C08-Q010-P064","1xrwi3j":"C08-Q011-P064","13npoq9":"C08-Q012-P064","1i0k42j":"C08-Q013-P064","1n9kvl6":"C08-Q014-P064","p6vvks":"C08-Q015-P064","hqyrhh":"C08-Q016-P064","1lpxj7b":"C08-Q017-P064","70cjly":"C08-Q018-P064","18alurc":"C08-Q019-P065","1t4k8cv":"C08-Q020-P065","16ao5k0":"C08-Q021-P065","1d95q2r":"C08-Q022-P065","6onou0":"C08-Q023-P065","1hnpev0":"C08-Q024-P065","8bjbbo":"C08-Q025-P065","1wm6wfk":"C08-Q026-P066","a1vlvh":"C08-Q027-P066","1hhd7ng":"C08-Q028-P066","h87z3j":"C08-Q029-P066","1cmpha8":"C08-Q030-P066","1qz9lou":"C08-Q031-P066","1h0j6fj":"C08-Q032-P066","4y01fr":"C08-Q033-P067","dxqp8e":"C08-Q034-P067","5tzuq6":"C08-Q035-P067","1jfipdu":"C08-Q036-P067","1i2wk3v":"C08-Q037-P067","c97zbw":"C08-Q038-P067","p18h50":"C08-Q039-P068","1gr1c4p":"C08-Q040-P068","bmeaws":"C08-Q041-P068","p5b9ee":"C08-Q042-P068","1kxjpw0":"C08-Q043-P068","1ick77k":"C08-Q044-P068","j8bb1w":"C08-Q045-P068","hgol":"C08-Q046-P069","18maul1":"C08-Q047-P069","1ac3s2":"C08-Q048-P069","1e5e60r":"C08-Q049-P069","1mhupdd":"C08-Q050-P069","1r0d9vi":"C08-Q051-P069","26ts4i":"C09-Q001-P071","gaheks":"C09-Q002-P071","1ihj827":"C09-Q003-P071","ql0xa0":"C09-Q004-P072","z16rfw":"C09-Q005-P072","l3kx29":"C09-Q006-P072","5zdk7b":"C09-Q007-P072","1n2jlcw":"C09-Q008-P072","po5vcf":"C09-Q009-P072","1dn1gqr":"C09-Q010-P072","zo8css":"C09-Q011-P073","uprpux":"C09-Q012-P073","1qmdyx":"C09-Q013-P073","1tnuo7g":"C09-Q014-P073","1ijq2qq":"C09-Q015-P074","ts6cs8":"C09-Q016-P074","bmryqp":"C09-Q017-P074","18y77hh":"C09-Q018-P074","1sjdoa5":"C09-Q019-P074","17quevb":"C09-Q020-P075","5w5eul":"C09-Q021-P075","7eqz6y":"C09-Q022-P075","1p32eke":"C09-Q023-P075","5pdsmw":"C09-Q024-P075","4qn7wy":"C09-Q025-P075","cfcmcn":"C09-Q026-P076","1bflduq":"C09-Q027-P076","19ihu27":"C09-Q028-P076","1ef1krt":"C09-Q029-P076","12s4lci":"C09-Q030-P076","16cj0ym":"C09-Q031-P076","1ioue41":"C09-Q032-P076","109mwvg":"C09-Q033-P076","tt50wy":"C09-Q034-P076","1sxtft6":"C09-Q035-P077","7u6a7y":"C09-Q036-P077","18k8650":"C09-Q037-P077","1kectmr":"C09-Q038-P077","r0lssc":"C09-Q039-P077","jhjawy":"C09-Q040-P077","1zo4qk":"C09-Q041-P078","1ngknls":"C09-Q042-P078","1moxjcy":"C09-Q043-P078","7y0c1y":"C09-Q044-P078","7kyhb0":"C09-Q045-P078","1osokp6":"C09-Q046-P079","1uloz52":"C09-Q047-P079","1ntr6b0":"C09-Q048-P079","1v0fzi6":"C09-Q049-P079","ilg7bb":"C09-Q050-P080","6kv8fr":"C09-Q051-P080","6zo8st":"C09-Q052-P080","q871zh":"C09-Q053-P080","yro65e":"C09-Q054-P081","12msmsx":"C09-Q055-P081","9d7uqj":"C09-Q056-P081","1js5lgn":"C09-Q057-P081","vbf9mu":"C09-Q058-P082","1tk2ruk":"C09-Q059-P082","139pnuv":"C09-Q060-P082","170e971":"C09-Q061-P082","10mraic":"C09-Q062-P082","16v4vyj":"C09-Q063-P083","1ozr9qt":"C09-Q064-P083","1k370r6":"C09-Q065-P083","6am0t3":"C09-Q066-P083","10h0zyi":"C09-Q067-P083","wo3qrc":"C09-Q068-P083","1a3d8a8":"C09-Q069-P084","104iqed":"C09-Q070-P084","gerkpd":"C09-Q071-P084","pif520":"C09-Q072-P084","fhz30o":"C09-Q073-P084","1glj1y1":"C09-Q074-P085","1dksupo":"C09-Q075-P085","y7g44w":"C09-Q076-P085","1dtl3q6":"C09-Q077-P085","14amfdb":"C09-Q078-P085","nnrhq0":"C09-Q079-P086","17i5ch6":"C09-Q080-P086","1cmhgi1":"C09-Q081-P086","13r5wzo":"C09-Q082-P086","kezac0":"C09-Q083-P086","1a89bsr":"C10-Q001-P087","e3zhq4":"C10-Q002-P087","4ugw5n":"C10-Q003-P087","1gckgp7":"C10-Q004-P088","4h3q8o":"C10-Q005-P088","otqhwq":"C10-Q006-P088","5us9ob":"C10-Q007-P088","1dejir1":"C10-Q008-P088","1f8sdfp":"C10-Q009-P088","1cu8d8r":"C10-Q010-P088","azg1f5":"C10-Q011-P089","1p0jvas":"C10-Q012-P089","tzq53f":"C10-Q013-P089","z51hk8":"C10-Q014-P089","1tnx101":"C10-Q015-P089","1da64g4":"C10-Q016-P089","1wkrpr1":"C11-Q001-P090","b3kz9m":"C11-Q002-P090","1stynic":"C11-Q003-P090","ijiovt":"C11-Q004-P091","laqcsz":"C11-Q005-P091","2t1yes":"C11-Q006-P091","6i6ngr":"C11-Q007-P091","gk2ozu":"C11-Q008-P091","vh3u2s":"C11-Q009-P091","avv7qe":"C11-Q010-P091","xvjmnw":"C11-Q011-P091","1qh9x0y":"C11-Q012-P092","1v7vrpo":"C11-Q013-P092","1efa13k":"C11-Q014-P092","a6v3s8":"C11-Q015-P092","10sf1nn":"C11-Q016-P093","100ghl1":"C11-Q017-P093","15y91gd":"C11-Q018-P093","1qwd1h":"C11-Q019-P093","1fskqpv":"C11-Q020-P094","1h9shx3":"C11-Q021-P094","uqkhk5":"C11-Q022-P094","qeoga4":"C11-Q023-P094","1jcjl3z":"C11-Q024-P094","1xh01d9":"C11-Q025-P094","1ak43ts":"C11-Q026-P094","9n3kk4":"C11-Q027-P095","y140tt":"C11-Q028-P095","dhhqli":"C11-Q029-P095","18i3d4":"C11-Q030-P095","s8sep1":"C11-Q031-P095","n1qydf":"C11-Q032-P096","udgwmc":"C11-Q033-P096","13cb034":"C11-Q034-P096","1dy5ozr":"C11-Q035-P096","1jv30p7":"C11-Q036-P096","g1xwi4":"C11-Q037-P096","1698v5":"C11-Q038-P096","1yiuo3s":"C11-Q039-P097","19w7kxh":"C11-Q040-P097","1u7gqmb":"C11-Q041-P097","110j5j6":"C11-Q042-P097","sf6mej":"C11-Q043-P097","czfg6z":"C11-Q044-P098","qhk0zs":"C11-Q045-P098","13rbf0l":"C11-Q046-P098","imw67c":"C11-Q047-P098","ju3hz3":"C11-Q048-P098","3zs0il":"C11-Q049-P098","1dqwt3k":"C11-Q050-P098","1ocha22":"C11-Q051-P099","15qtp4n":"C11-Q052-P099","m0a9fl":"C11-Q053-P099","pr2cg4":"C11-Q054-P099","18fp5gu":"C11-Q055-P099","1hh3ddj":"C11-Q056-P100","144b6u0":"C11-Q057-P100","1ttgjt8":"C11-Q058-P100","1p4ozlu":"C11-Q059-P100","1xmie26":"C11-Q060-P100","17lgj2u":"C11-Q061-P100","g5jndz":"C11-Q062-P101","jhexw0":"C11-Q063-P101","7bmeaf":"C11-Q064-P101","g6cdkv":"C11-Q065-P101","gx1p3":"C11-Q066-P101","rq78h3":"C11-Q067-P101","1smjigz":"C12-Q001-P102","13t2xbh":"C12-Q002-P102","1tyfkhw":"C12-Q003-P102","89qpg8":"C12-Q004-P102","1yzatwo":"C12-Q005-P103","15iqsel":"C12-Q006-P103","1pfk8mw":"C12-Q007-P103","k9yqmp":"C12-Q008-P103","pnbn48":"C12-Q009-P103","1qwgwn5":"C12-Q010-P104","1ku6r64":"C12-Q011-P104","99n1t9":"C12-Q012-P104","12pbnck":"C12-Q013-P104","3od5km":"C12-Q014-P105","kq3pzw":"C12-Q015-P105","4kez08":"C12-Q016-P105","13csji":"C12-Q017-P105","9vc1mi":"C13-Q001-P106","n3fhzj":"C13-Q002-P106","4xu3pu":"C13-Q003-P107","wa3hgg":"C13-Q004-P107","1ufz4x2":"C13-Q005-P107","gu1tqk":"C13-Q006-P107","5hz7ue":"C13-Q007-P107","1vhvdvj":"C13-Q008-P107","1isv283":"C13-Q009-P107","uu3u6h":"C13-Q010-P108","2h686h":"C13-Q011-P108","s83oa8":"C13-Q012-P108","1jk1saf":"C13-Q013-P108","jqk4rr":"C13-Q014-P108","1thprwk":"C13-Q015-P109","1s1ng4o":"C13-Q016-P109","11mqrfz":"C13-Q017-P109","131d3th":"C13-Q018-P109","1o12xu9":"C13-Q019-P109","posu26":"C13-Q020-P109","pquq9a":"C13-Q021-P110","xllcs0":"C13-Q022-P110","1niakhk":"C13-Q023-P110","1rp3u1y":"C13-Q024-P110","3jbvcp":"C13-Q025-P110","f0tlya":"C13-Q026-P111","1x25bkb":"C13-Q027-P111","1jmtdr4":"C13-Q028-P111","gyxlwg":"C13-Q029-P111","zmriht":"C13-Q030-P112","i3kiax":"C13-Q031-P112","n0ni4":"C13-Q032-P112","1qhoyz8":"C13-Q033-P112","1lhu1kk":"C13-Q034-P112","sfsvn4":"C13-Q035-P112","wayat2":"C13-Q036-P112","4bq39b":"C13-Q037-P113","pitqk6":"C13-Q038-P113","1cmwcy8":"C13-Q039-P113","4jajhq":"C13-Q040-P113","c0ipbx":"C13-Q041-P113","na3qok":"C13-Q042-P114","12w1yhc":"C13-Q043-P114","vjgzpw":"C13-Q044-P114","1ikeech":"C13-Q045-P114","967av4":"C13-Q046-P114","z9wbes":"C13-Q047-P114","1b2h3w0":"C13-Q048-P115","16gh09k":"C13-Q049-P115","1pdn5bg":"C13-Q050-P115","1hnp6k5":"C13-Q051-P115","lo4n3e":"C13-Q052-P115","1auxqz9":"C13-Q053-P115","57ak1r":"C13-Q054-P115","1avqfjq":"C13-Q055-P116","5s7pl3":"C13-Q056-P116","4w9fgl":"C13-Q057-P116","14qt480":"C13-Q058-P116","1ty6xco":"C13-Q059-P116","h10zot":"C13-Q060-P117","9fb67h":"C13-Q061-P117","p60hk1":"C13-Q062-P117","8t2h8o":"C13-Q063-P117","1fws2dr":"C13-Q064-P117","vdnfft":"C13-Q065-P118","1g0nk4s":"C13-Q066-P118","11lipdg":"C13-Q068-P118","etc924":"C13-Q069-P118","10pm8p3":"C13-Q070-P118","1bmge60":"C13-Q071-P119","annfe0":"C13-Q072-P119","1bydzu7":"C13-Q073-P119","72rb73":"C13-Q074-P119","k7ru98":"C13-Q075-P119","18a54od":"C13-Q076-P120","1utjodv":"C13-Q077-P120","e3egi1":"C13-Q078-P120","bzefj":"C13-Q079-P120","125075t":"C13-Q080-P120","1jx7241":"C13-Q081-P120","f3hzwf":"C13-Q082-P120","19niqdx":"C13-Q083-P120","1bz4mgs":"C13-Q084-P121","10h7qve":"C13-Q085-P121","u4s7j8":"C13-Q086-P121","qpdnny":"C13-Q087-P121","1wa950g":"C13-Q088-P122","gyeh01":"C13-Q089-P122","rfq660":"C13-Q090-P122","vcize4":"C13-Q091-P122","4uth4y":"C13-Q092-P122","vyofi8":"C13-Q093-P122","1nbavrv":"C13-Q094-P123","zk7kh8":"C13-Q095-P123","l4m9uf":"C13-Q096-P123","1xseqnp":"C13-Q097-P123","1j2h3no":"C13-Q098-P123","452bln":"C13-Q099-P124","10nb8ap":"C13-Q100-P124","10mye2h":"C13-Q101-P124","itj2wz":"C13-Q102-P124","ju12j8":"C13-Q103-P124","59pwmp":"C13-Q104-P124","b4qmcr":"C13-Q105-P124","1uosylj":"C13-Q106-P125","1t9kr2r":"C13-Q107-P125","hbf6wl":"C13-Q108-P125","1v20j2v":"C13-Q109-P125","1hle3x4":"C13-Q110-P125","1qm8abw":"C13-Q111-P126","13gs2cx":"C13-Q112-P126","xq8ft0":"C13-Q113-P126","z2jo5u":"C13-Q114-P126","13cm084":"C13-Q115-P126","1x5wk0r":"C13-Q116-P127","3rslx9":"C13-Q117-P127","bwymcp":"C13-Q118-P127","1dbz71i":"C13-Q119-P127","xlb26g":"C13-Q120-P127","j70btm":"C13-Q121-P127","1fzvb98":"C13-Q122-P128","1ej8ay7":"C13-Q123-P128","i9423r":"C13-Q124-P128","1vtga2a":"C13-Q125-P128","pl2eyh":"C13-Q126-P129","73d6jp":"C13-Q127-P129","1jfvn11":"C13-Q128-P129","pmsn0q":"C13-Q129-P130","r1l8uc":"C13-Q130-P130","1n8x9qv":"C13-Q131-P130","6bdf9c":"C13-Q132-P130","2g6as3":"C13-Q133-P130","1u407tu":"C13-Q134-P130","1ilidja":"C13-Q135-P130","1qz23e0":"C13-Q136-P131","1yd9d1o":"C13-Q137-P131","17shww7":"C13-Q138-P131","1b7bk0r":"C13-Q139-P131","ox9fma":"C13-Q140-P131","k3w4ba":"C13-Q141-P131","1d5l0g":"C13-Q142-P131","1rmhxi0":"C13-Q143-P131","1vyjh76":"C13-Q144-P132","1ys9r34":"C13-Q145-P132","dkgy3l":"C13-Q146-P132","2pus7n":"C13-Q147-P132","uzpkww":"C13-Q148-P132","1afnz9q":"C13-Q149-P132","14oefq2":"C13-Q150-P132","5vjnio":"C13-Q151-P132","rbm878":"C13-Q152-P133","kp2cxr":"C13-Q153-P133","10fsmg3":"C13-Q154-P133","1o7fogs":"C13-Q155-P133","kxy0tg":"C13-Q156-P134","14bajhk":"C13-Q157-P134","lzkt5y":"C13-Q158-P134","1i9puk2":"C13-Q159-P134","15okkpl":"C13-Q160-P134","1tsc5w5":"C13-Q161-P134","diwre3":"C13-Q162-P135","16y0v6z":"C13-Q163-P135","11ay9se":"C13-Q164-P135","1hd0p08":"C13-Q165-P135","1exlnzi":"C13-Q166-P135","17ursn5":"C13-Q167-P135","oe1hh":"C13-Q168-P136","1fy23sx":"C13-Q169-P136","1f9souu":"C14-Q001-P138","yhsore":"C14-Q002-P138","9vmt4p":"C14-Q003-P138","faillm":"C14-Q004-P138","hv08ad":"C14-Q005-P139","v59c0t":"C14-Q006-P139","1jmv7z4":"C14-Q007-P139","wxyja":"C14-Q008-P139","17xuva6":"C14-Q009-P139","xe4edt":"C14-Q010-P139","h231sx":"C14-Q011-P140","1ipsyjg":"C14-Q012-P140","2t0euv":"C14-Q013-P140","1etw98n":"C14-Q014-P140","1a0q56j":"C14-Q015-P140","1p4ohlk":"C14-Q016-P140","q658xs":"C14-Q017-P140","2bdsmk":"C14-Q018-P141","1qb6sk8":"C14-Q019-P141","64ey6u":"C14-Q020-P141","1s4n0ec":"C14-Q021-P141","1ou9dy8":"C14-Q022-P141","1ohmi9":"C14-Q023-P141","zsh6ou":"C14-Q024-P141","1uwlhsp":"C14-Q025-P142","18klab1":"C14-Q026-P142","1j4zjtw":"C14-Q027-P142","uv3pxs":"C14-Q028-P142","1so52db":"C14-Q029-P142","1xvwukx":"C14-Q030-P142","1dfmjlk":"C14-Q031-P142","hbbckx":"C14-Q032-P143","o7b471":"C14-Q033-P143","1t53wki":"C14-Q034-P143","12thx5v":"C14-Q035-P143","1wu7i3i":"C14-Q036-P144","1p31ytr":"C14-Q037-P144","1c23p7y":"C14-Q038-P144","1k3b19j":"C14-Q039-P144","6dcllv":"C14-Q040-P144","1rl8gdb":"C14-Q041-P145","k6vq10":"C14-Q042-P145","1dxoo4z":"C14-Q043-P145","14ug189":"C14-Q044-P145","bckmfg":"C14-Q045-P145","xz0zre":"C14-Q046-P145","16o6oto":"C14-Q047-P145","jh82yi":"C14-Q048-P146","6qu7qn":"C14-Q049-P146","1aapdnh":"C14-Q050-P146","17j5hhp":"C14-Q051-P146","151zowk":"C14-Q052-P146","1i13h65":"C14-Q053-P146","1hxxqlk":"C14-Q054-P147","c25xmb":"C14-Q055-P147","1d1ha3f":"C14-Q056-P147","1vtjyq5":"C14-Q057-P147","sthnt8":"C14-Q058-P147","hyhjg8":"C14-Q059-P148","qvxcw8":"C14-Q060-P148","1xv0u62":"C14-Q061-P148","1p7kzyl":"C14-Q062-P149","1laeomb":"C14-Q063-P149","1xjkm7s":"C14-Q064-P149","lmh0ct":"C14-Q065-P149","7melj4":"C14-Q066-P149","lde6hx":"C14-Q067-P149","g4h494":"C14-Q068-P150","pzyz81":"C15-Q001-P150","1ybx3kf":"C15-Q002-P151","1w3hf8l":"C15-Q003-P151","1kffywz":"C15-Q004-P151","19vby4y":"C15-Q005-P151","11fiqz5":"C15-Q006-P151","rh2d49":"C15-Q007-P151","usc2rx":"C15-Q008-P151","10f7hde":"C15-Q009-P151","ts8hl0":"C15-Q010-P152","nhrj2p":"C15-Q011-P152","gzvj16":"C15-Q012-P152","1kz2cgh":"C15-Q013-P152","ep4xf5":"C15-Q014-P152","hgur4d":"C15-Q015-P152","1n3tssn":"C15-Q016-P152","15oduik":"C15-Q017-P152","17043h5":"C15-Q018-P153","psboyc":"C15-Q019-P153","1xhoido":"C15-Q020-P153","11bzjj0":"C15-Q021-P153","1dph0ej":"C15-Q022-P153","bjdo5y":"C15-Q023-P153","152ig1l":"C15-Q024-P153","1r8qr4s":"C15-Q025-P153","1kxwc6o":"C15-Q026-P154","n8vrbs":"C15-Q027-P154","1kxbo2c":"C15-Q028-P154","1u66ws2":"C15-Q029-P154","1emrvti":"C15-Q030-P154","gaa8fu":"C15-Q031-P155","107th8":"C15-Q032-P155","190w2vy":"C15-Q033-P155","1xyk08l":"C15-Q034-P155","1drbifu":"C15-Q035-P155","gqywyn":"C15-Q036-P155","um2ggw":"C15-Q037-P155","s1wlbp":"C15-Q038-P155","xr8y67":"C15-Q039-P156","1aog2yd":"C15-Q040-P156","1q99nwx":"C15-Q041-P156","1l0pca7":"C16-Q001-P157","lhyhro":"C16-Q002-P158","11rwta8":"C16-Q003-P158","1ilvycz":"C16-Q004-P158","59nnr7":"C16-Q005-P158","y0k0cs":"C16-Q006-P159","1hjyl3c":"C16-Q007-P159","1ntctt2":"C16-Q008-P159","1kbbly9":"C16-Q009-P159","1r4tc7p":"C16-Q010-P159","w99f7p":"C16-Q011-P159","1yjikls":"C16-Q012-P159","113kobf":"C16-Q013-P159","1oo7n22":"C16-Q014-P160","1ozw66u":"C16-Q015-P160","1lzq0va":"C16-Q016-P160","a5nvtz":"C16-Q017-P160","8b92lv":"C16-Q018-P160","1c747l8":"C16-Q019-P160","47d8os":"C16-Q020-P161","ay0e5g":"C16-Q021-P161","54g7jp":"C16-Q022-P161","1stx0ex":"C16-Q023-P161","ve8241":"C16-Q024-P161","19fdhgv":"C16-Q025-P161","11abxki":"C16-Q026-P161","4ovlzm":"C16-Q027-P161","1tgkqca":"C16-Q028-P162","dg2l7q":"C16-Q029-P162","x5uub4":"C16-Q030-P162","79c8ba":"C16-Q031-P162","p5m5l1":"C16-Q032-P163","q72x0":"C16-Q033-P163","6fzf4d":"C16-Q034-P164","1pau9zg":"C16-Q035-P164","1fvs52b":"C16-Q036-P164","hvdt5e":"C16-Q037-P164","sr360y":"C16-Q038-P164","x8xyw":"C16-Q039-P165","1y9i82t":"C16-Q040-P165","4lb7bt":"C16-Q041-P165","zvu6eg":"C16-Q042-P165","1ekfd9h":"C16-Q043-P165","1jfepcc":"C16-Q044-P166","1q6dd16":"C16-Q045-P166","d1aale":"C16-Q046-P166","1d0qiki":"C16-Q047-P166","1x3v7qk":"C16-Q048-P166","hy75mj":"C16-Q049-P166","ea4rbv":"C16-Q050-P166","17xquh3":"C16-Q051-P166","bp67pf":"C16-Q052-P167","pua9au":"C16-Q053-P167","1puar3q":"C16-Q054-P167","o32reb":"C16-Q055-P167","vysw0e":"C16-Q056-P167","naionf":"C16-Q057-P167","5dw8mh":"C16-Q058-P167","1ropc9k":"C16-Q059-P168","1p2ffay":"C16-Q060-P168","psoxpo":"C16-Q061-P168","3mv3u8":"C16-Q062-P168","109sozx":"C16-Q063-P168","1j5587w":"C16-Q064-P168","ztnlxk":"C16-Q065-P168","l2q8fe":"C16-Q066-P168","12jq4zo":"C16-Q067-P169","1n9vfry":"C16-Q068-P169","l9q21j":"C16-Q069-P169","ugt7g1":"C16-Q070-P169","6xrthv":"C16-Q071-P169","8n38hd":"C16-Q072-P169","1vk6piu":"C16-Q073-P169","19rss0q":"C16-Q074-P170","ea9j09":"C16-Q075-P170","butvk3":"C16-Q076-P170","w6n93y":"C16-Q077-P170","5atq3e":"C16-Q078-P170","10lwbo5":"C16-Q079-P171","64ewur":"C16-Q080-P171","14tjtqc":"C16-Q081-P171","1tnh0j7":"C16-Q082-P171","h13l5j":"C16-Q083-P171","nehx7g":"C16-Q084-P171","14f9if8":"C16-Q085-P172","15vipgv":"C16-Q086-P172","kqiq84":"C16-Q087-P172","1u8qepk":"C16-Q088-P172","uspjhp":"C16-Q089-P172","26kjxj":"C16-Q090-P173","1dts53":"C16-Q091-P173","ntnmgx":"C16-Q092-P173","s0m1p3":"C16-Q093-P173","etr74b":"C16-Q094-P173","1j2v9yu":"C16-Q095-P174","10cx3bk":"C16-Q096-P174","jcivz6":"C16-Q097-P174","13kseqg":"C16-Q098-P174","kuaz7l":"C16-Q099-P174","bk7sbf":"C16-Q100-P174","1tqae09":"C16-Q101-P175","ua3u6p":"C16-Q102-P175","mwxdhr":"C16-Q103-P175","41oxl":"C16-Q104-P175","ayysee":"C16-Q105-P175","qbsnp1":"C16-Q106-P175","go15bq":"C16-Q107-P175","1hodftb":"C16-Q108-P176","ywdvws":"C16-Q109-P176","rdlmt1":"C16-Q110-P176","18pps2q":"C16-Q111-P176","1u3hmra":"C16-Q112-P176","wjib4u":"C16-Q113-P177","1fd0tzz":"C16-Q114-P177","fm0dyp":"C16-Q115-P177","ggyrpk":"C16-Q116-P177","ohpxbj":"C16-Q117-P177","1x9wtqp":"C16-Q118-P177","1iswee4":"C16-Q119-P177","lrf7jc":"C16-Q120-P177","h8yhqg":"C16-Q121-P177","1ar2llm":"C16-Q122-P178","1ybgn8u":"C16-Q123-P178","mgj64r":"C16-Q124-P178","cvf5mv":"C16-Q125-P178","sjcmx6":"C16-Q126-P178","e68xsr":"C16-Q127-P178","r7tl71":"C16-Q128-P178","1kwmaq3":"C16-Q129-P178","13hd2zp":"C16-Q130-P179","1169l20":"C16-Q131-P179","zeur01":"C16-Q132-P179","a715uc":"C16-Q133-P179","ydssh2":"C16-Q134-P179","1yz8r65":"C16-Q135-P179","1wkpdbn":"C17-Q001-P180","1ajloha":"C17-Q002-P180","1ji9dpw":"C17-Q003-P180","1qpnyn5":"C17-Q004-P180","197h3tc":"C17-Q005-P180","ktaftl":"C17-Q006-P181","ktre8i":"C17-Q007-P181","ifgmpv":"C17-Q008-P181","15kv3o2":"C17-Q009-P181","kr2io5":"C17-Q010-P181","1qkx107":"C17-Q011-P182","si75ml":"C17-Q012-P182","1nanwpl":"C17-Q013-P182","9x902c":"C17-Q014-P182","aqd36":"C17-Q015-P182","7pw82g":"C17-Q016-P182","hmi7uu":"C17-Q017-P183","1aiu8pr":"C17-Q018-P183","1wkljgk":"C17-Q019-P183","rqjd0v":"C17-Q020-P183","1wdqwhz":"C17-Q021-P183","xb8ozw":"C17-Q022-P183","j2jt93":"C17-Q023-P183","qfgnob":"C18-Q001-P184","jaz2j1":"C18-Q002-P184","1nkmn49":"C18-Q003-P185","tjtp9o":"C18-Q004-P185","9pafyf":"C18-Q005-P185","1jwjz85":"C18-Q006-P185","9o4ofk":"C18-Q007-P185","vh6713":"C18-Q008-P186","1lho2qh":"C18-Q009-P186","1xorccy":"C18-Q010-P186","axhs7a":"C18-Q011-P186","1kiy4da":"C18-Q012-P186","f7qbet":"C18-Q013-P187","1b9p0mh":"C18-Q014-P187","12o0eea":"C18-Q015-P187","tas5kh":"C18-Q016-P187","1qpvl3b":"C18-Q017-P187","4lpr5c":"C18-Q018-P187","r6xgwo":"C18-Q019-P188","c379tk":"C18-Q020-P188","17gzb99":"C18-Q021-P188","lhgi7c":"C18-Q022-P188","fi6gyv":"C18-Q023-P188","16rp74x":"C18-Q024-P188","15148p9":"C18-Q025-P188","19rdm0v":"C18-Q026-P189","1ifplf0":"C18-Q027-P189","14geswt":"C18-Q028-P189","1obyl10":"C18-Q029-P189","jrznlv":"C18-Q030-P189","1m4cl7n":"C18-Q031-P189","1lhsdco":"C18-Q032-P189","nfi6ta":"C18-Q033-P189","1rqczc5":"C18-Q034-P189","d5pqpy":"C18-Q035-P190","1hqg2xe":"C18-Q036-P190","1ml842h":"C18-Q037-P190","5hly57":"C18-Q038-P190","yx6tri":"C18-Q039-P190","1cc3pgx":"C18-Q040-P190","1w01jyb":"C18-Q041-P191","148sqkl":"C18-Q042-P191","8jb4sj":"C18-Q043-P191","1ic6xng":"C18-Q044-P191","1pal0o9":"C18-Q045-P191","1a0nzjj":"C18-Q046-P191","h5ctjc":"C18-Q047-P192","1dz3920":"C18-Q048-P192","146s2ro":"C18-Q049-P192","n217na":"C18-Q050-P192","1osboep":"C18-Q051-P192","1dhkord":"C18-Q052-P192","g5dhkw":"C18-Q053-P193","51mzhn":"C18-Q054-P193","16b4t7s":"C18-Q055-P193","mydq8e":"C18-Q056-P193","5orjyr":"C18-Q057-P193","19lhfyz":"C18-Q058-P194","1b4n9sf":"C18-Q059-P194","qhyp3t":"C18-Q060-P194","1wrnqkg":"C18-Q061-P194","1sfh71h":"C18-Q062-P194","git6y2":"C18-Q063-P194","w2p2ad":"C18-Q064-P194","1lzyqte":"C18-Q065-P194","10u862q":"C18-Q066-P195","1gu1u3s":"C18-Q067-P195","1q8t2mr":"C18-Q068-P195","1s2pklg":"C18-Q069-P195","urvbxk":"C18-Q070-P195","2id2ki":"C18-Q071-P196","1c9abm6":"C18-Q072-P196","1eilz1h":"C18-Q073-P196","1o5b2e0":"C18-Q074-P196","g6x68o":"C18-Q075-P196","mjjfts":"C18-Q076-P197","9ds3et":"C18-Q077-P197","1iwi2vt":"C18-Q078-P197","isyk9q":"C18-Q079-P197","1pp38rw":"C18-Q080-P197","121gw4y":"C18-Q081-P197","z3a19z":"C18-Q082-P198","yzs6n0":"C18-Q083-P198","zjueme":"C18-Q084-P198","haswao":"C18-Q085-P198","87tdc5":"C18-Q086-P198","1jhfc0t":"C18-Q087-P198","15ogzpw":"C18-Q088-P199","fbde43":"C18-Q089-P199","14pcpnc":"C18-Q090-P199","1w4frh4":"C18-Q091-P199","1hzhabq":"C18-Q092-P199","st10bj":"C19-Q001-P200","1crs13y":"C19-Q002-P200","ybey80":"C19-Q003-P200","1o6ws6e":"C19-Q004-P200","8c2ras":"C19-Q005-P200","1u2w674":"C19-Q006-P200","164soml":"C19-Q007-P200","iqndyt":"C19-Q008-P201","152svkc":"C19-Q009-P201","viqa3h":"C19-Q010-P201","gt33hg":"C19-Q011-P201","ftjwmt":"C19-Q012-P201","jbzomr":"C19-Q013-P201","15jjmtp":"C19-Q014-P202","1jzj3fr":"C19-Q015-P202","2fpe0v":"C19-Q016-P202","6ndfoj":"C19-Q017-P202","xxs95j":"C19-Q018-P202","15u2c3p":"C19-Q019-P203","rwz4jk":"C19-Q020-P203","gcw4pe":"C19-Q021-P203","1mxxr9m":"C19-Q022-P203","1ofk6":"C19-Q023-P203","1nxubtu":"C19-Q024-P203","hqmnqr":"C19-Q025-P203","um8pgz":"C19-Q026-P204","1pnnyc1":"C19-Q027-P204","s0q6er":"C19-Q028-P204","1wbob2p":"C19-Q029-P204","1qit3is":"C19-Q031-P204","lgishs":"C19-Q032-P204","1sd2hvj":"C19-Q033-P204","q7yjh1":"C19-Q034-P205","7mezyz":"C19-Q035-P205","xeylgi":"C19-Q036-P205","822hp8":"C19-Q037-P205","13sha12":"C19-Q038-P205","k2hok":"C19-Q039-P205","klqw4i":"C19-Q040-P205","1dl6zgj":"C19-Q041-P206","1iriand":"C19-Q042-P206","1tklpg6":"C19-Q043-P206","vlfcpm":"C19-Q044-P206","5s23d5":"C19-Q045-P206","sekznv":"C19-Q046-P207","ogikbl":"C19-Q047-P207","godn6o":"C19-Q048-P207","iega30":"C19-Q049-P207","rcn8wa":"C19-Q050-P207","1e7s2a1":"C19-Q051-P207","khuo4t":"C19-Q052-P208","1f0a9mz":"C19-Q053-P208","lby7zm":"C19-Q054-P208","t44psb":"C19-Q055-P208","w5ubjq":"C19-Q056-P208","rlfzii":"C19-Q057-P209","lmrpv8":"C19-Q058-P209","6rve44":"C19-Q059-P209","15bngy4":"C19-Q060-P209","mq4har":"C19-Q061-P209","15cvak5":"C19-Q062-P209","1kkbxp7":"C19-Q063-P210","1vr6ghl":"C20-Q001-P211","1uykzab":"C20-Q003-P212","okixio":"C20-Q004-P212","17nuscv":"C20-Q005-P212","1oqq1g6":"C20-Q006-P212","qabqhi":"C20-Q007-P212","7e131k":"C21-Q001-P213","47jmyi":"C21-Q002-P213","115y4j2":"C21-Q003-P214","wcfsgd":"C21-Q004-P214","9p6axi":"C21-Q005-P214","3iwo6v":"C21-Q006-P214","13nmhlp":"C21-Q007-P214","yi4ymd":"C21-Q008-P214","1d5h9e1":"C21-Q009-P214","1xr5fcg":"C21-Q010-P214","1ujv71x":"C21-Q011-P215","hcqgz8":"C21-Q012-P215","w4zz7g":"C21-Q013-P215","hbpz7b":"C21-Q014-P215","1syx26q":"C21-Q015-P215","d3uwpg":"C21-Q016-P215","183thhh":"C21-Q017-P215","1spbhw3":"C21-Q018-P216","1myrt90":"C21-Q019-P216","722sod":"C21-Q020-P216","ofymbd":"C21-Q021-P216","azc4ok":"C21-Q022-P216","1hnzp49":"C21-Q023-P216","1n5m37d":"C21-Q024-P217","xfj7wb":"C21-Q025-P217","ze0aqv":"C21-Q026-P217","106rvsf":"C21-Q027-P217","1hcb2vs":"C21-Q028-P217","1yvtr87":"C21-Q029-P217","lnsuw1":"C21-Q030-P217","1hsfn0e":"C21-Q031-P217","1vxvb1s":"C21-Q032-P218","f6b4yr":"C21-Q033-P218","1gqwoj5":"C21-Q034-P218","4wn756":"C21-Q035-P218","hhu5w2":"C21-Q036-P218","mmpkx2":"C21-Q037-P218","t3qj0s":"C21-Q038-P219","1uoxwrc":"C21-Q039-P219","1luwotl":"C21-Q040-P219","1adgfto":"C21-Q041-P219","12a7nea":"C21-Q042-P219","1ytqb0w":"C21-Q043-P219","9eoylr":"C21-Q044-P219","17axlvz":"C21-Q045-P219","vccqyf":"C21-Q046-P220","1o0frmu":"C21-Q047-P220","1ao84fk":"C21-Q048-P220","vf124b":"C21-Q049-P220","9azgw4":"C21-Q050-P220","b7qovm":"C21-Q051-P220","qyxout":"C21-Q052-P220","1mbavy8":"C21-Q053-P221","145d2ub":"C21-Q054-P221","tdwwzb":"C21-Q055-P221","bsbcg5":"C21-Q056-P221","165c1b2":"C21-Q057-P221","5s1ndt":"C21-Q058-P221","rzaqj1":"C21-Q059-P222","zi2z94":"C21-Q060-P222","1ubjq0x":"C21-Q061-P222","9l1bb1":"C21-Q062-P222","zwvcqi":"C21-Q063-P222","bg9out":"C21-Q064-P222","wockyo":"C21-Q065-P222","ytjzvb":"C21-Q066-P222","txg36q":"C21-Q067-P223","14gdaz":"C21-Q068-P223","i6sla8":"C21-Q069-P223","1wor8al":"C21-Q070-P223","1grv65w":"C21-Q071-P223","1l2csa":"C21-Q072-P223","1itjxfk":"C21-Q073-P224","1vt2u8s":"C21-Q074-P224","ya6g25":"C21-Q075-P224","mgkrev":"C21-Q076-P224","1kksvql":"C21-Q077-P224","18ctl5j":"C21-Q078-P224","10fb2e6":"C21-Q079-P224","1c03jcn":"C21-Q080-P225","oamy0m":"C21-Q082-P225","jxctov":"C21-Q083-P225","zu7eiy":"C21-Q084-P226","3el2ih":"C21-Q085-P226","1bu5eyz":"C21-Q086-P226","pzc40o":"C21-Q087-P226","2qcs5l":"C21-Q088-P227","vbgx63":"C21-Q089-P227","7oggx3":"C21-Q090-P227","1i4i235":"C21-Q091-P227","5iakv5":"C21-Q092-P228","9wnt47":"C21-Q093-P228","1uk83gq":"C21-Q094-P228","1a2giw9":"C21-Q095-P228","1e29m54":"C21-Q096-P228","youra8":"C21-Q097-P228","165e84x":"C21-Q098-P228","bgs9cw":"C21-Q099-P229","563l5c":"C21-Q100-P229","1bun7rr":"C21-Q101-P229","17c8ksa":"C21-Q102-P229","pkeetj":"C21-Q103-P229","1si7dk7":"C21-Q104-P229","8nmukg":"C21-Q105-P230","ydxaqm":"C21-Q106-P230","10fpc2m":"C21-Q107-P230","158zyb2":"C21-Q108-P230","j3of6e":"C22-Q001-P231","1545hi3":"C22-Q002-P232","1ofhx5":"C22-Q003-P232","1ey6lhs":"C22-Q004-P232","5s8lul":"C22-Q005-P232","1gluhvk":"C22-Q006-P232","muhcgd":"C22-Q007-P232","1uz4y5u":"C22-Q008-P233","2w9914":"C22-Q009-P233","m260uq":"C22-Q010-P233","19axr4p":"C22-Q011-P233","1a0qmab":"C22-Q012-P233","1ypf9qx":"C22-Q013-P233","pnruf3":"C22-Q014-P233","5cx04j":"C22-Q015-P234","i2iyzw":"C22-Q016-P234","izh2kf":"C22-Q017-P234","u32rk8":"C22-Q018-P234","9qhpul":"C22-Q019-P234","jlve3i":"C22-Q020-P234","qp754t":"C22-Q021-P234","1g08kge":"C22-Q022-P234","1fip5pn":"C22-Q023-P235","l3gap0":"C22-Q024-P235","sgdymd":"C22-Q025-P235","iovumj":"C22-Q026-P235","oevrds":"C22-Q027-P235","zqt30y":"C22-Q028-P236","r4e2rb":"C22-Q029-P236","leqez1":"C22-Q030-P236","muzj5j":"C22-Q031-P236","1ovv80n":"C22-Q032-P236","irpoiz":"C22-Q033-P237","j9bsbt":"C22-Q034-P237","xntcwp":"C22-Q035-P237","dpoftd":"C22-Q036-P237","nhdaoj":"C22-Q037-P238","729g5e":"C22-Q038-P238","suhspa":"C22-Q039-P238","1bwtb5":"C22-Q040-P238","19suib3":"C22-Q041-P238","1drzlcp":"C22-Q042-P238","7yznvp":"C22-Q043-P239","1h5ylb9":"C22-Q044-P239","15kg14y":"C22-Q045-P239","11dh9m6":"C22-Q046-P239","1lde3k9":"C22-Q047-P240","sgavdp":"C22-Q048-P240","1srnadj":"C22-Q049-P240","1ina3uu":"C22-Q050-P240","j3c7ae":"C22-Q051-P240","5g4of0":"C22-Q052-P240","1olzzc3":"C22-Q053-P241","1niv1xc":"C22-Q054-P241","1qf3168":"C22-Q055-P241","drdtcu":"C22-Q056-P241","6blwri":"C22-Q057-P241","188gihw":"C22-Q058-P241","g0sji0":"C22-Q059-P241","17q5kjp":"C22-Q060-P242","1qd9yeq":"C22-Q061-P242","d13ttr":"C22-Q062-P242","gsw5uc":"C22-Q063-P242","1pbdmjb":"C22-Q064-P242","zla71u":"C23-Q001-P243","1ryms53":"C23-Q002-P244","1bfi6jy":"C23-Q003-P244","1716hoa":"C23-Q004-P244","1qoq2hg":"C23-Q005-P244","xb5c0l":"C23-Q006-P245","4unmit":"C23-Q007-P245","pvjx2u":"C23-Q008-P245","21hc9i":"C23-Q009-P245","1fr3heu":"C23-Q010-P245","trdg5r":"C23-Q011-P245","rqrgsv":"C23-Q012-P245","vc7mti":"C23-Q013-P245","o79vl6":"C23-Q014-P245","1chcmfj":"C23-Q015-P246","47kmv3":"C23-Q016-P246","1w2f308":"C23-Q017-P246","3ugaj3":"C23-Q018-P246","1t949kg":"C23-Q019-P246","jogq2z":"C23-Q020-P246","1erg4ve":"C23-Q021-P246","12a744j":"C23-Q022-P247","tc2rei":"C23-Q023-P247","rmm36z":"C23-Q024-P247","1f2ortf":"C23-Q025-P247","tdjh4m":"C23-Q026-P247","1cosrhn":"C23-Q027-P248","xpz176":"C23-Q028-P248","1x3n30q":"C23-Q029-P248","16fxsdx":"C23-Q030-P248","t289zn":"C23-Q031-P248","1w82cb":"C23-Q032-P248","xvibpz":"C23-Q033-P249","ls9bqg":"C23-Q034-P249","1hba679":"C23-Q035-P249","1ma0yfs":"C23-Q036-P249","1geh48o":"C23-Q037-P249","118gbww":"C23-Q038-P250","wbqsuu":"C23-Q039-P250","1949v6f":"C23-Q040-P250","1lguder":"C23-Q041-P250","wnbxsk":"C23-Q042-P250","3512c":"C23-Q043-P251","1tg9lu5":"C23-Q044-P251","1p4k5tx":"C23-Q045-P251","1j2eny7":"C23-Q046-P251","1kc2tvs":"C23-Q047-P251","1n77vr4":"C23-Q048-P251","1xposvx":"C23-Q049-P251","1chzmur":"C23-Q050-P252","1axswnn":"C23-Q051-P252","fx1ww9":"C23-Q052-P252","zimrr0":"C23-Q053-P252","fd5tim":"C23-Q054-P252","7l3poa":"C23-Q055-P252","1nrzucf":"C23-Q056-P253","1burr5g":"C23-Q057-P253","1n8diok":"C23-Q058-P253","15yz812":"C23-Q059-P253","j2gqca":"C23-Q060-P253","e0bu67":"C23-Q061-P253","182a69g":"C23-Q062-P254","19c5wop":"C23-Q063-P254","11hlppj":"C23-Q064-P254","qk60ss":"C23-Q065-P254","7rutld":"C23-Q066-P254","1qcr4q1":"C23-Q067-P255","1dzae3n":"C23-Q068-P255","4nd2cx":"C23-Q069-P255","irdmzg":"C23-Q070-P255","yrhdvg":"C23-Q071-P255","b09hsy":"C23-Q072-P255","6sc9rp":"C23-Q073-P256","15s8mnc":"C23-Q074-P256","jcwmdc":"C23-Q075-P256","1uilqfg":"C23-Q076-P256","1mst8eu":"C23-Q077-P256","zuh0gd":"C23-Q078-P257","hebjez":"C23-Q079-P257","gswfgc":"C23-Q080-P257","abzh7y":"C23-Q081-P257","e05mw0":"C23-Q082-P257","1uxknfy":"C23-Q083-P257","1tuffhs":"C23-Q084-P258","jrygec":"C23-Q085-P258","1t6cfmb":"C23-Q086-P258","nkvphu":"C23-Q087-P258","1t5hcch":"C23-Q088-P258","1kd8nhi":"C23-Q089-P259","6r5byv":"C23-Q090-P259","1fgqiok":"C23-Q091-P259","76571p":"C23-Q092-P259","1hyl8xv":"C23-Q093-P259","1971j0p":"C23-Q094-P259","cwj9q":"C23-Q095-P260","1o0w5lk":"C23-Q096-P260","1txa4lp":"C23-Q097-P260","1ofsci3":"C23-Q098-P260","nyclem":"C23-Q099-P260","hq5qau":"C23-Q100-P260","1rj0fc4":"C23-Q101-P261","esy4by":"C23-Q102-P261","1upryah":"C23-Q103-P261","jpvvqq":"C23-Q104-P261","1i7jnky":"C23-Q105-P261","xveuia":"C23-Q106-P261","bfkraj":"C23-Q107-P261","44kcil":"C23-Q108-P262","mbrv6d":"C23-Q109-P262","jefpv5":"C23-Q110-P262","dis1q1":"C23-Q111-P262","hlndrm":"C23-Q112-P262","1jid2bb":"C23-Q113-P262","1jeo7c8":"C23-Q114-P263","vd8twp":"C23-Q115-P263","or7ehb":"C23-Q116-P263","g5hzjd":"C23-Q117-P263","17zkzgl":"C23-Q118-P263","1jwp5v0":"C23-Q119-P264","jzf91d":"C23-Q120-P264","10x0zho":"C23-Q121-P264","1rcvdip":"C23-Q122-P264","4krmg7":"C23-Q123-P264","1kv2vra":"C23-Q124-P264","df2ilm":"C23-Q125-P265","21yvyf":"C23-Q126-P265","10fx10c":"C23-Q127-P265","13re9vv":"C23-Q128-P265","1yur7w1":"C23-Q129-P265","hfaxq":"C23-Q130-P266","5jzm2d":"C23-Q131-P266","b8zlhw":"C23-Q132-P266","l99jay":"C23-Q133-P266","1upxzh9":"C23-Q134-P266","z94zkn":"C23-Q135-P267","1161nqu":"C23-Q136-P267","oznu8e":"C23-Q137-P267","m03p87":"C23-Q138-P267","1c8d9fr":"C23-Q139-P268","mv1ux4":"C23-Q140-P268","ujphze":"C23-Q141-P268","1kbcg9v":"C23-Q142-P268","a53c97":"C24-Q001-P269","1h00b03":"C24-Q002-P269","o8jdcg":"C24-Q003-P269","1q2takz":"C24-Q004-P270","r30fa0":"C24-Q005-P270","1irsqqm":"C24-Q006-P270","1o3312f":"C24-Q007-P270","jre2tb":"C24-Q008-P271","ikqdk4":"C24-Q009-P271","1gtvkme":"C24-Q010-P271","8m6mu4":"C24-Q011-P271","vre4tb":"C24-Q012-P271","1r8z1fd":"C24-Q013-P272","qgs2xo":"C24-Q014-P272","17cxjgh":"C24-Q015-P272","1351zn":"C24-Q016-P272","po9yl8":"C24-Q017-P272","ysnva1":"C24-Q018-P272","1iuynhl":"C24-Q019-P272","10clhem":"C24-Q020-P273","chfmdi":"C24-Q021-P273","1pyx1ro":"C24-Q022-P273","jppwd9":"C24-Q023-P273","oujyel":"C24-Q024-P273","1lw6pzb":"C24-Q025-P273","xl4l48":"C24-Q026-P274","1u4bdrs":"C24-Q027-P274","16xzf25":"C24-Q028-P274","117ttz2":"C24-Q029-P274","3xz628":"C24-Q030-P275","1exd6h5":"C24-Q031-P275","ejdged":"C24-Q032-P275","wmsjvt":"C24-Q033-P275","1bzir66":"C24-Q034-P275","411z66":"C24-Q035-P276","1i5l9uc":"C24-Q036-P276","1wh6ovl":"C24-Q037-P276","1puvmsu":"C24-Q038-P276","uxz5n6":"C25-Q001-P277","17c263b":"C25-Q002-P277","1m8e0dn":"C25-Q003-P277","1n82asv":"C25-Q004-P277","xd3psz":"C25-Q005-P278","l7a4vk":"C25-Q006-P278","zg8uck":"C25-Q007-P278","56czr8":"C25-Q008-P278","1cby60e":"C25-Q009-P278","r5t8d1":"C25-Q010-P278","yn3u53":"C25-Q011-P279","aicnyp":"C25-Q012-P279","hw8oek":"C25-Q013-P279","lqh7ad":"C25-Q014-P279","chwdfn":"C25-Q015-P279","hqfdqg":"C25-Q016-P279","1azlhil":"C25-Q017-P280","q5tg8v":"C25-Q018-P280","i4ka7a":"C25-Q019-P280","1es3ph4":"C25-Q020-P280","1gwpi8q":"C25-Q021-P280","1w6v20q":"C25-Q022-P280","1e9mtif":"C25-Q023-P281","1v8mdk":"C25-Q024-P281","gckufd":"C25-Q025-P281","fwo9x8":"C25-Q026-P281","1j3nxe4":"C25-Q027-P281","1cb24le":"C25-Q028-P282","1t7wywz":"C25-Q029-P282","11scdwy":"C25-Q030-P282","1ds0q9n":"C25-Q031-P282","13zx375":"C25-Q032-P282","1lx8hxj":"C25-Q033-P282","szyhfd":"C25-Q034-P282","18kgvq0":"C25-Q035-P283","1k1f9b3":"C25-Q036-P283","1o2llu6":"C25-Q037-P283","1ado5t4":"C25-Q038-P283","16nzaws":"C25-Q039-P283","8u0150":"C25-Q040-P283","4my158":"C25-Q041-P284","1a76pqy":"C25-Q042-P284","10kb3in":"C25-Q043-P284","1q634tc":"C25-Q044-P284","xgt5y3":"C25-Q045-P284","14jrigj":"C25-Q046-P285","1zlma9":"C25-Q047-P285","oao4nx":"C25-Q048-P285","fbvvv4":"C25-Q049-P285","dr7jaz":"C25-Q050-P285","v2xh2f":"C25-Q051-P285","1afufrw":"C25-Q052-P285","mxgifa":"C25-Q053-P286","1hk79so":"C25-Q054-P286","1txzcon":"C25-Q055-P286","1loetmk":"C25-Q056-P286","15yiu6p":"C25-Q057-P287","166u0nh":"C25-Q058-P287","v3hojp":"C25-Q059-P287","1fgucnv":"C25-Q060-P287","1bt2zqk":"C25-Q061-P287","894fje":"C25-Q062-P287","1l55br5":"C25-Q063-P288","13686zr":"C25-Q064-P288","1j25akv":"C25-Q065-P288","6eq265":"C25-Q066-P288","1nttef9":"C25-Q067-P288","19trr6b":"C25-Q068-P289","j1ozty":"C25-Q069-P289","d2uvgo":"C25-Q070-P289","octrsz":"C25-Q071-P289","pfgfbe":"C25-Q072-P289","l8yo51":"C25-Q073-P290","ro2dqu":"C25-Q074-P290","dh5gef":"C25-Q075-P290","3utd0h":"C25-Q076-P290","6y13gu":"C25-Q077-P291","1ald5hw":"C25-Q078-P291","yris99":"C25-Q079-P291","16id9mg":"C25-Q080-P291","m9lt0p":"C25-Q081-P291","1ocpunl":"C25-Q082-P291","1gqyp29":"C25-Q083-P292","5smhuh":"C25-Q084-P292","a4g6fp":"C25-Q085-P292","zp3e0l":"C25-Q086-P293","88icfz":"C25-Q087-P293","1q6s5bq":"C25-Q088-P293","1x9pl89":"C25-Q089-P293","1aany98":"C25-Q090-P294","ww06du":"C25-Q091-P294","1rubcll":"C25-Q092-P294","49rkv5":"C25-Q093-P294","18iimie":"C26-Q001-P296","1vrpxhn":"C26-Q002-P296","1tno4t4":"C26-Q003-P296","at9e3u":"C26-Q004-P296","9r6k9z":"C26-Q005-P296","1ev8por":"C26-Q006-P297","1ndakgx":"C26-Q007-P297","19pshun":"C26-Q008-P297","1bymt7b":"C26-Q009-P297","1lfxa2f":"C26-Q010-P297","q2tvh2":"C26-Q011-P298","1dyik6k":"C26-Q012-P298","bc96y3":"C26-Q013-P298","1rh38sn":"C26-Q014-P298","161rrac":"C26-Q015-P298","gk3qt5":"C26-Q016-P298","ylq127":"C26-Q017-P299","1lcf8cb":"C26-Q018-P299","jd4qcf":"C26-Q019-P299","1e6rrrm":"C26-Q020-P299","ai2plm":"C26-Q021-P300","1qeb12o":"C26-Q022-P300","sju1g6":"C26-Q023-P300","7hpwk9":"C26-Q024-P300","1fwe1tb":"C26-Q025-P300","27njg4":"C26-Q026-P300","bh3eex":"C26-Q027-P301","1yjp2w3":"C26-Q028-P301","qgd0mp":"C26-Q029-P301","sksx05":"C26-Q030-P302","9cgdcz":"C26-Q031-P302","81gk71":"C26-Q032-P302","1d5v3nu":"C26-Q033-P302","1q1ipfk":"C26-Q034-P302","upofc1":"C26-Q035-P302","aqbhw7":"C26-Q036-P303","4ox1gr":"C26-Q037-P303","vhx0q9":"C26-Q038-P303","142xfj2":"C26-Q039-P303","1hz0hd9":"C26-Q040-P303","1l9tiro":"C26-Q041-P303","11knc9m":"C26-Q042-P304","1u45u48":"C26-Q043-P304","u0u4hs":"C26-Q045-P304","9dvspb":"C26-Q046-P304","ryubal":"C26-Q047-P305","ddv2tt":"C26-Q048-P305","cdy5js":"C26-Q049-P305","10rm5hl":"C26-Q050-P305","1ge5sel":"C26-Q051-P305","1le9lqz":"C26-Q052-P305","4yjlno":"C26-Q053-P306","1i2hhab":"C26-Q054-P306","10eyjo1":"C26-Q055-P306","13mnac7":"C26-Q056-P306","1jup16f":"C26-Q057-P306","1i8kp28":"C26-Q058-P307","gatkim":"C26-Q059-P307","1agna2":"C26-Q060-P307","1xom4yd":"C26-Q061-P307","1p6bn0c":"C26-Q062-P307","cu2axk":"C26-Q063-P308","cegyzg":"C26-Q064-P308","uw683r":"C26-Q065-P308","wqsfrq":"C26-Q066-P308","147f3bd":"C26-Q067-P308","1i4zwl0":"C26-Q068-P308","1hdn135":"C26-Q069-P309","1jzjgn6":"C26-Q070-P309","rdsbd6":"C26-Q071-P309","1dbehjd":"C26-Q072-P309","124obdw":"C26-Q073-P309","rs08m6":"C26-Q074-P310","mqv1a":"C26-Q075-P310","x2sdr9":"C26-Q076-P310","1led50n":"C26-Q077-P310","1c8qys5":"C26-Q078-P310","bwimoo":"C26-Q079-P310","nar2hy":"C26-Q080-P310","584xnf":"C26-Q081-P310","r4giiu":"C26-Q082-P311","6jy4fe":"C26-Q083-P311","jp5atw":"C26-Q084-P311","1g8v8gz":"C26-Q085-P311","1veclsw":"C26-Q086-P311","w34cvf":"C26-Q087-P312","a5f1v7":"C26-Q088-P312","bcxmgb":"C26-Q089-P312","17w4f84":"C26-Q090-P312","p6k3qh":"C26-Q091-P312","js6ron":"C26-Q092-P313","1skj3l9":"C26-Q093-P313","pgbu35":"C26-Q094-P313","40btmj":"C26-Q095-P313","1aycua8":"C26-Q096-P314","1suw934":"C26-Q097-P314","83lsyr":"C26-Q098-P314","1dx610v":"C26-Q099-P314","1whmocf":"C26-Q100-P314","1sdgpoz":"C26-Q101-P314","v5j6z3":"C26-Q102-P315","1y8gxbv":"C26-Q103-P315","156djlu":"C26-Q104-P315","1e7l3fv":"C26-Q105-P315","1hyny78":"C26-Q106-P316","bzke6":"C26-Q107-P316","bqq7yz":"C26-Q108-P316","10n13e5":"C26-Q109-P316","1w23q8m":"C26-Q110-P316","1kxjk9g":"C26-Q111-P316","1csfna9":"C26-Q112-P317","1cqaqiy":"C26-Q113-P317","8bmiyw":"C26-Q114-P317","189a1ke":"C26-Q115-P317","t3uwlo":"C26-Q116-P317","p9idn7":"C26-Q117-P318","8xqwa4":"C26-Q118-P318","1lpos8i":"C26-Q119-P318","91034i":"C26-Q120-P318","vxwrak":"C26-Q121-P318","19pm8jx":"C26-Q122-P319","1ntvkho":"C26-Q123-P319","x7fpiw":"C26-Q124-P319","gtz54s":"C26-Q125-P319","pt4360":"C26-Q126-P319","1dnc5ey":"C26-Q127-P319","76pv03":"C27-Q001-P320","f8rwpd":"C27-Q002-P321","1v0hv7v":"C27-Q003-P321","ene13y":"C27-Q004-P321","d0ev1c":"C27-Q005-P321","1v3jpm0":"C27-Q006-P321","rjc3od":"C27-Q007-P321","cjxo35":"C27-Q008-P321","1jas6z4":"C27-Q009-P322","11p9esd":"C27-Q010-P322","rru95a":"C27-Q011-P322","14ja6c6":"C27-Q012-P322","1s7mn6u":"C27-Q013-P323","lfu4tp":"C27-Q014-P323","1gn5h7b":"C27-Q015-P323","abxsar":"C27-Q016-P323","1w1u3r3":"C27-Q017-P323","9ivbt1":"C27-Q018-P323","1gu66sj":"C27-Q019-P324","dbbxan":"C27-Q020-P324","1cpvw6m":"C27-Q021-P324","pj0fp3":"C27-Q022-P324","13h182x":"C27-Q023-P324","1oi941d":"C27-Q024-P325","1w3zucj":"C27-Q025-P325","17tkut5":"C27-Q026-P325","1e54goz":"C27-Q027-P325","qtr17w":"C27-Q028-P326","1kfeyla":"C27-Q029-P326","46s60m":"C27-Q030-P326","jzh3kn":"C27-Q031-P326","14s4k3r":"C27-Q032-P326","xhvuji":"C27-Q033-P326","n7tznz":"C27-Q034-P327","sfbjan":"C27-Q035-P327","1t18sbg":"C27-Q036-P327","m3ilcf":"C27-Q037-P327","j6rho0":"C27-Q038-P327","1q3hfe6":"C27-Q039-P327","8d4kpp":"C27-Q040-P328","8uc6ph":"C27-Q041-P328","u9lrj5":"C27-Q042-P328","15uyiku":"C27-Q043-P328","tt4dey":"C27-Q044-P329","1y7i51h":"C27-Q045-P329","folwn6":"C27-Q046-P329","ocsw3y":"C27-Q047-P329","1td7h91":"C27-Q048-P329","jjriu2":"C27-Q049-P330","n503lw":"C27-Q050-P330","130ag1d":"C27-Q051-P330","2ma1oz":"C27-Q052-P330","qjxhas":"C27-Q053-P330","9ji0s8":"C27-Q054-P330","fqbfau":"C27-Q055-P331","ar8hv5":"C27-Q056-P331","1scg4fr":"C28-Q001-P332","6dkhog":"C28-Q002-P332","1vdqxt3":"C28-Q003-P332","hdz774":"C28-Q004-P333","1t38lj9":"C28-Q005-P333","wkpsi3":"C28-Q006-P333","vct1eh":"C28-Q007-P333","pmxad9":"C28-Q008-P333","1v197kj":"C28-Q009-P333","8mgfli":"C28-Q010-P333","12s971r":"C28-Q011-P334","2w8fz0":"C28-Q012-P334","upw5eo":"C28-Q013-P334","1m48m2j":"C28-Q014-P334","bia4vf":"C28-Q015-P334","2d6agj":"C28-Q016-P335","ydvjgj":"C28-Q017-P335","1f3afp6":"C28-Q018-P335","15w1rgh":"C28-Q019-P335","1pryd13":"C28-Q020-P335","1uqbv1y":"C28-Q021-P335","wdsmb8":"C28-Q022-P335","n9p0dl":"C28-Q023-P336","13x6n3y":"C28-Q024-P336","qd43us":"C28-Q025-P336","1k9abkz":"C28-Q026-P336","sada7o":"C28-Q027-P336","vu5l6j":"C28-Q028-P336","1ogqbeh":"C28-Q029-P337","uch5m2":"C28-Q030-P337","1tzahh4":"C28-Q031-P337","jpcv18":"C28-Q032-P337","v3sut1":"C28-Q033-P337","4ya2b9":"C28-Q034-P337","239if7":"C28-Q035-P337","1qvchk3":"C28-Q036-P338","fq0v2t":"C28-Q037-P338","e0ptrj":"C28-Q038-P338","1yjvg04":"C28-Q039-P338","tewcfy":"C28-Q040-P338","tc1fxv":"C28-Q041-P338","6pf04c":"C28-Q042-P339","ekpo0":"C28-Q043-P339","rlgoc9":"C28-Q044-P339","9ivgl8":"C28-Q045-P339","15eslw7":"C28-Q046-P339","1vwbi9":"C28-Q047-P339","zo7kei":"C28-Q048-P340","15egxpr":"C28-Q049-P340","v5d9lg":"C28-Q050-P340","1caads1":"C28-Q051-P340","f5rjvg":"C28-Q052-P341","1i8z6lv":"C28-Q053-P341","7wefy7":"C28-Q054-P341","ecds6h":"C28-Q055-P341","1i3is8p":"C28-Q056-P341","ndz39r":"C28-Q057-P341","hrfrje":"C28-Q058-P342","13gdiy7":"C28-Q059-P342","12weoya":"C28-Q060-P342","8d5q2m":"C28-Q061-P342","kkdplv":"C28-Q062-P342","htqhy9":"C28-Q063-P342","qz7w0a":"C28-Q064-P343","3lbrlh":"C28-Q065-P343","15ig6v7":"C28-Q066-P343","1ibcjou":"C28-Q067-P343","4gdu10":"C28-Q068-P343","pfdrlu":"C28-Q069-P343","wv6lnt":"C28-Q070-P343","dlzrny":"C28-Q071-P344","rkww3k":"C28-Q072-P344","14dmmpf":"C28-Q073-P344","18t7odq":"C28-Q074-P344","1r0vysm":"C28-Q075-P345","im7lva":"C28-Q076-P345","18bdaiz":"C28-Q077-P345","508b2t":"C28-Q078-P345","h4c8xy":"C28-Q079-P345","11o5b6s":"C28-Q080-P345","fbd9x2":"C28-Q081-P346","127tpnv":"C28-Q082-P346","1tp2qj2":"C28-Q083-P346","804qjn":"C28-Q084-P346","1ekpueb":"C28-Q085-P346","8buil5":"C28-Q086-P346","1wkkyh5":"C29-Q001-P348","10nrnt6":"C29-Q002-P348","10bigga":"C29-Q003-P348","rhh60r":"C29-Q004-P348","tczz45":"C29-Q005-P348","1j7fjtt":"C29-Q006-P349","1ygbom1":"C29-Q007-P349","1t8q8dw":"C29-Q008-P349","v1areo":"C29-Q009-P349","qgkzz9":"C29-Q010-P349","1vggdao":"C29-Q011-P349","9g44dg":"C29-Q012-P349","124cycr":"C29-Q013-P350","wj10qr":"C29-Q014-P350","11is82g":"C29-Q015-P350","9xma30":"C29-Q016-P350","7qyz89":"C29-Q017-P350","10rlwa0":"C29-Q018-P350","qn56fd":"C29-Q019-P350","z7erxi":"C29-Q020-P351","1t7vpst":"C29-Q021-P351","18e6u3x":"C29-Q022-P351","1rmogrw":"C29-Q023-P351","1he79b5":"C29-Q024-P351","kwxu9f":"C29-Q025-P352","1ffe596":"C29-Q026-P352","juvfky":"C29-Q027-P352","ovee4b":"C29-Q028-P352","1pmnv9e":"C29-Q029-P353","xr3oag":"C29-Q030-P353","1t89hty":"C29-Q031-P353","186d0nz":"C29-Q032-P353","1uxryhx":"C29-Q033-P353","1usyh8e":"C29-Q034-P353","ypywcq":"C29-Q035-P353","f7up5r":"C29-Q036-P353","jnnjjw":"C29-Q037-P354","16zwiar":"C29-Q038-P354","d7nynt":"C29-Q039-P354","12oidc8":"C29-Q040-P355","rljt3g":"C29-Q041-P355","1t4s9ih":"C29-Q042-P355","s1mu5u":"C29-Q043-P355","1yl86ej":"C30-Q001-P357","1bbvuvo":"C30-Q002-P357","pwc1hg":"C30-Q003-P357","1d5cu8b":"C30-Q004-P357","199hcim":"C30-Q005-P357","13prwyx":"C30-Q006-P358","1lq5xuk":"C30-Q007-P358","id1akl":"C30-Q008-P358","z9707l":"C30-Q009-P358","22p0ui":"C30-Q010-P358","1iqdu53":"C30-Q011-P358","hcggvt":"C30-Q012-P359","2qy6hk":"C30-Q013-P359","9kivbe":"C30-Q014-P359","1pe2zsr":"C30-Q015-P359","1u64bcy":"C30-Q016-P359","ow6zq4":"C30-Q017-P359","oqx8aw":"C30-Q018-P359","s2dfyw":"C30-Q019-P360","cqtj0j":"C30-Q020-P360","176407r":"C30-Q021-P360","1b140k1":"C30-Q022-P360","140aqq1":"C30-Q023-P360","w9ddsc":"C30-Q024-P360","1tuux11":"C30-Q025-P360","1a7v3nt":"C30-Q026-P361","1j39qa1":"C30-Q027-P361","1ouypoi":"C30-Q028-P361","h3mdg":"C30-Q029-P362","1kzu5lm":"C30-Q030-P362","1mce059":"C30-Q031-P362","1gznode":"C30-Q032-P362","ngnoek":"C30-Q033-P362","s1jbnh":"C30-Q034-P362","eecrg":"C30-Q035-P362","1qhdiog":"C30-Q036-P362","13dtci4":"C30-Q037-P363","d5egz":"C30-Q038-P363","2qj0vh":"C30-Q039-P363","121haj":"C30-Q040-P363","1e1nvb":"C30-Q041-P364","1rav77v":"C30-Q042-P364","1xvbf5t":"C30-Q043-P364","q5n62o":"C30-Q044-P364","1jlwowe":"C30-Q045-P365","1fmfjyn":"C30-Q046-P365","1nngygx":"C30-Q047-P365","dd9ogy":"C30-Q048-P365","jsgayf":"C30-Q049-P365","5sjeg":"C30-Q050-P365","4fmuo2":"C30-Q051-P366","oq754s":"C30-Q052-P366","1e0x4ql":"C30-Q053-P366","26i80g":"C30-Q054-P366","1qxa8uv":"C30-Q055-P366","1hhawuy":"C30-Q056-P366","lk0qp8":"C30-Q057-P367","1p65gbc":"C30-Q058-P367","1o2yj0l":"C31-Q001-P368","1r2713l":"C31-Q002-P368","1nh0lx":"C31-Q003-P369","ewt5nf":"C31-Q004-P369","jcclbf":"C31-Q005-P369","15uz698":"C31-Q006-P369","1v3h8c7":"C31-Q007-P369","vghj5q":"C31-Q008-P369","1ubi55v":"C31-Q009-P370","6bwoi8":"C31-Q010-P370","kj0zke":"C31-Q011-P370","163qhrq":"C31-Q012-P370","15zvkwb":"C31-Q013-P370","1ich8pw":"C31-Q014-P371","1ukv50v":"C31-Q015-P371","1fop22l":"C31-Q016-P371","1slrdp8":"C31-Q017-P371","48fxu0":"C31-Q018-P371","bibu14":"C31-Q019-P371","zv6kly":"C31-Q020-P372","tbljyw":"C31-Q021-P372","bazmoh":"C31-Q022-P372","maww5":"C31-Q023-P372","98vspa":"C31-Q024-P372","686ko7":"C31-Q025-P373","143qude":"C31-Q026-P373","10l6jd6":"C31-Q027-P373","1hjbu2u":"C31-Q028-P373","iimpl7":"C31-Q029-P373","z6wtec":"C31-Q030-P373","1h80fy0":"C31-Q031-P374","14rp5v3":"C31-Q032-P374","1tqtgo8":"C31-Q033-P374","8pgy6f":"C31-Q034-P374","a7gjyq":"C31-Q035-P374","z1w7hk":"C31-Q036-P375","83urzr":"C31-Q037-P375","tynosi":"C31-Q038-P375","eokezx":"C31-Q039-P375","dxch49":"C32-Q001-P376","nbztzc":"C32-Q002-P376","nzbbte":"C32-Q003-P376","1293iyo":"C32-Q004-P376","p0w0xj":"C32-Q005-P376","w8l72t":"C32-Q006-P376","q2vb9n":"C32-Q007-P376","1cxx58e":"C32-Q008-P377","17wl2c3":"C32-Q009-P377","194n4vw":"C32-Q010-P377","16dy6x":"C32-Q011-P377","6xfirg":"C32-Q012-P377","niepg0":"C32-Q013-P377","12ewr":"C32-Q014-P377","11jog66":"C32-Q015-P378","skhu3u":"C32-Q016-P378","2h4id5":"C32-Q017-P378","1u00kd3":"C32-Q018-P378","3c9g4b":"C32-Q019-P379","nj9qwy":"C32-Q020-P379","ovkfl3":"C32-Q021-P379","isbmm6":"C32-Q022-P379","1i4c0sp":"C32-Q023-P379","jkgwp6":"C32-Q024-P379","i5hman":"C32-Q025-P379","1vjc3vr":"C32-Q026-P380","1dn06na":"C32-Q027-P380","19yjps3":"C32-Q028-P380","xz5c9a":"C32-Q029-P380","1h1nemj":"C32-Q030-P380","tunp9a":"C33-Q001-P381","11pi4f0":"C33-Q002-P381","1af1q40":"C33-Q003-P381","5c30pw":"C33-Q004-P381","gwp96c":"C33-Q005-P381","aauwuu":"C33-Q006-P381","vexjb1":"C33-Q007-P382","18myatj":"C33-Q008-P382","1kenual":"C33-Q009-P382","1ato6ur":"C33-Q010-P382","1r32pn3":"C33-Q011-P382","8fk6o1":"C33-Q012-P382","1wyjwya":"C33-Q013-P382","6vuzmq":"C33-Q014-P383","1exm9a":"C33-Q015-P383","rawqo7":"C33-Q016-P383","fu8j6s":"C33-Q017-P383","1xvvsn9":"C33-Q018-P383","1bh2mw3":"C33-Q019-P383","1g2hwy4":"C33-Q020-P383","dn1scx":"C33-Q021-P383","15r0mmb":"C33-Q022-P384","yxpn1u":"C33-Q023-P384","1podotv":"C33-Q024-P384","1g39p4c":"C33-Q025-P384","1baiil0":"C33-Q026-P384","wgohld":"C33-Q027-P384","1oeylcl":"C33-Q028-P385","1dr365u":"C33-Q029-P385","1o9cfwr":"C33-Q030-P385","e62bof":"C33-Q031-P385","1uk96g4":"C33-Q032-P385","1sz156v":"C33-Q033-P386","s9btuz":"C33-Q034-P386","4zned8":"C33-Q035-P386","mgtaz3":"C34-Q001-P387","icxzll":"C34-Q002-P387","j48aq4":"C34-Q003-P387","os83rn":"C34-Q004-P388","geh4ze":"C34-Q005-P388","8lep8h":"C34-Q006-P388","1a4yii4":"C34-Q007-P388","4htfng":"C34-Q008-P388","1ygq5pc":"C34-Q009-P389","1idiils":"C34-Q010-P389","1e9foev":"C34-Q011-P389","10ngdyq":"C34-Q012-P389","mw0czl":"C34-Q013-P389","1doba0v":"C34-Q014-P389","ayudwr":"C34-Q015-P389","7zglrm":"C34-Q016-P390","1rqn9ue":"C34-Q017-P390","1rishzb":"C34-Q018-P390","nrzx6l":"C34-Q019-P390","1vp7vxt":"C34-Q020-P390","1trntsj":"C34-Q021-P390","1gyqemo":"C34-Q022-P390","12kc2ax":"C34-Q023-P391","3ucfb0":"C34-Q024-P391","1j6mybt":"C34-Q025-P391","hffypn":"C34-Q026-P391","2ndkss":"C34-Q027-P392","1b0yjoo":"C34-Q028-P392","hkagcq":"C34-Q029-P392","1xu1wpo":"C34-Q030-P392","1siy057":"C34-Q031-P392","1nstdkx":"C34-Q032-P392","80iavc":"C34-Q033-P393","1suf95v":"C34-Q034-P393","1ng2hss":"C34-Q035-P393","1myljjj":"C34-Q036-P393","12qu21g":"C34-Q037-P393","8vf3on":"C34-Q038-P393","19ff0j":"C34-Q039-P394","bb2sm6":"C34-Q040-P394","1yzyeo0":"C34-Q041-P394","9pp30p":"C34-Q042-P394","a90ej4":"C34-Q043-P394","z24omo":"C34-Q044-P395","1vyfq9z":"C34-Q045-P395","xudb5e":"C34-Q046-P395","pj8u56":"C34-Q047-P395","1qtftju":"C34-Q048-P395","4sgpkl":"C34-Q049-P395","1smramv":"C34-Q050-P396","wm8ov8":"C34-Q051-P396","1b2by6t":"C34-Q052-P396","a2rau3":"C34-Q053-P396","19a8ygq":"C34-Q054-P396","4znwid":"C34-Q055-P396","h3xnmw":"C34-Q056-P397","i27np3":"C34-Q057-P397","1hbo5fo":"C34-Q058-P397","1v1kjna":"C34-Q059-P397","2jwj92":"C34-Q060-P397","1sm9b2":"C34-Q061-P398","hu1gnz":"C34-Q062-P398","ktro8a":"C34-Q063-P398","1cwfpfb":"C34-Q064-P398","1gj5vxl":"C34-Q065-P398","10lp0lb":"C34-Q066-P398","1gssuho":"C34-Q067-P399","3n9ubd":"C34-Q068-P399","gg5d11":"C34-Q069-P399","4rxei7":"C34-Q070-P399","nwgfek":"C34-Q071-P399","9s6bt5":"C34-Q072-P399","qj8i10":"C34-Q073-P400","1e6m3jl":"C34-Q074-P400","1uk36di":"C34-Q075-P400","1yjm3pg":"C34-Q076-P400","1qeaubk":"C34-Q077-P400","x34kmb":"C34-Q078-P400","7mxuul":"C34-Q079-P401","i4a1uw":"C34-Q080-P401","nd7gjv":"C34-Q081-P401","1nshicz":"C34-Q082-P401","150das9":"C34-Q083-P401","16etbxe":"C34-Q084-P401","us08a3":"C34-Q085-P402","lvlm4":"C34-Q086-P402","4oznjj":"C34-Q087-P402","63u8tj":"C34-Q088-P402","1wah1va":"C34-Q089-P402","1a88klq":"C34-Q090-P402","99pwz4":"C34-Q091-P403","daud6s":"C34-Q092-P403","13mjd1j":"C34-Q093-P403","shth32":"C34-Q094-P403","1bipcpk":"C34-Q095-P403","1533s60":"C34-Q096-P404","ti2lgp":"C34-Q097-P404","i0ixdm":"C34-Q098-P404","1hk9dww":"C34-Q099-P404","1wz8zgr":"C34-Q100-P404","2g43w3":"C34-Q101-P404","11xiuv9":"C34-Q102-P404","xqcvra":"C34-Q103-P405","cyo71b":"C34-Q104-P405","msimz5":"C34-Q105-P405","5k3z3u":"C34-Q106-P405","7z4563":"C34-Q107-P405","1kvim1d":"C34-Q108-P406","dqxv3e":"C34-Q109-P406","u4hqjt":"C34-Q110-P406","qnvuex":"C34-Q111-P406","15hgg6c":"C34-Q112-P406","1mn6e5k":"C34-Q113-P406","48r7kt":"C34-Q114-P406","3djd2":"C34-Q115-P407","fuyoyk":"C34-Q116-P407","1kk9j9":"C34-Q117-P407","1tqfehv":"C34-Q118-P407","18k0apl":"C34-Q119-P407","haalzw":"C34-Q120-P407","k7wpf6":"C34-Q121-P407","1qscjsn":"C34-Q122-P408","1cfcidt":"C34-Q123-P408","1ybednu":"C35-Q001-P408","mispk9":"C35-Q002-P408","pvxwqd":"C35-Q003-P408","1lgizi9":"C35-Q004-P408","1b7bpdl":"C35-Q005-P409","up3syg":"C35-Q006-P409","149aswl":"C35-Q007-P409","2xmdsq":"C35-Q008-P409","3zdi58":"C35-Q009-P409","1vpbedx":"C35-Q010-P409","1cx104b":"C35-Q011-P410","ro2o39":"C35-Q012-P410","4koy64":"C35-Q014-P410","pv4rb3":"C36-Q001-P412","474ifo":"C36-Q002-P412","6utmze":"C36-Q003-P412","130ooe5":"C36-Q004-P412","q9p2di":"C36-Q005-P413","5yp14z":"C36-Q006-P413","asrws1":"C36-Q007-P413","vtgcje":"C36-Q008-P414","685qt0":"C36-Q009-P414","80lehc":"C36-Q010-P414","10hlgff":"C36-Q011-P414","skbfdl":"C36-Q012-P414","103nhzd":"C36-Q013-P415","1j7ab9b":"C36-Q014-P415","1px1i14":"C36-Q015-P415","if3hyt":"C36-Q016-P415","1qa76rc":"C36-Q017-P415","f40tud":"C36-Q018-P416","1y1qc3u":"C36-Q019-P416","12m8eks":"C36-Q020-P416","18g453x":"C36-Q021-P416","mziape":"C36-Q022-P416","c87xb1":"C36-Q023-P417","11j7ayj":"C36-Q024-P417","5pacfw":"C36-Q025-P417","vo84wg":"C36-Q026-P417","18b0r6n":"C36-Q027-P417","1clmnxb":"C36-Q028-P417","yrde9d":"C36-Q029-P418","1lu4rcy":"C36-Q030-P418","puxchv":"C36-Q031-P418","13e6hbc":"C36-Q032-P418","14r3gxv":"C36-Q033-P418","1fbbdmv":"C36-Q034-P418","1omr4ga":"C36-Q035-P419","q3pwdd":"C36-Q036-P419","rroda0":"C36-Q037-P419","1ae17e":"C36-Q038-P419","1gftcpc":"C36-Q039-P419","c3htmj":"C36-Q040-P419","11ckdft":"C36-Q041-P419","1dj2g4t":"C36-Q042-P420","97kh9u":"C36-Q043-P420","1m47l44":"C36-Q044-P420","4mlvej":"C36-Q045-P420","3zp9jx":"C36-Q046-P421","1cwf146":"C36-Q047-P421","1gsmou6":"C36-Q048-P421","1i6csak":"C36-Q049-P421","gc3pxb":"C36-Q050-P421","aqocnx":"C36-Q051-P422","1knqgdw":"C36-Q052-P422","ws7l1h":"C36-Q053-P422","5scuxa":"C36-Q054-P422","1h2jgm7":"C36-Q055-P423","g54wk1":"C36-Q056-P423","1suei5x":"C36-Q057-P423","1jgfjm9":"C36-Q058-P423","4cs4nf":"C36-Q059-P423","12xtljr":"C36-Q060-P424","1fm5pbg":"C36-Q061-P424","16kp5t8":"C36-Q062-P424","xupcew":"C36-Q063-P424","q1y8sd":"C37-Q001-P424","19p2ui4":"C37-Q002-P425","uzb0st":"C37-Q003-P425","1nej9ti":"C37-Q004-P425","ya41ul":"C37-Q005-P425","jhykr6":"C37-Q006-P425","xq0flc":"C37-Q007-P425","okbvx2":"C37-Q008-P426","1eknth9":"C37-Q009-P426","1ybfe7":"C37-Q010-P426","ur4oid":"C37-Q011-P426","vqb1km":"C37-Q012-P426","16a0s3y":"C37-Q013-P427","1dxeney":"C37-Q014-P427","1pe8kci":"C37-Q015-P427","1nidkek":"C37-Q016-P427","1gao49q":"C37-Q017-P427","1dmqaz0":"C37-Q018-P427","1kvg84e":"C37-Q019-P427","1mbamjt":"C37-Q020-P427","cn5pr4":"C37-Q021-P428","uvbib7":"C37-Q023-P428","13loruc":"C37-Q024-P428","1a1u0g9":"C37-Q025-P429","1c5kt7p":"C37-Q026-P429","qnw8m3":"C37-Q027-P429","1wm6r3z":"C37-Q028-P430","pcx16d":"C37-Q029-P430","3h350z":"C37-Q030-P430","1cirvjp":"C37-Q031-P430","16hjmlx":"C37-Q032-P430","1nja3pr":"C37-Q033-P431","px596j":"C37-Q034-P431","8isx1a":"C37-Q035-P431","1levnfw":"C37-Q036-P431","1347awc":"C37-Q037-P432","hwsu7p":"C37-Q038-P432","ydr753":"C37-Q039-P432","k8h4s4":"C37-Q040-P432","13r8f4x":"C37-Q041-P432","1x0f743":"C37-Q042-P432","1v1ie35":"C37-Q043-P433","16uouqt":"C37-Q044-P433","ibuv7d":"C37-Q045-P433","1j2zoz3":"C37-Q046-P433","1p5b2vi":"C37-Q047-P433","1gm4ilz":"C37-Q048-P433","1t2x9fn":"C37-Q049-P434","1laivpa":"C37-Q050-P434","oasyw0":"C37-Q051-P434","1bl726r":"C37-Q052-P434","1em2yao":"C37-Q053-P435","glf4s9":"C37-Q054-P435","1touuo3":"C37-Q055-P435","ocviql":"C37-Q056-P435","15iesme":"C37-Q057-P435","1dab8py":"C38-Q001-P437","1k3wdm2":"C38-Q002-P437","127s0wt":"C38-Q003-P437","1h4yx6z":"C38-Q004-P437","1hshyio":"C38-Q005-P437","eus007":"C38-Q006-P438","1dy2mfb":"C38-Q007-P438","1katbjp":"C38-Q008-P438","ukh48w":"C38-Q009-P438","42t56f":"C38-Q010-P438","2pl7ha":"C38-Q011-P439","izmtms":"C38-Q012-P439","wjbz76":"C38-Q013-P439","15f596b":"C38-Q014-P440","18apidq":"C38-Q015-P440","g15vi2":"C38-Q016-P440","1n68q21":"C38-Q017-P440","1h2dr1s":"C38-Q018-P441","owjc87":"C38-Q019-P441","vwqwyt":"C38-Q020-P441","yko8db":"C38-Q021-P441","25z7ff":"C38-Q022-P442","1kjb0n8":"C38-Q023-P442","y4ntaw":"C38-Q024-P442","sgymta":"C38-Q025-P442","8runt0":"C38-Q026-P442","lyv4r5":"C38-Q027-P443","jpv8kh":"C38-Q028-P443","500ahy":"C38-Q029-P443","1add6c7":"C38-Q030-P443","xdnk5d":"C38-Q031-P444","gjh7nm":"C38-Q032-P444","1611ehk":"C38-Q033-P445","15tswhi":"C38-Q034-P445","1pfhnhr":"C38-Q035-P445","1y9y90b":"C38-Q036-P445","5u8cye":"C38-Q037-P446","8q4l6l":"C38-Q038-P446","mu4hul":"C38-Q039-P446","tmsw42":"C38-Q040-P446","1mbr935":"C38-Q041-P446","1y5xkfi":"C38-Q042-P447","1rk42ep":"C38-Q043-P447","1n3ml19":"C38-Q044-P447","1iwa3hf":"C38-Q045-P447","1kesvzr":"C38-Q046-P447","1j48l5p":"C38-Q047-P447","1eruret":"C38-Q048-P447","rf388w":"C38-Q049-P447","9jtgv4":"C38-Q050-P447","11uoisi":"C38-Q051-P448","1qxcq2x":"C38-Q052-P448","1dab3lk":"C38-Q053-P448","srbvn":"C38-Q054-P448","lf0sdu":"C38-Q055-P448","mx2x3g":"C38-Q056-P448","1hh72yp":"C38-Q057-P448","v0o131":"C38-Q058-P449","h6q8ia":"C38-Q059-P449","1ew57jp":"C38-Q060-P449","1gw5xf7":"C38-Q061-P449","18wbsz2":"C38-Q062-P449","1dreu3u":"C38-Q063-P449","5p7n6b":"C38-Q064-P449","1fsebdt":"C38-Q065-P450","kuajxi":"C38-Q066-P450","1fwhuep":"C38-Q067-P450","ehnp3c":"C38-Q068-P450","173qx7s":"C38-Q069-P450","16fy1ol":"C38-Q070-P450","13it2hn":"C38-Q071-P450","fjmmge":"C38-Q072-P451","1c8nsy0":"C38-Q073-P451","d9j9x7":"C38-Q074-P451","8pxgqv":"C38-Q075-P451","zv80ak":"C38-Q076-P451","9dtxmn":"C38-Q077-P452","1qwyibh":"C38-Q078-P452","1r13mzw":"C38-Q079-P452","vw3308":"C38-Q080-P452","18y24vq":"C38-Q081-P452","16ccud3":"C38-Q082-P452","12pgbg7":"C38-Q083-P452","axpw6e":"C38-Q084-P453","1wd5ema":"C38-Q085-P453","1gu4e57":"C38-Q086-P453","1cc2pmd":"C38-Q087-P453","1wpsd6h":"C38-Q088-P454","1yk42a8":"C38-Q089-P454","5gn4m2":"C38-Q090-P454","77aqt0":"C39-Q001-P455","1klucwi":"C39-Q002-P455","1qdd2f5":"C39-Q003-P455","1j3a9qz":"C39-Q004-P456","1k2e6yl":"C39-Q005-P456","1fhlynq":"C39-Q006-P456","1p9aou":"C39-Q007-P456","cpjovp":"C39-Q008-P456","1jcecle":"C39-Q009-P457","1nb4m2q":"C39-Q010-P457","1izdife":"C39-Q011-P457","s72tra":"C39-Q012-P457","u0ar8n":"C39-Q013-P457","12om4wy":"C39-Q014-P457","1gz60jo":"C39-Q015-P457","1sgys56":"C39-Q016-P457","vxgk8f":"C39-Q017-P457","ixxi0c":"C39-Q018-P458","ckk1ng":"C39-Q019-P458","l9s5qy":"C39-Q020-P458","zjeypk":"C39-Q021-P458","b502su":"C39-Q022-P458","jqn739":"C39-Q023-P458","j1ljtu":"C39-Q024-P458","14wibpg":"C39-Q025-P459","qksnrd":"C39-Q026-P459","1nsp8l1":"C40-Q001-P460","q5gimm":"C40-Q002-P460","12i2q8v":"C40-Q003-P460","175chbi":"C40-Q004-P460","1nn1p9d":"C40-Q004-P473","f9mwad":"C40-Q005-P460","1x3jiya":"C40-Q006-P460","p1efe8":"C40-Q007-P460","1ewd4d3":"C40-Q008-P460","1ngsacf":"C40-Q009-P461","zzqvkg":"C40-Q010-P461","jdo9s2":"C40-Q011-P461","1bi18ee":"C40-Q012-P461","1pm37p1":"C40-Q013-P461","1pci5wf":"C40-Q014-P461","123b2kq":"C40-Q015-P462","101iy97":"C40-Q016-P462","1t8vpy0":"C40-Q017-P462","cwlgjt":"C40-Q019-P462","lyrmq5":"C40-Q020-P462","qrv6ul":"C40-Q021-P462","1a8uhdr":"C40-Q022-P462","1frhgj2":"C40-Q023-P463","1o2pz7j":"C40-Q024-P463","1tovexm":"C40-Q025-P463","1obiifv":"C40-Q026-P463","17j85qi":"C40-Q027-P463","s9tddb":"C40-Q028-P464","113nigw":"C40-Q029-P464","dlrfbq":"C40-Q030-P464","1ay5fja":"C40-Q031-P464","1g879ap":"C40-Q032-P465","zuijv7":"C40-Q033-P465","tsngzy":"C40-Q034-P465","1byfnrz":"C40-Q035-P465","1gtz1l2":"C40-Q036-P466","12vf4tg":"C40-Q037-P466","1fwgv3n":"C40-Q038-P466","yf4o76":"C40-Q039-P466","1cwmdnf":"C40-Q040-P466","1afrjr6":"C40-Q041-P466","16ea1hb":"C40-Q042-P467","15dbmdh":"C40-Q043-P467","1l53hqj":"C40-Q044-P467","1h2vq99":"C40-Q045-P467","kw71jz":"C40-Q046-P467","1kfjhha":"C40-Q047-P467","r8quoz":"C40-Q048-P467","cw2tlt":"C40-Q049-P467","1shq0hi":"C40-Q050-P467","1vfiznp":"C40-Q051-P468","v3esgo":"C40-Q052-P468","1ecif1":"C40-Q053-P468","1phng7o":"C40-Q054-P468","j7916":"C40-Q055-P468","ocahl3":"C40-Q056-P469","14pp3xy":"C40-Q057-P469","9fmkyn":"C40-Q058-P469","10ptc2":"C40-Q059-P469","18d362":"C40-Q060-P469","k6ajis":"C40-Q061-P469","qjqbqa":"C40-Q062-P469","12se9xy":"C40-Q063-P470","12cg8yz":"C40-Q064-P470","udnme6":"C40-Q065-P470","1c3swd6":"C40-Q066-P470","z3wt26":"C40-Q067-P470","incg8a":"C40-Q068-P470","1vqx8j5":"C40-Q069-P470","tvytqv":"C40-Q070-P471","19jhh8w":"C40-Q071-P471","wfj2sr":"C40-Q072-P471","14ufgo9":"C40-Q073-P471","ct3wtc":"C40-Q074-P471","13sibej":"C40-Q075-P472","rc388a":"C40-Q076-P472","1gov3wu":"C40-Q077-P472","nqaksw":"C40-Q078-P472","1ir15vb":"C40-Q079-P473","1uuiwoz":"C40-Q080-P473","ytx27k":"C40-Q081-P473","nbm4um":"C40-Q083-P473","g67rxm":"C40-Q084-P473","9nw8za":"C40-Q085-P473","cmlpzl":"C40-Q086-P474","vily78":"C40-Q087-P474","xzxv8n":"C40-Q088-P474","uut618":"C40-Q089-P474","op7ttm":"C40-Q090-P474","m85fnj":"C40-Q091-P474","19itone":"C40-Q092-P474","3cevy0":"C40-Q093-P475","vpgr8h":"C40-Q094-P475","ous1d4":"C40-Q095-P475","1fhvp12":"C40-Q096-P475","ke0525":"C40-Q097-P476","1owvscg":"C40-Q098-P476","77os39":"C40-Q099-P476","iqxql9":"C40-Q100-P476","1i17k9t":"C40-Q101-P476","how4k":"C40-Q102-P476","1f7dav2":"C40-Q103-P476","rs115s":"C40-Q104-P476","gr0j1x":"C40-Q105-P476","1656evx":"C40-Q106-P477","1v3d2p4":"C40-Q107-P477","1ay80f6":"C40-Q108-P477","1vjgiid":"C40-Q109-P477","1llxbo7":"C40-Q110-P477","61qdqn":"C40-Q111-P478","1foc6df":"C40-Q112-P478","nldh3s":"C40-Q113-P478","etextb":"C40-Q114-P478","nq19ik":"C40-Q115-P478","1kxvu2x":"C40-Q116-P478","ej682i":"C40-Q117-P478","15bq07d":"C40-Q118-P478","1d7cbk4":"C40-Q119-P478","1lr4ye3":"C40-Q120-P478","uowtty":"C40-Q121-P478","plkkon":"C40-Q122-P479","1h0vnbm":"C40-Q123-P479","clxhd":"C40-Q124-P479","1vb8lfl":"C40-Q125-P479","7zzr1x":"C40-Q126-P479","128vacf":"C40-Q127-P480","kxszsx":"C40-Q128-P480","1nj49va":"C40-Q129-P480","b8j0y":"C40-Q130-P480","1q3jk9u":"C40-Q131-P480","n8lf94":"C40-Q132-P480","geuan0":"C40-Q133-P480","johl42":"C40-Q134-P481","11kgksa":"C40-Q135-P481","120tdvw":"C40-Q136-P481","124g68l":"C40-Q137-P481","rok7kw":"C40-Q138-P482","1e522vz":"C40-Q139-P482","1dj4kim":"C40-Q140-P482","1d030cb":"C40-Q141-P482","om0l8f":"C40-Q142-P482","qkvt6b":"C40-Q143-P483","1bu4tel":"C40-Q144-P483","uac63w":"C40-Q145-P483","iyqvlj":"C40-Q146-P483","1y0r5v4":"C40-Q147-P483","7h1q2i":"C40-Q148-P483","1vkz8uu":"C40-Q149-P484","1s529nn":"C40-Q150-P484","1e7z4l4":"C40-Q151-P484","li99hs":"C40-Q152-P484","1rifl0v":"C40-Q153-P484","1dod9xp":"C40-Q154-P484","1mo9hn0":"C40-Q155-P484","152xdj7":"C40-Q156-P485","1cfyyjf":"C40-Q157-P485","2avm0u":"C40-Q158-P485","1hjt7cs":"C40-Q159-P485","vs8s4g":"C40-Q160-P486","2abup7":"C40-Q161-P486","gim22b":"C40-Q162-P486","1illpw5":"C40-Q163-P486","1k8rs9c":"C40-Q164-P486","1kjn7xs":"C40-Q165-P486","hsqbns":"C40-Q166-P487","mjizj6":"C40-Q167-P487","dkyfr0":"C40-Q168-P487","1ezteju":"C40-Q169-P487","1tm45u5":"C40-Q170-P487","2a5jpd":"C40-Q171-P487","b9yx6z":"C40-Q172-P487","1j67muy":"C40-Q173-P488","13ovtor":"C40-Q174-P488","pcnpcf":"C40-Q175-P488","zawp9h":"C40-Q176-P488","d9mysx":"C40-Q177-P489","1acepyc":"C40-Q178-P489","1e7tqco":"C40-Q179-P489","1l8ydt7":"C40-Q180-P489","qh9l0d":"C40-Q181-P489","1rtx2o":"C40-Q182-P489","1xolpdb":"C40-Q183-P489","52f3nn":"C40-Q184-P490","1iazpug":"C40-Q185-P490","sswb12":"C40-Q186-P490","1uwgkye":"C40-Q187-P490","vb76it":"C40-Q188-P490","2rg24m":"C40-Q189-P491","13hkk0n":"C40-Q190-P491","g8wep9":"C40-Q191-P491","dwfesl":"C40-Q192-P491","3f0m1a":"C40-Q193-P491","1endglc":"C40-Q194-P491","1k6xfuc":"C40-Q195-P492","1qeq09t":"C40-Q196-P492","1k1xt0x":"C40-Q197-P492","3mksdx":"C40-Q198-P492","p6942j":"C40-Q199-P492","qvhuz5":"C40-Q200-P492","iwihf0":"C40-Q201-P493","1lyvr7a":"C40-Q202-P493","5onyzv":"C40-Q203-P493","lbpi2":"C40-Q204-P493","8ksmsj":"C40-Q205-P493","7qf4gi":"C40-Q206-P494","fmev3e":"C40-Q207-P494","1s8hl7b":"C40-Q208-P495","fadjus":"C40-Q209-P495","7i347l":"C40-Q210-P495","1l1rup8":"C40-Q211-P495","14huqhs":"C40-Q212-P495","mxlvee":"C40-Q213-P496","1b4bwlk":"C40-Q214-P496","kaojwm":"C40-Q215-P496","1aikbym":"C40-Q216-P496","dle3qt":"C40-Q217-P496","13m8d58":"C40-Q218-P496","11w23t3":"C40-Q219-P497","1pfoiku":"C40-Q220-P497","1j9ee7m":"C40-Q221-P497","1cm9427":"C40-Q222-P497","mk0q4e":"C41-Q001-P498","16r8cfr":"C41-Q002-P499","84ycvb":"C41-Q003-P499","1kpvm9z":"C41-Q004-P499","k85dxe":"C41-Q005-P499","1h7r30w":"C41-Q006-P499","1lvg4ns":"C41-Q007-P499","1m01e0r":"C41-Q008-P500","1as1dwf":"C41-Q009-P500","1cpf6zm":"C41-Q010-P500","1n7j4s0":"C41-Q011-P500","1e4rvdm":"C41-Q012-P501","176o0ea":"C41-Q013-P501","1mjwgjx":"C41-Q014-P501","17s8d21":"C41-Q015-P501","1d4419g":"C41-Q016-P501","1ymngzv":"C41-Q017-P501","6ti8va":"C41-Q018-P502","1hz3y19":"C41-Q019-P502","1nifgxv":"C41-Q020-P502","1rgzgl3":"C41-Q021-P502","e5vk6c":"C41-Q022-P502","17lwdgj":"C41-Q023-P503","1j9b3ja":"C41-Q024-P503","hn8fml":"C41-Q025-P503","17valc2":"C41-Q026-P503","1otslsi":"C41-Q027-P504","1c73tph":"C41-Q028-P504","1yquh3k":"C41-Q029-P504","1gpgszy":"C42-Q001-P504","1tqyh5w":"C42-Q002-P504","1u223xj":"C42-Q003-P505","1nazxq4":"C42-Q004-P505","m4l2rj":"C42-Q005-P505","xajgki":"C42-Q006-P505","19419he":"C42-Q007-P505","1dutbri":"C42-Q008-P505","he4tq3":"C42-Q009-P506","nnn31b":"C42-Q010-P506","1kjxbr2":"C42-Q011-P506","1ghuyv8":"C42-Q012-P506","69lbc4":"C42-Q013-P506","5izdl2":"C42-Q014-P507","132i3ad":"C42-Q015-P507","c5dq14":"C42-Q016-P507","igp7v8":"C42-Q017-P507","1j5gme1":"C42-Q018-P507","rz1jgm":"C42-Q019-P507","8dx8xn":"C42-Q020-P508","16u1k7l":"C42-Q021-P508","1dzjnjm":"C42-Q022-P508","6neiv5":"C42-Q023-P508","1pxqaol":"C42-Q024-P508","15gwjpo":"C42-Q025-P509","mofb3y":"C42-Q026-P509","8hcfj3":"C42-Q027-P509","lv702o":"C42-Q028-P509","1ucme1o":"C42-Q029-P509","c4180o":"C42-Q030-P509","1v0o4ni":"C42-Q031-P510","15nrjo7":"C42-Q032-P510","13w7b6n":"C42-Q033-P510","le2g8j":"C42-Q034-P510","ayv1ev":"C42-Q035-P510","ey1626":"C42-Q036-P510","1567em9":"C42-Q037-P511","stjjcg":"C42-Q038-P511","t6k7fk":"C42-Q039-P511","1276e49":"C42-Q040-P511","1cdoxc0":"C42-Q041-P511","mltr9j":"C42-Q042-P511","1nfy53m":"C42-Q043-P512","1uy9fva":"C42-Q044-P512","1he18ir":"C42-Q045-P512","1m6bse3":"C42-Q046-P512","hdo8r":"C42-Q047-P512","gebl0":"C42-Q048-P512","vp2tea":"C42-Q049-P512","1wedumo":"C42-Q050-P513","x09v7p":"C42-Q051-P513","j0jw7p":"C42-Q052-P513","1uqqwj3":"C42-Q053-P513","1uih2ux":"C42-Q054-P513","5tu2on":"C42-Q055-P513","xyyiwv":"C42-Q056-P513","y3cz69":"C42-Q057-P513","1d036ff":"C42-Q058-P514","rh9pxx":"C42-Q059-P514","1dqkc6f":"C42-Q060-P514","32c9pg":"C42-Q061-P514","1ehihaa":"C42-Q062-P514","up33l4":"C42-Q063-P514","904ppx":"C42-Q064-P515","108agkq":"C42-Q065-P515","1wr4m8h":"C42-Q066-P515","vfjlgn":"C42-Q067-P515","mh0565":"C42-Q068-P515","16vslu":"C42-Q069-P516","1gakjsb":"C42-Q070-P516","zsjon2":"C42-Q071-P516","tzi392":"C42-Q072-P516","xzgvdx":"C42-Q073-P517","19j9xhh":"C42-Q074-P517","3xzpd0":"C42-Q075-P517","1fkscin":"C42-Q076-P517","1yzy5pz":"C42-Q077-P518","c1s7ku":"C42-Q078-P518","uwz59s":"C42-Q079-P518","elnmw4":"C42-Q080-P518","kkh7aj":"C42-Q081-P519","4z8qx3":"C42-Q082-P519","1i0nr2q":"C42-Q083-P519","1x4dwpi":"C42-Q084-P519","1gvelou":"C42-Q085-P519","1a7qctw":"C42-Q086-P520","71ugwv":"C42-Q087-P520","114iuwn":"C42-Q088-P520","1536f03":"C42-Q089-P520","kdmb0s":"C42-Q090-P520","3p2gw8":"C42-Q091-P521","fau4o5":"C42-Q092-P521","1hxo3zi":"C42-Q093-P521","n19vrh":"C42-Q094-P521","6d0h1f":"C42-Q095-P521","121ls1e":"C42-Q096-P521","gbkp5c":"C42-Q097-P521","mr30au":"C42-Q098-P522","1xuvray":"C42-Q099-P522","z1seki":"C42-Q100-P522","18266gi":"C42-Q101-P522","o3t28m":"C42-Q102-P522","1681vy2":"C42-Q103-P522","1g7wwve":"C42-Q104-P523","elahml":"C42-Q105-P523","1mzcnrp":"C42-Q106-P523","1s7hfam":"C42-Q107-P524","ughf0k":"C42-Q108-P524","jxfm8l":"C42-Q109-P524","cxbsyr":"C42-Q110-P524","15t7c8":"C42-Q111-P525","7cj3pw":"C42-Q112-P525","1vplwkl":"C42-Q113-P525","1xzcg1f":"C42-Q114-P525","uyvvab":"C42-Q115-P525","1b1ebmv":"C42-Q116-P525","fe94s5":"C42-Q117-P526","118zut":"C42-Q118-P526","qlic96":"C42-Q119-P526","1t7l1zj":"C42-Q120-P526","dqvn99":"C42-Q121-P526","10yyr7j":"C42-Q122-P526","1no11y5":"C42-Q123-P527","14eufaq":"C42-Q124-P527","1wpmaov":"C42-Q125-P527","ygnu9m":"C42-Q126-P527","1sfeljr":"C42-Q127-P527","16uwgbo":"C42-Q128-P528","1fp220d":"C42-Q129-P528","10d4475":"C42-Q130-P528","kne5i1":"C42-Q131-P528","187mitw":"C42-Q132-P529","7txrby":"C42-Q133-P529","gjo2vj":"C42-Q134-P529","e6kftf":"C42-Q135-P529","igtts1":"C42-Q136-P530","13k647a":"C42-Q137-P530","1iuwmoj":"C42-Q138-P530","1ul2smu":"C42-Q139-P530","yzkk8y":"C42-Q140-P530","1f9dxyt":"C42-Q141-P530"}};
const polityOriginal = new Map();
for (const [id, [, imported]] of Object.entries(polityCatalog.entries)) {
 polityOriginal.set(id,id);
 if(imported)polityOriginal.set(imported,id);
}
function buildProgressIndex(subject) {
 const ids=new Set(subject.data.questions.map(q=>q.id));
 const knownPolity=subject.id==='polity'||(/indian polity.{0,12}governance/i.test(subject.name)&&subject.data.questions.some(q=>polityOriginal.has(q.id)));
 const aliases=new Map(knownPolity?polityOriginal:[]);
 const liveIds=new Map();
 if(knownPolity){
  const clean=s=>String(s||'').toLowerCase().replace(/[^a-z0-9]/g,'');
  for(const q of subject.data.questions){
   if(aliases.has(q.id))continue;
   const fingerprint=h32(q.chapter+'|'+clean(q.prompt)+'|'+q.options.map(o=>clean(o.text)).join('|'));
   const original=polityCatalog.prints[fingerprint];
   if(original&&!ids.has(original)&&!ids.has(polityCatalog.entries[original][1])){
    if(liveIds.has(original)){aliases.delete(liveIds.get(original));liveIds.set(original,null);}
    else {aliases.set(q.id,original);liveIds.set(original,q.id);}
   }
  }
 }
 const canonical=id=>aliases.get(id)||id;
 const current=new Set([...ids].map(canonical));
 const chapters=new Map(subject.data.chapters.map(c=>[c.title,c.no]));
 const earlierChapter=id=>{
  const row=knownPolity&&polityCatalog.entries[canonical(id)];
  return row?chapters.get(polityCatalog.chapters[row[0]-1]):undefined;
 };
 return {canonical,current,earlierChapter,knownPolity};
}
let progressIndex;
function progressStorageKey(id) {
 const original=progressIndex?.canonical(id)||id;
 const imported=polityCatalog.entries[original]?.[1];
 if(!progressIndex?.knownPolity)return id;
 let best=id;
 for(const key of [original,imported]){
  if(key&&QS[key]&&(!QS[best]||(QS[key].t||0)>(QS[best].t||0)))best=key;
 }
 return best;
}
function earlierProgress(index, saved, records, subject) {
 const counts=new Map(),seen=new Set(),historical=new Map();
 const chapters=new Map(subject.data.chapters.map(c=>[c.title,c.no]));
 for(const rec of records){
  if(rec.subj!==subject.id)continue;
  for(const w of rec.wrong||[])if(w.id&&chapters.has(w.ch))historical.set(w.id,chapters.get(w.ch));
  if(rec.rows?.length===1&&chapters.has(rec.rows[0].t)){
   for(const [id] of rec.items||[])historical.set(id,chapters.get(rec.rows[0].t));
  }
 }
 for(const id of Object.keys(saved)){
  const key=index.canonical(id);
  if(index.current.has(key)||seen.has(key))continue;
  const chapter=index.earlierChapter(key)??historical.get(id);
  if(chapter===undefined)continue;
  seen.add(key);counts.set(chapter,(counts.get(chapter)||0)+1);
 }
 return counts;
}

async function loadSubjData(s){progressIndex=buildProgressIndex(s);QS=(await kv.get('qs:'+s.id))||{};NOTES=(await kv.get('notes:'+s.id))||{};NTS=(await kv.get('nts:'+s.id))||{};}
function persistSoon(){clearTimeout(_ps);_ps=setTimeout(flushPersist,900);}
function flushPersist(){if(_ps==null)return;clearTimeout(_ps);_ps=null;if(SUBJ){kv.set('qs:'+SUBJ.id,QS);kv.set('notes:'+SUBJ.id,NOTES);kv.set('nts:'+SUBJ.id,NTS);}kv.set('daily',DAILY);kv.set('prefs',PREFS);}
function recordResult(q,g){
 if(!q||(g!=='correct'&&g!=='wrong'))return;
 const s=QS[progressStorageKey(q.id)]||(QS[progressStorageKey(q.id)]={a:0,c:0,w:0,b:0,t:0,d:0});s.a++;if(g==='correct'){s.c++;s.b=Math.min(5,s.b+1);}else{s.w++;s.b=0;}
 s.confidence=sess.confidence?.[q.id]||'';s.lastGrade=g;
 s.t=Date.now();s.d=s.t+INTERVALS[s.b]*864e5;const k=dayKey();DAILY[k]=(DAILY[k]||0)+1;persistSoon();}
function gradePending(){for(const [id,a] of answers)if(a.grade==='pending'){a.grade=gradeOf(byId.get(id),a);recordResult(byId.get(id),a.grade);}}
function autoSubmit(){gradePending();submitted=true;setPaused(false);stopClock();logSession('submitted');$('testSubmit').textContent='Summary';render();showSummary();toast('Time is up — your test was submitted.');}

/* notes */
const noteBox=q=>`<details class="mynote" ${NOTES[q.id]?'open':''}><summary>📝 ${NOTES[q.id]?'My note':'Add a note'}</summary><textarea id="noteTa" placeholder="A memory trick, source or doubt to revisit…">${esc(NOTES[q.id]||'')}</textarea></details>`;
const nMeta=id=>{const q=byId.get(id);return{ts:Date.now(),c:q?q.chapterNo:0,ch:q?q.chapter:'',n:q?String(q.number):'',p:q?String(q.prompt||'').slice(0,160):''}};
function setNote(id,t){if(t.trim()){NOTES[id]=t;NTS[id]=nMeta(id);}else{delete NOTES[id];delete NTS[id];}persistSoon();}

/* "Show" filter counts */
const VIEW_BASE={due:'Due for revision',everwrong:'Missed before',weak:'Weak: under 60%',new:'Never attempted',noted:'With my notes'};
function refreshViewCounts(){
 if(!DATA)return;const now=Date.now(),c={due:0,everwrong:0,weak:0,new:0,noted:0};
 for(const q of DATA.questions){const s=QS[progressStorageKey(q.id)];if(!s)c.new++;else{if(s.d<=now)c.due++;if(s.w)c.everwrong++;if(s.a&&s.c/s.a<.6)c.weak++;}if(NOTES[q.id])c.noted++;}
 for(const o of viewFilter.options)if(VIEW_BASE[o.value])o.textContent=`${VIEW_BASE[o.value]} (${c[o.value]})`;return c;}
$('reviseBtn').addEventListener('click',()=>{const c=refreshViewCounts();if(!c.due){toast('Nothing is due for revision right now — nice work!');return;}
 chosenChapters.clear();groupFilter.value='all';fillChapters();[examFilter,yearFilter].forEach(s=>s.value='all');viewFilter.value='due';search='';$('searchBox').value='';setTab('quiz');document.body.classList.remove('fopen');userFilter();toast(`${c.due} questions due for revision.`);});

/* ---------- Excel / CSV reading (no external library) ---------- */
async function inflateRaw(u8){const ds=new DecompressionStream('deflate-raw'),w=ds.writable.getWriter();w.write(u8);w.close();return new Uint8Array(await new Response(ds.readable).arrayBuffer());}
function unzip(buf){const u8=new Uint8Array(buf),dv=new DataView(buf);let e=u8.length-22;while(e>=0&&dv.getUint32(e,true)!==0x06054b50)e--;if(e<0)throw new Error('This is not a valid .xlsx file.');
 const n=dv.getUint16(e+10,true);let p=dv.getUint32(e+16,true);const files={},dec=new TextDecoder();
 for(let i=0;i<n&&dv.getUint32(p,true)===0x02014b50;i++){const meth=dv.getUint16(p+10,true),csz=dv.getUint32(p+20,true),nl=dv.getUint16(p+28,true),el=dv.getUint16(p+30,true),cl=dv.getUint16(p+32,true),off=dv.getUint32(p+42,true),name=dec.decode(u8.subarray(p+46,p+46+nl));p+=46+nl+el+cl;
  const st=off+30+dv.getUint16(off+26,true)+dv.getUint16(off+28,true);files[name]={meth,data:u8.subarray(st,st+csz)};}
 return files;}
const fileText=async f=>new TextDecoder().decode(f.meth===0?f.data:await inflateRaw(f.data));
const unent=s=>s.indexOf('&')<0?s:s.replace(/&(#x[0-9a-f]+|#\d+|amp|lt|gt|quot|apos);/gi,(m,e)=>{e=e.toLowerCase();return e==='amp'?'&':e==='lt'?'<':e==='gt'?'>':e==='quot'?'"':e==='apos'?"'":String.fromCodePoint(e[1]==='x'?parseInt(e.slice(2),16):+e.slice(1));});
const tText=x=>{let o='',m;const re=/<t\b[^>]*?(?:\/>|>([\s\S]*?)<\/t>)/g;x=x.replace(/<rPh\b[\s\S]*?<\/rPh>/g,'');while((m=re.exec(x)))o+=m[1]||'';return unent(o);};
function parseSheet(x,ss){
 const rows=[],re=/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g;let m;
 while((m=re.exec(x))){const at=m[1],r=/\br="([A-Z]+)(\d+)"/.exec(at);if(!r)continue;let ci=0;for(const ch of r[1])ci=ci*26+ch.charCodeAt(0)-64;ci--;
  const ty=(/\bt="(\w+)"/.exec(at)||[])[1],body=m[2]||'';let v='';
  if(ty==='inlineStr')v=tText(body);else{const vm=/<v[^>]*>([\s\S]*?)<\/v>/.exec(body);v=vm?unent(vm[1]):'';if(ty==='s')v=ss[+v]??'';else if(ty==='b')v=v==='1'?'TRUE':'FALSE';}
  (rows[+r[2]-1]||(rows[+r[2]-1]=[]))[ci]=v;}
 return Array.from(rows,r=>r||[]);}
async function parseXlsx(buf){
 const z=unzip(buf),X=n=>z[n]?fileText(z[n]):Promise.resolve(null),dp=new DOMParser(),P=s=>dp.parseFromString(s,'application/xml');
 const wbx=await X('xl/workbook.xml');if(!wbx)throw new Error('This is not a valid Excel workbook.');
 const wb=P(wbx),rels=P(await X('xl/_rels/workbook.xml.rels')),sst=await X('xl/sharedStrings.xml');
 const ss=sst?(sst.match(/<si\b[\s\S]*?<\/si>|<si\s*\/>/g)||[]).map(tText):[];const out=[];
 for(const sh of wb.getElementsByTagName('sheet')){
  const rid=sh.getAttribute('r:id'),rel=[...rels.getElementsByTagName('Relationship')].find(r=>r.getAttribute('Id')===rid);if(!rel)continue;
  let t=rel.getAttribute('Target');t=t.startsWith('/')?t.slice(1):'xl/'+t.replace(/^\.\//,'');if(!z[t])continue;
  out.push({name:sh.getAttribute('name')||'Sheet',rows:parseSheet(await X(t),ss)});}
 if(!out.length)throw new Error('No sheets were found in this workbook.');return out;}
function parseCsv(t){
 t=t.replace(/^\uFEFF/,'');const first=t.split('\n',1)[0],d=[',',';','\t'].map(x=>[x,first.split(x).length]).sort((a,b)=>b[1]-a[1])[0][0],rows=[];let r=[],f='',q=false;
 for(let i=0;i<t.length;i++){const c=t[i];if(q){if(c==='"'){if(t[i+1]==='"'){f+='"';i++;}else q=false;}else f+=c;}
  else if(c==='"')q=true;else if(c===d){r.push(f);f='';}else if(c==='\n'||c==='\r'){if(c==='\r'&&t[i+1]==='\n')i++;r.push(f);f='';rows.push(r);r=[];}else f+=c;}
 if(f!==''||r.length){r.push(f);rows.push(r);}return rows;}

/* ---------- sheet rows → subject ---------- */
function rowsToRaw(rows,info){
 const h=rows.findIndex(r=>r&&r.some(c=>String(c??'').trim()));if(h<0)return{err:['The sheet is empty.']};
 const head=rows[h].map(c=>String(c??'').trim().toLowerCase().replace(/[^a-z0-9]+/g,' ').trim()),find=(...k)=>head.findIndex(x=>k.includes(x));
 const col={paper:find('paper id'),pno:find('paper number'),ptotal:find('paper total'),qid:find('question id'),ch:find('chapter','chapter name','topic','unit'),gr:find('group','era','category','branch','section'),q:find('question','questions','q','prompt'),an:find('answer','correct answer','correct','ans','key','correct option'),ex:find('explanation','solution','rationale','explain'),exam:find('exam','exams','exam tag','source','previous year','pyq'),yr:find('year')};
 const oi='abcdef'.split('').map(L=>find(L,'option '+L,'opt '+L,'options '+L,'choice '+L));
 const pictureColumns=head.map((name,i)=>/^(?:image|images|picture|figure|diagram|question image|(?:img|image|picture) [a-f]|(?:opt|option) [a-f] image)$/.test(name)?i:-1).filter(i=>i>=0);
 if(rows.slice(h+1).some(row=>pictureColumns.some(i=>String(row?.[i]??'').trim()))){
  return {err:['This workbook references pictures. Import it on the admin page and select the picture files there.']};
 }
 const err=[];if(col.q<0)err.push('No “Question” column found — the first row must hold the column headings (Chapter, Question, Option A …).');if(oi[0]<0||oi[1]<0)err.push('Columns “Option A” and “Option B” are required.');
 if(err.length)return{err};
 const qs=[];let lastCh='',lastGr='';
 for(let i=h+1;i<rows.length;i++){const r=rows[i]||[];if(!r.some(c=>String(c??'').trim()))continue;const g=k=>k<0?'':String(r[k]??'').trim();
  const ch=g(col.ch)||lastCh,gr=g(col.gr)||(g(col.ch)?'':lastGr);lastCh=ch;lastGr=gr||lastGr;if(g(col.ch)&&!g(col.gr))lastGr='';
  const opts=oi.map(g);let n=opts.length;while(n>0&&!opts[n-1])n--;
  const ans=g(col.an).toLowerCase().replace(/[().]/g,'').split(/[\s,;&\/]+/).filter(x=>x&&x!=='and').map(x=>/^[1-6]$/.test(x)?'abcdef'[+x-1]:x);
  let ex=g(col.exam).split(/[;|\n]+/).map(s=>s.trim()).filter(Boolean);const y=g(col.yr).match(/(?:19|20)\d{2}/);
  if(y)ex=ex.length?ex.map(s=>/(?:19|20)\d{2}/.test(s)?s:s+' '+y[0]):['PYQ '+y[0]];
  qs.push({_row:i+1,paper:g(col.paper)?{id:g(col.paper),no:Number(g(col.pno))||0,total:Number(g(col.ptotal))||0}:undefined,questionId:g(col.qid),chapter:ch||undefined,group:gr,question:g(col.q),options:opts.slice(0,n),answer:ans,explanation:g(col.ex),exams:ex});}
 return{raw:{subject:info.subject||'',subtitle:info.subtitle||'',groupLabel:info.groupLabel||'',questions:qs}};}
async function readFileToRaw(f){
 const ext=(f.name.split('.').pop()||'').toLowerCase(),stem=f.name.replace(/\.[^.]+$/,'');
 if(ext==='json')return{raw:JSON.parse(await f.text()),stem};
 let sheets;
 if(['csv','tsv','txt'].includes(ext))sheets=[{name:'Questions',rows:parseCsv(await f.text())}];
 else if(['xlsx','xlsm'].includes(ext)){if(typeof DecompressionStream==='undefined')throw new Error('This browser cannot open .xlsx directly. In Excel use File ▸ Save As ▸ CSV UTF-8 and import that file instead.');sheets=await parseXlsx(await f.arrayBuffer());}
 else throw new Error('Unsupported file type “.'+ext+'”. Please use .xlsx, .csv or .json.');
 const q=sheets.find(s=>/question/i.test(s.name))||sheets[0],info={},is=sheets.find(s=>s!==q&&/^(info|about|subject|settings)/i.test(s.name));
 if(is)for(const r of is.rows){const k=String(r&&r[0]||'').toLowerCase().replace(/[^a-z]/g,''),v=String(r&&r[1]||'').trim();if(['subject','subjectname','name'].includes(k))info.subject=v;else if(k==='subtitle')info.subtitle=v;else if(['grouplabel','filterlabel'].includes(k))info.groupLabel=v;}
 const t=rowsToRaw(q.rows,info);if(t.err)throw new Error(t.err.join(' '));return{raw:t.raw,stem};}

/* ---------- Excel writing ---------- */
const crcT=(()=>{const t=new Uint32Array(256);for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;t[n]=c>>>0;}return t;})();
const crc32=u=>{let c=-1;for(let i=0;i<u.length;i++)c=crcT[(c^u[i])&255]^(c>>>8);return(~c)>>>0;};
function zipStore(files){
 const enc=new TextEncoder(),parts=[],cd=[];let off=0;
 for(const [name,txt] of files){const nb=enc.encode(name),d=enc.encode(txt),crc=crc32(d);
  const lh=new DataView(new ArrayBuffer(30));lh.setUint32(0,0x04034b50,true);lh.setUint16(4,20,true);lh.setUint16(6,0x0800,true);lh.setUint32(14,crc,true);lh.setUint32(18,d.length,true);lh.setUint32(22,d.length,true);lh.setUint16(26,nb.length,true);
  parts.push(new Uint8Array(lh.buffer),nb,d);
  const ch=new DataView(new ArrayBuffer(46));ch.setUint32(0,0x02014b50,true);ch.setUint16(4,20,true);ch.setUint16(6,20,true);ch.setUint16(8,0x0800,true);ch.setUint32(16,crc,true);ch.setUint32(20,d.length,true);ch.setUint32(24,d.length,true);ch.setUint16(28,nb.length,true);ch.setUint32(42,off,true);
  cd.push(new Uint8Array(ch.buffer),nb);off+=30+nb.length+d.length;}
 const cl=cd.reduce((n,x)=>n+x.length,0),en=new DataView(new ArrayBuffer(22));en.setUint32(0,0x06054b50,true);en.setUint16(8,files.length,true);en.setUint16(10,files.length,true);en.setUint32(12,cl,true);en.setUint32(16,off,true);
 return new Blob([...parts,...cd,new Uint8Array(en.buffer)],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});}
const xe=s=>String(s??'').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g,'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const colL=i=>{let s='';i++;while(i>0){const m=(i-1)%26;s=String.fromCharCode(65+m)+s;i=Math.floor((i-1)/26);}return s;};
const NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main',XH='<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
function sheetXml(sh){
 const rows=sh.rows.map((r,i)=>`<row r="${i+1}">`+r.map((v,j)=>v===''||v==null?'':`<c r="${colL(j)}${i+1}" t="inlineStr" s="${sh.header&&i===0?1:2}"><is><t xml:space="preserve">${xe(v)}</t></is></c>`).join('')+'</row>').join('');
 return`${XH}<worksheet xmlns="${NS}"><sheetViews><sheetView workbookViewId="0">${sh.header?'<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>':''}</sheetView></sheetViews>${sh.widths?'<cols>'+sh.widths.map((w,i)=>`<col min="${i+1}" max="${i+1}" width="${w}" customWidth="1"/>`).join('')+'</cols>':''}<sheetData>${rows}</sheetData></worksheet>`;}
function xlsxBlob(sheets){
 const R='http://schemas.openxmlformats.org/officeDocument/2006/relationships',n=sheets.length;
 const styles=`${XH}<styleSheet xmlns="${NS}"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF2F4FD8"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment vertical="center"/></xf><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
 const files=[['[Content_Types].xml',`${XH}<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheets.map((s,i)=>`<Override PartName="/xl/worksheets/sheet${i+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>`],
  ['_rels/.rels',`${XH}<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="${R}/officeDocument" Target="xl/workbook.xml"/></Relationships>`],
  ['xl/workbook.xml',`${XH}<workbook xmlns="${NS}" xmlns:r="${R}"><sheets>${sheets.map((s,i)=>`<sheet name="${xe(s.name)}" sheetId="${i+1}" r:id="rId${i+1}"/>`).join('')}</sheets></workbook>`],
  ['xl/_rels/workbook.xml.rels',`${XH}<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheets.map((s,i)=>`<Relationship Id="rId${i+1}" Type="${R}/worksheet" Target="worksheets/sheet${i+1}.xml"/>`).join('')}<Relationship Id="rId${n+1}" Type="${R}/styles" Target="styles.xml"/></Relationships>`],
  ['xl/styles.xml',styles],...sheets.map((s,i)=>[`xl/worksheets/sheet${i+1}.xml`,sheetXml(s)])];
 return zipStore(files);}
function dlBlob(blob,name){const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.append(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove();},1500);}
const QHEAD=['Chapter','Group','Question','Option A','Option B','Option C','Option D','Option E','Option F','Answer','Explanation','Exam','Question ID','Paper ID','Paper number','Paper total'],QW=[28,14,70,26,26,26,26,22,22,10,60,28,24];
function templateBlob(){
 const info=[['Subject','General Science'],['Subtitle','NCERT based · Class 6–10'],['Group label','Branch'],[''],['HOW TO USE THIS TEMPLATE'],['1. Keep the headings in row 1 of the “Questions” sheet. Add one row per question.'],['2. Chapter: type the chapter name. You may leave it blank on following rows of the same chapter.'],['3. Group (optional): e.g. Physics / Chemistry or Ancient / Medieval / Modern. It becomes an extra filter named “Group label” above.'],['4. Options: fill Option A–F (2 to 6 options). Leave unused option columns empty.'],['5. Answer: the correct letter, e.g. B. For several correct answers write A, C. Leave blank for an unscored question.'],['6. Explanation and Exam (e.g. UPSC CSE 2019) are optional. Separate several exams with ;'],['7. Change the Subject name above, save as .xlsx (or .csv) and import it from Subject ▸ Add subject. Re-importing the same subject name updates it and keeps student progress on unchanged questions.']];
 const q=[QHEAD,['Motion and Force','Physics','The SI unit of force is –','Joule','Newton','Watt','Pascal','','','B','Force is measured in newton (N).','UPSC CSE (Pre) 2019'],['','','Select all vector quantities.','Speed','Velocity','Displacement','Mass','','','B, C','Velocity and displacement have direction.',''],['Acids, Bases and Salts','Chemistry','Which of the following are acids?\n1. HCl\n2. NaOH\n3. H2SO4','1 and 2','2 only','1 and 3','1, 2 and 3','','','C','NaOH is a base.','SSC CGL 2021; UPSC CSE (Pre) 2018']];
 return xlsxBlob([{name:'Questions',rows:q,header:true,widths:QW},{name:'Info',rows:info,widths:[18,90]}]);}
async function exportSubject(s){
 await ensureData(s);const d=s.data,rows=[QHEAD];
 for(const q of d.questions){const o=q.options.map(x=>rfs(s,x.text));while(o.length<6)o.push('');rows.push([q.chapter,q.group||'',rfs(s,q.prompt),...o.slice(0,6),q.correct.map(x=>x.toUpperCase()).join(', '),rfs(s,q.explanation),q.examTags.map(t=>t.label).join(' ; '),q.id,q.paper?.id||'',q.paper?.no||'',q.paper?.total||'']);}
 dlBlob(xlsxBlob([{name:'Questions',rows,header:true,widths:QW},{name:'Info',rows:[['Subject',d.title||s.name],['Subtitle',d.subtitle||''],['Group label',d.groupLabel||'']],widths:[18,60]}]),slug(s.name)+'.xlsx');
 toast(`Exported ${d.questions.length} questions to Excel.`);}

/* ---------- import UI ---------- */
let pend=null;
function normalizeImport(raw){
 const err=[];if(!raw||typeof raw!=='object'||Array.isArray(raw))return{err:['The file must contain a JSON object or an Excel sheet with a heading row.']};
 const name=String(raw.subject||raw.name||'').trim()||'Imported subject';
 if(!Array.isArray(raw.questions)||!raw.questions.length)return{err:['No questions were found in the file.']};
 const chs=[],byNo=new Map(),byTitle=new Map(),explicit=Array.isArray(raw.chapters)&&raw.chapters.length>0;
 const fold=value=>String(value??'').trim().toLowerCase();
 function addCh(no,title,group){
  const c={no,title:String(title).trim(),group:String(group||'').trim()};
  chs.push(c);byNo.set(no,c);
  const key=fold(c.title);
  if(!byTitle.has(key))byTitle.set(key,[]);
  byTitle.get(key).push(c);
  return c;
 }
 (explicit?raw.chapters:[]).forEach((c,i)=>{const o=c&&typeof c==='object'?c:{title:c};addCh(+o.no||i+1,o.title||o.name||'Chapter '+(i+1),String(o.group||o.category||''));});
 const qs=[],cnt=new Map(),seen=new Set();
 const reservedIds=new Set(raw.questions.map(r=>String(r?.questionId||'').trim()).filter(Boolean));
 raw.questions.forEach((r,i)=>{const at=(r&&r._row?'Row '+r._row:'Question #'+(i+1))+': ';if(!r||typeof r!=='object'){err.push(at+'not an object.');return;}
  const text=String(r.question??r.prompt??'').trim();if(!text){err.push(at+'the Question cell is empty.');return;}
  let opts=r.options;if(!Array.isArray(opts)||opts.length<2||opts.length>6){err.push(at+'needs 2 to 6 options (found '+(Array.isArray(opts)?opts.length:0)+').');return;}
  opts=opts.map(o=>String(o&&typeof o==='object'?o.text??'':o??'').trim());if(opts.some(o=>!o)){err.push(at+'an option cell is empty between filled options.');return;}
  const keys='abcdef'.slice(0,opts.length).split('');let a=r.answer??r.correct;a=a==null||a===''?[]:Array.isArray(a)?a:String(a).split(/[\s,;&\/]+/);
  a=[...new Set(a.map(x=>String(x).trim().toLowerCase().replace(/[().]/g,'')).filter(Boolean))];if(a.some(x=>!keys.includes(x))){err.push(at+'Answer “'+(Array.isArray(r.answer)?r.answer.join(','):r.answer)+'” must be one of '+keys.map(k=>k.toUpperCase()).join(', ')+'.');return;}
  const cr=r.chapter,group=String(r.group||r.category||'').trim();
  let ch;
  if(typeof cr==='number'){
   ch=byNo.get(cr);
   if(!ch&&explicit){err.push(at+'chapter '+cr+' is not listed in "chapters".');return;}
   if(!ch)ch=addCh(cr,'Chapter '+cr,group);
  }else{
   const missing=cr==null||String(cr).trim()==='';
   const title=missing?'General':String(cr).trim();
   const candidates=byTitle.get(fold(title))||[];
   if(group){
    ch=candidates.find(c=>fold(c.group)===fold(group));
    if(!ch&&candidates.length===1&&!candidates[0].group)ch=candidates[0];
   }else if(candidates.length>1){
    err.push(at+'chapter "'+title+'" appears in multiple sections. Enter its Group.');return;
   }else ch=candidates[0];
   if(!ch&&!candidates.length)ch=missing?(group?undefined:chs[0]):byNo.get(+cr);
   if(!ch)ch=addCh(chs.reduce((max,c)=>Math.max(max,c.no),0)+1,title,group);
  }
  if(group&&!ch.group)ch.group=group;
  const n=(cnt.get(ch.no)||0)+1;cnt.set(ch.no,n);const given=String(r.questionId||'').trim();
  if(given&&(!/^[A-Za-z0-9_-]{1,120}$/.test(given)||seen.has(given))){err.push(at+'invalid or duplicate Question ID.');return;}
  const base='U'+h32(ch.title+'|'+text);let id=given||base,dd=0;
  if(!given)while(seen.has(id)||reservedIds.has(id))id=base+'_'+(++dd);
  seen.add(id);
  const ex=Array.isArray(r.exams)?r.exams:r.exams?[r.exams]:[];
  qs.push({id,...(r.paper?{paper:r.paper}:{}),chapterNo:ch.no,chapter:ch.title,number:n,pdfPage:'',bookPage:r.page?String(r.page):'',prompt:text,options:opts.map((t,j)=>({key:keys[j],sourceLabel:keys[j],text:t})),correct:a,answerRaw:a.length?'Ans. ('+a.join(' & ')+')':'',type:a.length>1?'Multiple answer':'Multiple choice',explanation:String(r.explanation||''),examTags:ex.filter(Boolean).map(examTag),attemptable:true,gradeable:a.length>0,reviewFlags:[]});});
 if(!qs.length)return{err:err.length?err:['No valid questions were found.']};
 qs.sort((x,y)=>x.chapterNo-y.chapterNo);const used=new Set(qs.map(q=>q.chapterNo));
 const data={title:name,subtitle:String(raw.subtitle||''),groupLabel:String(raw.groupLabel||'').trim()||'Category',chapters:chs.filter(c=>used.has(c.no)).sort((x,y)=>x.no-y.no),questions:qs,source:String(raw.source||'Imported subject'),stats:{total:qs.length}};
 return{data,skipped:err,ungraded:qs.filter(q=>!q.gradeable).length};}
const showImp=l=>{$('impGo').disabled=true;pend=null;$('impNameWrap').hidden=true;$('impMsg').innerHTML=`<div class="note" style="margin:0"><b>Couldn’t import this file</b><br>${l.slice(0,8).map(esc).join('<br>')}${l.length>8?`<br>…and ${l.length-8} more`:''}</div>`;};
function openAdd(){if(!QM.isAdmin){toast('Only admins can add subjects.');return;}$('impMsg').innerHTML='';$('impGo').disabled=true;$('impNameWrap').hidden=true;pend=null;$('impFile').value='';renderMine();$('subjBackdrop').hidden=false;}
function renderMine(){
 $('mySubj').innerHTML='<h3>Your subjects</h3>'+SUBJECTS.map(s=>`<div class="mine"><span><b>${esc(s.name)}</b>${s.builtin?' <span class="chip">built-in</span>':''}</span><span class="mbtn"><button class="btn" type="button" data-ex="${s.id}">Export Excel</button>${s.builtin?'':`<button class="btn danger" type="button" data-rm="${s.id}">Remove</button>`}</span></div>`).join('');
 $('mySubj').querySelectorAll('[data-ex]').forEach(b=>b.addEventListener('click',async()=>{b.disabled=true;try{await exportSubject(SUBJECTS.find(x=>x.id===b.dataset.ex));}finally{b.disabled=false;}}));
 $('mySubj').querySelectorAll('[data-rm]').forEach(b=>b.addEventListener('click',async()=>{const s=SUBJECTS.find(x=>x.id===b.dataset.rm);if(!s||!await ask('Remove “'+s.name+'”?','The subject, its notes and saved progress are deleted. Past sessions stay in Performance.','Remove'))return;
  await kv.del('subj:'+s.id);await kv.del('qs:'+s.id);await kv.del('notes:'+s.id);await kv.del('nts:'+s.id);try{localStorage.removeItem('qm-state:'+s.id)}catch(e){}const cur=SUBJ.id===s.id;SUBJECTS.splice(SUBJECTS.indexOf(s),1);if(cur){sess={};await openSubject('polity',true);}buildSubjectSelect();renderMine();}));}
$('tplBtn').addEventListener('click',()=>{dlBlob(templateBlob(),'quizmaster-subject-template.xlsx');toast('Template downloaded — open it in Excel, Numbers or Google Sheets.');});
$('impFile').addEventListener('change',async e=>{
 const f=e.target.files[0];if(!f)return;$('impMsg').innerHTML='<div class="note" style="margin:0">Reading file…</div>';
 try{const{raw,stem}=await readFileToRaw(f);raw.subject=String(raw.subject||raw.name||'').trim()||stem.replace(/[_-]+/g,' ');
  const r=normalizeImport(raw);if(r.err){showImp(r.err);return;}pend=r;const d=r.data,gs=new Set(d.chapters.map(c=>c.group).filter(Boolean)).size;
  $('impName').value=raw.subject;$('impNameWrap').hidden=false;
  $('impMsg').innerHTML=`<div class="note" style="margin:0;background:var(--ok-bg);color:var(--ok);border-color:var(--ok-line)"><b>${d.questions.length} questions</b> in ${d.chapters.length} chapters${gs?` · ${gs} groups (“${esc(d.groupLabel)}” filter)`:''}${r.ungraded?` · ${r.ungraded} without an answer (unscored)`:''}. Ready to import.</div>`+(r.skipped.length?`<div class="note" style="margin:8px 0 0"><b>${r.skipped.length} row${r.skipped.length>1?'s':''} will be skipped</b><br>${r.skipped.slice(0,6).map(esc).join('<br>')}${r.skipped.length>6?`<br>…and ${r.skipped.length-6} more`:''}</div>`:'');
  $('impGo').disabled=false;}catch(x){showImp([x.message||String(x)]);}});
$('impGo').addEventListener('click',async()=>{
 if(!pend)return;const d=pend.data;d.title=($('impName').value.trim()||d.title).slice(0,60);let id=slug(d.title);if(['polity','history'].includes(id))id+='-2';
 const old=SUBJECTS.find(s=>s.id===id);if(old&&!await ask('Update “'+old.name+'”?','A subject with this name exists. Its questions are replaced by the new file; student progress and notes are kept for questions whose text is unchanged.','Update'))return;
 await kv.set('subj:'+id,d);const s={id,name:d.title,builtin:false,data:d,sourceHtml:'<b>Source:</b> '+esc(d.source)+'. Imported on this device.'};
 if(old)SUBJECTS[SUBJECTS.indexOf(old)]=s;else SUBJECTS.push(s);
 $('subjBackdrop').hidden=true;buildSubjectSelect();await openSubject(id);toast('“'+d.title+'” saved — '+d.questions.length+' questions.');});
$('closeSubj').addEventListener('click',()=>$('subjBackdrop').hidden=true);
$('subjBackdrop').addEventListener('click',e=>{if(e.target===$('subjBackdrop'))$('subjBackdrop').hidden=true;});

/* ---------- mock tests ---------- */
$('hostBtn').addEventListener('click',()=>{who='host';openCustom();});$('joinBtn').addEventListener('click',()=>{who='join';openCustom();});
$('mkCancel').addEventListener('click',()=>{cancelRoomOpening();$('mockBackdrop').hidden=true;});
/* ---------- performance extras: goal, streak, charts, backup ---------- */
function streak(){let n=0,t=Date.now();if(!DAILY[dayKey(t)])t-=864e5;while(DAILY[dayKey(t)]>0){n++;t-=864e5;}return n;}
function extraHTML(rows){
 const today=DAILY[dayKey()]||0,goal=PREFS.goal||30,p=Math.min(1,today/goal),C=2*Math.PI*26,due=refreshViewCounts().due;
 const goalCard=`<div class="card pgoal"><svg width="64" height="64" viewBox="0 0 64 64"><circle cx="32" cy="32" r="26" fill="none" stroke="var(--line)" stroke-width="7"/><circle cx="32" cy="32" r="26" fill="none" stroke="var(--brand)" stroke-width="7" stroke-linecap="round" stroke-dasharray="${C}" stroke-dashoffset="${C*(1-p)}" transform="rotate(-90 32 32)"/><text x="32" y="37" text-anchor="middle" font-size="14" font-weight="800" fill="var(--ink)">${Math.round(p*100)}%</text></svg>
  <div class="gt"><b>Today: ${today} / ${goal} questions</b><p>${streak()?`🔥 ${streak()}-day streak`:'Answer a question to start a streak'} · ${due} due for revision in ${esc(SUBJ.name)}</p></div>
  <label class="sel" style="flex:0 0 130px"><span>Daily goal</span><select id="goalSel">${[10,20,30,50,75,100,150].map(g=>`<option ${g===goal?'selected':''}>${g}</option>`).join('')}</select></label>
  <button class="btn primary" id="reviseGo" type="button">Revise now</button></div>`;
 const days=[...Array(14)].map((_,i)=>{const t=Date.now()-(13-i)*864e5;return{k:dayKey(t),v:DAILY[dayKey(t)]||0,d:new Date(t).getDate()};}),mx=Math.max(goal,...days.map(d=>d.v),1);
 const bars=days.map((d,i)=>{const h=Math.round(d.v/mx*70);return`<rect x="${i*24+4}" y="${78-h}" width="16" height="${Math.max(h,d.v?2:0)}" rx="4" style="fill:${d.v>=goal?'var(--ok)':'var(--brand)'}"><title>${d.k}: ${d.v}</title></rect><text x="${i*24+12}" y="94" text-anchor="middle" font-size="9" style="fill:var(--muted)">${d.d}</text>`;}).join('');
 const fin=rows.filter(r=>r.c+r.w>0).sort((a,b)=>a.st-b.st).slice(-20),pts=fin.map((r,i)=>[fin.length>1?i/(fin.length-1)*320+10:170,86-accOf(r)/100*76,accOf(r)]);
 const line=pts.length>1?`<polyline fill="none" style="stroke:var(--brand)" stroke-width="2.5" points="${pts.map(p=>p[0]+','+p[1]).join(' ')}"/>`+pts.map(p=>`<circle cx="${p[0]}" cy="${p[1]}" r="3.5" style="fill:var(--brand)"><title>${p[2]}%</title></circle>`).join('')+'<text x="2" y="14" font-size="9" style="fill:var(--muted)">100%</text><text x="2" y="88" font-size="9" style="fill:var(--muted)">0%</text>':'<text x="170" y="52" text-anchor="middle" font-size="12" style="fill:var(--muted)">Finish two sessions to see a trend</text>';
 return goalCard+`<div class="pcharts"><div class="card"><h3>Questions per day · last 14 days</h3><svg viewBox="0 0 340 100">${bars}</svg></div><div class="card"><h3>Accuracy trend · last ${fin.length||20} sessions</h3><svg viewBox="0 0 340 100">${line}</svg></div></div>`;}
function renderExtra(rows){
 $('pExtra').innerHTML=extraHTML(rows);
 $('goalSel').addEventListener('change',e=>{PREFS.goal=+e.target.value;persistSoon();renderPerf();});
 $('reviseGo').addEventListener('click',()=>$('reviseBtn').click());
 const lb=+store.get('qm-lastbackup')||0;$('bkNote').textContent=lb?`Last backup: ${Math.max(0,Math.floor((Date.now()-lb)/864e5))} day(s) ago.`:'No backup yet — export one so your progress survives a cleared browser.';}
$('bkExport').replaceWith($('bkExport').cloneNode(true));
$('bkExport').addEventListener('click',async()=>{
 logSession(submitted?'submitted':'in-progress');saveNow();flushPersist();const st={};stateKeys().forEach(k=>st[k]=localStorage.getItem(k));
 const subs={};SUBJECTS.filter(s=>!s.builtin&&s.data).forEach(s=>subs[s.id]=s.data);const kvs={};
 for(const k of [...await kv.keys('qs:'),...await kv.keys('notes:'),...await kv.keys('bookmark:'),'daily','prefs']){const v=await kv.get(k);if(v)kvs[k]=v;}
 dlBlob(new Blob([JSON.stringify({qmBackup:2,state:st,sessions:SESS,subjects:subs,kvs})],{type:'application/json'}),`quizmaster-backup-${dayKey()}.json`);store.set('qm-lastbackup',String(Date.now()));renderPerf();toast('Backup file created.');});


/* ===== v4: custom sessions (multi-chapter) + live test rooms ===== */
const REV=20;
const L=()=>LIVE&&LIVE.ph!=='over'?LIVE:null;
const myName=()=>($('mkName').value.trim()||store.get('qm-name')||'Player').slice(0,16);
const shufA=a=>{for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;};
const lab=(q,s)=>s.map(k=>((q.options.find(o=>o.key===k)||{}).sourceLabel||'?')).join(',').toUpperCase();
let who='host',cmode='practice';
const routeDialog=$('routeDialog');
function signedIn(){
 if(QM.user)return true;
 if(!QM.enabled){toast('Sign-in is unavailable. Check your connection and site configuration.');return false;}
 if(confirm('Sign in with Google to start or join a test?'))QM.signIn().catch(()=>toast('Sign-in could not start. Please try again.'));
 return false;
}
function chooseRoute(live=false){
 if(!signedIn())return;
 $('routeTitle').textContent=live?'Live test':'Start test';
 $('routeA').textContent=live?'Host a room':'Solo';
 $('routeB').textContent=live?'Join a room':'Live';
 const configure=(role,solo)=>{
  routeDialog.close();who=role;cmode=mode;$('mkAlone').checked=solo;openCustom();
 };
 $('routeA').onclick=()=>configure('host',!live);
 $('routeB').onclick=()=>live?configure('join',false):chooseRoute(true);
 if(!routeDialog.open)routeDialog.showModal();
}
$('startPortal').onclick=()=>{if(DATA&&!L())chooseRoute();};
$('routeClose').onclick=()=>routeDialog.close();
function openCustom(){
 $('mkName').value=store.get('qm-name')||'';setWho(who);document.body.classList.remove('fopen');$('mockBackdrop').hidden=false;updAvail();}
function poolOf(){
 const src=$('mkSrc').value,now=Date.now(),sel=new Set([...$('mkChs').querySelectorAll('input:checked')].map(i=>+i.value));
 return{sel,pool:DATA.questions.filter(q=>{if(!setupMatch(q,sel.size>0)||!(q.gradeable&&q.attemptable&&q.options.length)||(sel.size&&!sel.has(q.chapterNo)))return false;const s=QS[progressStorageKey(q.id)];
  return src==='all'||(src==='new'?!s:src==='due'?s&&s.d<=now:src==='wrong'?s&&s.w:s&&s.a&&s.c/s.a<.6);})};}
function updAvail(){const{sel,pool}=poolOf();$('mkAvail').textContent=`${pool.length} questions available from ${sel.size||'all'} chapter${sel.size===1?'':'s'}.`;}
function buildIds(){
 const n=+$('mkN').value,{sel,pool}=poolOf();if(!pool.length){toast('No questions match that selection.');return null;}
 let ids;
 if($('mkBal').checked){const g=[...new Set(pool.map(q=>q.chapterNo))].map(no=>shufA(pool.filter(q=>q.chapterNo===no))).filter(a=>a.length);ids=[];while(ids.length<n&&g.some(a=>a.length))for(const a of g)if(a.length&&ids.length<n)ids.push(a.pop());}
 else ids=shufA(pool.slice()).slice(0,n);
 if(!$('mkShuf').checked){const ix=new Map(DATA.questions.map((q,i)=>[q.id,i]));ids.sort((a,b)=>ix.get(a.id)-ix.get(b.id));}
 return ids.map(q=>q.id);}
function setWho(w){who=w;document.querySelectorAll('#mkWho button').forEach(b=>b.classList.toggle('on',b.dataset.w===w));document.querySelectorAll('#mkModeSeg button').forEach(b=>b.classList.toggle('on',b.dataset.m===cmode));
 $('mkJoin').hidden=w!=='join';$('mkCfg').hidden=w==='join';$('mkModeSeg').hidden=w==='join';$('mkNameW').hidden=w==='host'&&$('mkAlone').checked;
 const al=w==='host'&&$('mkAlone').checked;$('qsecSetting').hidden=w==='join'||(al&&cmode!=='practice');document.querySelectorAll('.solo-only').forEach(x=>x.hidden=!al);document.querySelectorAll('.host-only').forEach(x=>x.hidden=!(w==='host'&&!al));$('mkAloneW').hidden=w!=='host';
 $('mkGo').textContent=w==='join'?'Join room':$('mkAlone').checked?'Start session':'Create room';$('mkT0').textContent=w==='join'?'Join a test':$('mkAlone').checked?'Solo test':'Host a test';}
$('mkAlone').addEventListener('change',()=>setWho(who));
$('mkWho').addEventListener('click',e=>{const b=e.target.closest('[data-w]');if(b)setWho(b.dataset.w);});
$('mkModeSeg').addEventListener('click',e=>{const b=e.target.closest('[data-m]');if(b){cmode=b.dataset.m;setWho(who);}});
function updateChapters(){chosenChapters.clear();for(const box of $('mkChs').querySelectorAll('input:checked'))chosenChapters.add(+box.value);userFilter();updAvail();}
$('mkChs').addEventListener('change',updateChapters);$('mkSrc').addEventListener('change',updAvail);
$('mkAll').addEventListener('click',()=>{$('mkChs').querySelectorAll('input').forEach(i=>i.checked=true);updateChapters();});$('mkNone').addEventListener('click',()=>{$('mkChs').querySelectorAll('input').forEach(i=>i.checked=false);updateChapters();});
$('mkCancel').addEventListener('click',()=>$('mockBackdrop').hidden=true);
function setOrder(ids){order=ids.map(id=>byId.get(id));shuffled=true;current=0;selected=null;render();}
$('mkGo').addEventListener('click',async()=>{
 if(!signedIn())return;
 if(who==='join')return joinRoom();
 const ids=buildIds();if(!ids)return;
 const marks=Number($('mkMarks').value);if(!Number.isFinite(marks)||marks<=0||!$('mkMarks').checkValidity()){toast('Enter a positive mark per correct answer.');return;}
 if(!$('mkNeg').value||!$('mkNeg').checkValidity()){toast('Enter a deduction of zero or more.');return;}
 const cfg={marks,subj:SUBJ.id,ids,mode:cmode,neg:+$('mkNeg').value,qsec:+$('mkQS').value,n:ids.length};
 if(who==='host'&&!$('mkAlone').checked)return hostRoom(cfg);
 const lim=+$('mkT').value*60;
 if(answers.size&&!await ask('Start this session?','Your current attempt in this subject will be ended (it stays in Performance).','Start'))return;
 startSoloSession(ids,cmode,cfg,lim);
});
function startSoloSession(ids,testMode,cfg,lim){
 logSession(submitted?'submitted':'ended');stopClock();answers.clear();spent.clear();submitted=false;elapsed=0;FORCE.clear();mode=testMode;
 retryIds=new Set(ids);sess={account:QM.user.id,id:uid(),st:Date.now(),qsec:testMode==='practice'?cfg.qsec:0,eb:0,lim,marks:cfg.marks||1,neg:cfg.neg,mock:1,ids};
 $('mockBackdrop').hidden=true;$('summaryBackdrop').hidden=true;$('testSubmit').textContent='Submit';setTab('quiz');applyFilters();setOrder(ids);setPaused(false);paint();
 toast(`${ids.length} questions · ${testMode}${lim?' · '+lim/60+' min':''}`);}

/* --- live rooms --- */
const names=()=>[...LIVE.roster];
const cast=m=>LIVE.peer.bc(m);
async function loadRoomClient(){
 if(!QM.enabled)throw new Error('Live rooms need a configured Supabase project.');
 let timer;
 try{
  await Promise.race([QM.load(),new Promise((_,reject)=>{
   timer=setTimeout(()=>reject(new Error('Connection timed out. Please try again.')),8000);
  })]);
 }finally{clearTimeout(timer);}
}
const mkShow=H=>()=>H.ph==='live'||H.ph==='reveal'?(H.pz?'⏸ ':'')+mmss(Math.max(0,Math.ceil((H.pz?H.pr:H.end-Date.now())/1000))):'--:--';
function liveTick(){if(!LIVE)return;if(LIVE.host)hostTick();paint();const c=$('lcd');if(c&&LIVE.show)c.textContent=LIVE.show();}
let roomOpening=null;
function beginRoomOpening(label){
 if(roomOpening||L())return null;
 if(LIVE?.ph==='over')liveLeave();
 const opening={cancelled:false};
 roomOpening=opening;
 $('mkGo').disabled=true;
 $('mkGo').textContent=label;
 return opening;
}
function finishRoomOpening(opening){
 if(roomOpening!==opening)return;
 roomOpening=null;
 $('mkGo').disabled=false;
 setWho(who);
}
function cancelRoomOpening(){
 ++joinLookupVersion;
 const opening=roomOpening;
 if(!opening)return;
 opening.cancelled=true;
 if(LIVE?.opening===opening)liveLeave();
 else{
  opening.peer?.destroy();
  finishRoomOpening(opening);
 }
}
async function roomKey(){
 const getKey=()=>{
  let key=localStorage.getItem('qm-room-device');
  if(!key){key=crypto.randomUUID();localStorage.setItem('qm-room-device',key);}
  return key;
 };
 return navigator.locks? navigator.locks.request('qm-room-device',getKey) : getKey();
}
function wireLink(H){
 H.peer.onFailure=e=>{if(LIVE===H){toast(e.message);liveLeave(false);}};
 H.peer.onNetwork=()=>{if(LIVE===H&&!H.networkLost){H.networkLost=true;toast('Connection interrupted. Retrying…');}};
 H.peer.onConnected=()=>{if(H.networkLost&&LIVE===H){H.networkLost=false;toast('Connection restored.');}};
 H.show=mkShow(H);H.iv=setInterval(liveTick,250);
}
async function openHost(cfg,saved){
 if(!signedIn())return;
 const opening=beginRoomOpening(saved?'Restoring room…':'Opening room…');
 if(!opening)return;
 const previous=localStorage.getItem('qm-room');
 let peer,H;
 try{
  await loadRoomClient();
  const key=saved?.ownerKey||crypto.randomUUID();
  const alphabet='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code;
  for(let tries=0;tries<3;tries++){
   if(opening.cancelled)return;
   code=saved?.code||Array.from(crypto.getRandomValues(new Uint8Array(5)),x=>alphabet[x%32]).join('');
   peer=opening.peer=new LiveRoomLink(code,key,true);
   try{await peer.open(saved?'restore':'create',false,{cfg,name:myName(),ph:'lobby',i:-1});break;}
   catch(error){
    peer.destroy();
    if(saved||error.reason!=='unavailable'||tries===2)throw error;
   }
  }
  if(opening.cancelled){
   if(!saved)await peer.rpc('close').catch(()=>{});
   return;
  }
  const name=saved?.name||myName();
  if(!saved)store.set('qm-name',name);
  H=LIVE={
   host:true,peer,opening,code,cfg,name,ownerKey:key,attemptId:saved?.attemptId||'live-'+crypto.randomUUID(),
   ph:'lobby',moderating:new Set(),members:new Map(saved?.members||[]),roster:new Set(saved?.roster||[name]),off:new Set(),
   picks:new Map((saved?.picks||[]).map(([q,m])=>[q,new Map(m)])),presenceReady:false,
   i:saved?.i??-1,end:0,ci:-1,last:'',pz:saved?.pz,pr:saved?.rem
  };
  wireLink(H);syncExitGuard();
  if(saved&&Number.isSafeInteger(saved.cursor))peer.cursor=saved.cursor;
  peer.onCheckpoint=()=>{if(LIVE===H&&H.ph!=='over')saveHost();};
  peer.onMessage=(connection,message)=>{if(LIVE===H)hostMsg(connection,message);};
  peer.onMembers=members=>{if(LIVE===H&&H.ph!=='over')reconcileRoster(H,members);};
  if(saved&&saved.ph!=='lobby'){
   await liveBegin(cfg);
   if(LIVE!==H)return;
   restoreMine(mineOf(name));
   H.ph=saved.ph;H.end=(!saved.pz&&saved.deadline)||Date.now()+saved.rem;
   castPh();
   if(H.ph==='wait'&&H.i<0)nextQ();
  }else{saveHost();$('mockBackdrop').hidden=true;showRoom();}
  peer.start();
 }catch(error){
  peer?.destroy();
  if(H&&LIVE===H)liveLeave(false);
  if(saved&&error.reason==='unavailable'&&localStorage.getItem('qm-room')===previous){
   localStorage.removeItem('qm-room');localStorage.removeItem('qm-host');clearLiveAttempt();
  }
  if(!opening.cancelled)toast(error.message||'Could not open room.');
 }finally{finishRoomOpening(opening);}
}
const hostRoom=cfg=>openHost(cfg,null);
const hostRestore=s=>s.ownerKey?openHost(s.cfg,s):toast('This room used the previous site version. Create a new room.');
function restoreMine(mine){for(const qid in mine){const q=byId.get(qid);if(!q)continue;const sel=mine[qid];answers.set(qid,{selected:sel[0]||null,sel,grade:mode==='exam'?'pending':gradeOf(q,{sel})});}}
function lobbyCast(){const c=LIVE.cfg;cast({t:'lobby',players:names(),cfg:{mode:c.mode,qsec:c.qsec,neg:c.neg,n:c.n}});}
const mineOf=n=>{const o=Object.create(null);LIVE.picks.forEach((pm,q)=>{const v=pm.get(n);if(v)o[q]=v.sel;});return o;};
function hostMsg(c,m){const H=LIVE;if(!H||!m)return;
 if(m.t==='hi'){
  if(H.ph==='over'){c.send({t:'err',m:'This test has ended.'});return;}
  let name=H.members.get(c.member);
  if(!name){
   const base=String(m.name||'Player').trim().slice(0,16)||'Player';
   name=base;let suffix=2;const reserved=new Set([H.name,...H.members.values()]);
   while(reserved.has(name))name=base+suffix++;
   H.members.set(c.member,name);
  }
  H.roster.add(name);H.off.delete(name);
  saveHost();c.send({t:'me',name});
  if(H.ph==='lobby'){lobbyCast();showRoom();}
  else{c.send({t:'rj',cfg:H.cfg,mine:mineOf(name),ph:phMsg(),names:names()});publishRoster(H);}
 }else if(m.t==='a'&&H.roster.has(H.members.get(c.member))){
  // The database accepted this answer before the member refreshed their tab.
  recPick(H.members.get(c.member),m);
 }
}
function reconcileRoster(H,members){
 let changed=false;
 for(const member of members){
  const name=H.members.get(member.member);
  if(!name)continue;
  if(member.status==='active'){
   if(!H.roster.has(name)){H.roster.add(name);changed=true;}
   if(member.online)H.off.delete(name);else H.off.add(name);
  }else if(member.status==='left'&&H.ph!=='lobby'){
   H.off.add(name);
  }else{
   changed=H.roster.delete(name)||changed;
   H.off.delete(name);
  }
 }
 H.presenceReady=true;
 if(changed)publishRoster(H);else if(H.ph==='live'||H.ph==='reveal')liveUI();
}
function publishRoster(H){
 saveHost();
 if(H.ph==='lobby'){lobbyCast();showRoom();}
 else{cast({t:'roster',players:names()});liveUI();}
}
function memberName(H,n){
 if(!H.host||n===H.name)return esc(n);
 return '<button class="memberName" type="button" aria-expanded="'+(H.selectedMember===n)+'">'+esc(n)+'</button>';
}
document.addEventListener('click',e=>{
 const button=e.target.closest('.memberName'),H=LIVE;
 if(!button||!H?.host)return;
 const name=button.textContent;H.selectedMember=H.selectedMember===name?null:name;
 if(H.ph==='lobby')showRoom();else liveUI();
});
function moderationControls(H,n){
 if(!H.host||n===H.name||H.ph==='over')return '';
 const entry=[...H.members].find(([,name])=>name===n);
 if(!entry)return '';
 const id=esc(entry[0]),label=esc(n);
 return '<span class="room-member-actions" '+(H.selectedMember===n?'':'hidden')+'><button type="button" class="btn" aria-label="Kick '+label+'" data-room-action="kick" data-member="'+id+'">Kick</button><button type="button" class="btn" aria-label="Block '+label+'" data-room-action="block" data-member="'+id+'">Block</button></span>';
}
document.addEventListener('click',async e=>{
 const button=e.target.closest('[data-room-action]'),H=LIVE;if(!button||!H?.host)return;
 const {member,roomAction}=button.dataset,name=H.members.get(member);
 if(!name||H.moderating.has(member)||!['kick','block'].includes(roomAction))return;
 if(!await ask(roomAction==='kick'?'Remove '+name+'?':'Block '+name+'?',roomAction==='kick'?'They can join again.':'They will not be able to rejoin this room.',roomAction==='kick'?'Remove':'Block'))return;
 H.moderating.add(member);button.disabled=true;
 try{
  await H.peer.moderate(roomAction,member);if(LIVE!==H)return;
  H.roster.delete(name);H.off.delete(name);publishRoster(H);
  toast(name+(roomAction==='kick'?' was removed.':' was blocked from this room.'));
 }catch(err){toast(err.message);button.disabled=false;}finally{H.moderating.delete(member);}
});
function recPick(name,m){const H=LIVE;if(!H||H.ph!=='live'||H.pz||H.cfg.ids[H.i]!==m.qid||!Array.isArray(m.sel))return;
 let pm=H.picks.get(m.qid);if(!pm)H.picks.set(m.qid,pm=new Map());const o=pm.get(name);pm.set(name,{sel:m.sel,ms:o?o.ms:(+m.ms||0)});castPh();}
const allIn=()=>{const H=LIVE,pm=H.picks.get(H.cfg.ids[H.i]);return H.presenceReady&&!!pm&&names().every(n=>pm.has(n));};
function hostTick(){const H=LIVE;if(!H||H.ph==='over'||H.pz)return;const now=Date.now();
 if(H.ph==='live'){if(now>=H.end||allIn())toReveal();}else if(H.ph==='reveal'&&now>=H.end)nextQ();}
function toReveal(){if(LIVE.cfg.mode==='exam')return nextQ();LIVE.ph='reveal';LIVE.end=Date.now()+REV*1000;castPh();}
function nextQ(){const H=LIVE;if(!H||!H.host||H.ph==='over'||H.ph==='lobby')return;H.i++;if(H.i>=H.cfg.ids.length)return finish();H.ph='live';H.end=Date.now()+H.cfg.qsec*1000;castPh();}
function hostWatch(H){return Math.max(0,(H.cfg.watchPausedAt||Date.now())-(H.cfg.watchStart||Date.now()));}
function phMsg(){const H=LIVE,pm=H.picks.get(H.cfg.ids[H.i]),pk=Object.create(null);if(pm)pm.forEach((v,n)=>{if(H.roster.has(n))pk[n]=H.cfg.mode==='practice'&&H.ph==='reveal'?v.sel:[];});return{t:'ph',watchMs:hostWatch(H),i:H.i,ph:H.ph,rem:H.pz?H.pr:H.end-Date.now(),pz:H.pz?1:0,picks:pk};}
function castPh(){const m=phMsg();cast(m);onPh(m);saveHost();}
async function queueCheckpoint(H,snapshot){
 H.pendingSnapshot=snapshot;if(H.saving)return;H.saving=true;
 try{while(H.pendingSnapshot&&LIVE===H){
  const next=H.pendingSnapshot;H.pendingSnapshot=null;
  try{await H.peer.rpc('checkpoint',next);}catch(e){if(!e.reason&&LIVE===H){H.pendingSnapshot=H.pendingSnapshot||next;await new Promise(r=>setTimeout(r,1500));}else break;}
 }}finally{H.saving=false;}
}
async function findHost(code){
 if(!QM.user)return null;
 const local=JSON.parse(localStorage.getItem('qm-host')||'null');
 const matching=local?.ownerKey&&(!local.account||local.account===QM.user.id)&&(!code||local.code===code);
 const controller=new AbortController();
 const timeout=setTimeout(()=>controller.abort(),4000);
 let result;
 try{result=await QM.client().rpc('qm_host_room',{room_code:code||null}).abortSignal(controller.signal);}
 finally{clearTimeout(timeout);}
 const {data,error}=result;
 if(error&&matching)return local;
 if(error)throw new Error('Could not check your hosted room. Check your connection and the live-room SQL update.');
 return matching&&(!data||data.session===local.session&&local.cursor>=data.cursor)?local:data;
}
function saveHost(){const H=LIVE;const snapshot={account:QM.user?.id,code:H.code,cursor:H.peer.cursor,session:H.peer.session,ownerKey:H.ownerKey,attemptId:H.attemptId,members:[...H.members],cfg:H.cfg,name:H.name,i:H.i,ph:H.ph,deadline:H.end,rem:H.pz?H.pr:Math.max(0,H.end-Date.now()),pz:H.pz?1:0,roster:[...H.roster],picks:[...H.picks].map(([q,m])=>[q,[...m]])};queueCheckpoint(H,snapshot);try{localStorage.setItem('qm-host',JSON.stringify(snapshot));localStorage.setItem('qm-room',JSON.stringify({role:'h',code:H.code,session:H.peer.session,t:Date.now()}));}catch(e){}}
function onPh(m){const H=LIVE;if(!H||!H.cfg?.ids||!byId.has(H.cfg.ids[m.i]))return;const first=H.ci!==m.i;
 const redraw=first||H.displayPhase!==m.ph||current!==m.i;H.displayPhase=m.ph;
 if(first&&m.ph==='live'){H.qs=Date.now()-(H.cfg.qsec*1000-m.rem);H.last='';}
 H.watchMs=m.watchMs??H.watchMs??0;H.watchAnchor=Date.now();H.ci=m.i;H.ph=m.ph;H.end=Date.now()+m.rem;H.cpicks=m.picks;H.pz=m.pz;H.pr=m.rem;
 if(m.ph==='reveal'&&H.cfg.mode==='practice'){const qq=H.cfg.ids[m.i],a=answers.get(qq);if(!a)FORCE.add(qq);else if(a.grade==='pending'){const g=gradeOf(byId.get(qq),a);answers.set(qq,{...a,grade:g});recordResult(byId.get(qq),g);}}
 if(current!==m.i){current=m.i;selected=null;scrollTo({top:0});}
 if(redraw)render();else{liveUI();syncBar(currentQ());paint();}}
function finish(){const H=LIVE,ids=H.cfg.ids,neg=H.cfg.neg||0,rows=[],pk={};
 ids.forEach(id=>{pk[id]=Object.create(null);const pm=H.picks.get(id);if(pm)pm.forEach((v,n)=>{if(H.roster.has(n))pk[id][n]=v.sel;});});
 names().forEach(n=>{let c=0,w=0,t=0,att=0;ids.forEach(id=>{const v=H.picks.get(id)&&H.picks.get(id).get(n);if(!v)return;att++;t+=v.ms||0;const g=gradeOf(byId.get(id),{sel:v.sel});if(g==='correct')c++;else if(g==='wrong')w++;});rows.push({n,c,w,u:ids.length-att,t,s:Math.round((c*(H.cfg.marks||1)-w*neg)*100)/100});});
 rows.sort((a,b)=>b.s-a.s||a.t-b.t);const res={rows,ids,pk,neg};cast({t:'end',res});liveEnd(res);}
function liveEnd(res){const H=LIVE;if(!H)return;try{const saved=JSON.parse(localStorage.getItem('qm-room')||'null');if(saved?.session===H.peer.session){localStorage.removeItem('qm-room');if(H.host)localStorage.removeItem('qm-host');}}catch(e){}H.res=res;H.ph='over';clearInterval(H.iv);H.peer.outbox.finally(()=>H.peer.destroy());gradePending();submitted=true;setPaused(false);stopClock();logSession('submitted');$('testSubmit').textContent='Summary';render();paint();showLB();}
function showLB(){const r=LIVE.res,t=r.rows[0];
 $('lbBody').innerHTML=`<p class="weak" style="background:var(--ok-bg);color:var(--ok);border-color:var(--ok-line)">🏆 ${esc(t.n)} wins with ${t.s} point${t.s===1?'':'s'}</p><div style="overflow-x:auto"><table class="lbt"><tr><th>#</th><th>Player</th><th>Score</th><th>Correct</th><th>Wrong</th><th>Skipped</th><th>Avg time</th></tr>${r.rows.map((x,i)=>`<tr><td>${i+1}</td><td><b>${esc(x.n)}</b>${x.n===LIVE.name?' (you)':''}</td><td><b>${x.s}</b></td><td>${x.c}</td><td>${x.w}</td><td>${x.u}</td><td>${x.c+x.w?mmss(Math.round(x.t/(x.c+x.w)/1000)):'–'}</td></tr>`).join('')}</table></div><h3>Responses by question</h3><div style="overflow:auto;max-height:300px"><table class="lbt"><tr><th>Q</th><th>Key</th>${r.rows.map(x=>`<th>${esc(x.n)}</th>`).join('')}</tr>${r.ids.map((id,i)=>{const q=byId.get(id);return`<tr><td>${i+1}</td><td>${keyStr(q)}</td>${r.rows.map(x=>{const s=Object.hasOwn(r.pk[id],x.n)?r.pk[id][x.n]:null;if(!s)return'<td>–</td>';const g=gradeOf(q,{sel:s})==='correct';return`<td style="color:var(--${g?'ok':'bad'});font-weight:700">${lab(q,s)} ${g?'✓':'✗'}</td>`;}).join('')}</tr>`;}).join('')}</table></div>`;
 const d=document.createElement('details');d.innerHTML='<summary>Anonymous responses by question</summary>';
 const select=document.createElement('select');select.setAttribute('aria-label','Question');
 r.ids.forEach((_,i)=>select.add(new Option('Question '+(i+1),i)));
 const chart=document.createElement('div');function draw(){const id=r.ids[select.selectedIndex],q=byId.get(id);
  chart.replaceChildren();const picks=Object.values(r.pk[id]||{});for(const o of q.options){
   const bar=document.createElement('progress');bar.max=picks.length||1;bar.value=picks.filter(list=>list.includes(o.key)).length;
   const row=document.createElement('div');row.append(o.sourceLabel.toUpperCase()+' ',bar,' '+bar.value);chart.append(row);
  }}
 select.onchange=draw;d.append(select,chart);$('lbBody').append(d);if(r.ids.length)draw();
 $('lbBackdrop').hidden=false;}
function showRoom(){const H=LIVE;if(!H||H.ph!=='lobby'){$('roomBackdrop').hidden=true;return;}const ns=H.host?names():(H.players||[]),c=H.cfg||{};
 $('roomBody').innerHTML=`<button type="button" class="rcode" id="copyCode">${esc(H.code)}</button><p style="margin:0;text-align:center">Friends tap Join room and enter this code.</p><p style="margin:8px 0 0;text-align:center;font-size:13px">${c.mode==='exam'?'Exam':'Practice'} · ${c.n||'?'} questions · ${c.qsec||'?'}s per question</p><h3>Players (${ns.length})</h3>`+ns.map((n,i)=>`<div class="mine"><span><b>${memberName(H,n)}</b>${i===0?' <span class="chip">host</span>':''}</span>${moderationControls(H,n)}</div>`).join('')+(H.host?'':'<p class="dnote">Waiting for the host to start…</p>');
 $('roomStart').hidden=!H.host;$('roomBackdrop').hidden=false;}
function clearLiveAttempt(){
 if(!sess.live||submitted)return;
 logSession('ended');stopClock();sess={};retryIds=null;elapsed=0;paused=false;
 document.body.classList.remove('paused');
 answers.clear();spent.clear();FORCE.clear();
 if(DATA)applyFilters();
}
function liveLeave(explicit=true){
 const H=LIVE;
 if(!H)return;
 LIVE=null;
 clearInterval(H.iv);clearTimeout(H.handshake);
 try{
  const saved=JSON.parse(localStorage.getItem('qm-room')||'null');
  if(saved?.session===H.peer.session){
   localStorage.removeItem('qm-room');
   if(H.host)localStorage.removeItem('qm-host');
  }
 }catch(e){}
 if(explicit&&H.ph!=='over'){
  H.peer.rpc(H.host?'close':'leave').catch(()=>{});
 }
 if(H.host&&H.ph==='over')H.peer.outbox.finally(()=>H.peer.destroy());
 else H.peer.destroy();
 $('roomBackdrop').hidden=true;$('lbBackdrop').hidden=true;
 if(H.ph!=='over')clearLiveAttempt();
 finishRoomOpening(H.opening);paint();if(DATA)render();
}
let findingHost=false,joinLookupVersion=0;
async function joinRoom(){
 const code=$('mkCode').value.trim().toUpperCase();if(!/^[A-Z0-9]{5}$/.test(code)){toast('Enter the five-character room code.');return;}
 if(!signedIn()||roomOpening||findingHost)return;
 const lookup=++joinLookupVersion;findingHost=true;$('mkGo').disabled=true;$('mkGo').textContent='Joining…';
 try{const saved=await findHost(code);if(lookup!==joinLookupVersion)return;if(saved)await hostRestore(saved);else{store.set('qm-name',myName());await startGuest(code,myName(),false);}}
 catch(e){toast(e.message);}finally{findingHost=false;if(!roomOpening){$('mkGo').disabled=false;setWho(who);}}
}
async function startGuest(code,name,auto){
 if(!signedIn())return;
 const opening=beginRoomOpening(auto?'Rejoining…':'Joining…');
 if(!opening)return;
 const previous=localStorage.getItem('qm-room');
 let peer,H;
 try{
  await loadRoomClient();
  const key=await roomKey();
  if(opening.cancelled)return;
  peer=opening.peer=new LiveRoomLink(code,key,false);
  await peer.open('join',!auto);
  if(opening.cancelled){await peer.rpc('leave').catch(()=>{});return;}
  H=LIVE={host:false,opening,peer,code,name,ph:'wait',players:[],cfg:null,ci:-1,last:'',attemptId:'live-'+peer.memberId};
  wireLink(H);syncExitGuard();
  H.conn={send:m=>peer.send(m)};
  H.pendingKey='qm-last-pick:'+peer.memberId;
  const hello=()=>peer.send({t:'hi',name:H.name});
  peer.onRestore=hello;
  peer.onMessage=(_,message)=>guestMsg(H,message);
  H.handshake=setTimeout(()=>{
   if(LIVE===H&&!H.admitted){
    toast('Host has not responded yet. Check the connection and try again.');
    liveLeave();
   }
  },25000);
  peer.start();hello();
 }catch(error){
  peer?.destroy();
  if(H&&LIVE===H)liveLeave(false);
  if(auto&&error.reason&&error.reason!=='superseded'&&localStorage.getItem('qm-room')===previous){
   localStorage.removeItem('qm-room');clearLiveAttempt();
  }
  if(!opening.cancelled)toast(error.message||'Could not join room.');
 }finally{
  if(!H||LIVE!==H)finishRoomOpening(opening);
 }
}
const rejoin=s=>startGuest(s.code,s.name,true);
async function guestMsg(H,m){
 if(LIVE!==H||!m)return;
 if(m.t==='err'){toast(m.m);liveLeave(false);return;}
 if(m.t==='me'){
  H.named=true;H.name=m.name;localStorage.setItem('qm-room',JSON.stringify({role:'g',code:H.code,session:H.peer.session,name:H.name,t:Date.now()}));return;
 }
 if(!H.named)return;
 if(m.t==='lobby'||m.t==='rj'){
  H.admitted=true;clearTimeout(H.handshake);finishRoomOpening(H.opening);$('mockBackdrop').hidden=true;
 }
 if(m.t==='lobby'){H.players=m.players;H.cfg=m.cfg;H.ph='lobby';showRoom();}
 else if(m.t==='roster'){H.players=m.players;if(DATA)liveUI();}
 else if(m.t==='start')await liveBegin(m.cfg);
 else if(m.t==='rj'){await liveBegin(m.cfg);if(LIVE!==H)return;restoreMine(m.mine||{});H.players=m.names||[];onPh(m.ph);
  const pending=JSON.parse(localStorage.getItem(H.pendingKey)||'null');
  if(pending&&m.ph.ph==='live'&&H.cfg.ids[m.ph.i]===pending.qid&&!m.mine?.[pending.qid]){
   restoreMine({[pending.qid]:pending.sel});H.conn.send(pending);render();
  }
  toast('Joined room '+H.code+'.');}
 else if(m.t==='ph'&&H.cfg?.ids)onPh(m);
 else if(m.t==='end'&&H.cfg?.ids)liveEnd(m.res);
}
async function liveBegin(cfg){
 const H=LIVE;if(!SUBJECTS.some(s=>s.id===cfg.subj)){toast('Subject unavailable. Reopen the room when the subject is available.');liveLeave(false);return;}
 if(SUBJ.id!==cfg.subj)await openSubject(cfg.subj);if(LIVE!==H)return;
 if(!cfg.ids.every(id=>byId.has(id))){toast('Your copy of this subject differs from the host’s. Import the same file.');liveLeave(false);return;}
 const sameAttempt=sess.id===H.attemptId;
 if(!sameAttempt)logSession(submitted?'submitted':'ended');
 const prior=SESS.find(entry=>entry.id===H.attemptId);
 const started=(sameAttempt&&sess.st)||prior?.st||Date.now();
 stopClock();answers.clear();
 if(!sameAttempt){spent.clear();elapsed=prior?.dur||0;}
 submitted=false;FORCE.clear();mode=cfg.mode;paused=false;document.body.classList.remove('paused');
 sess={account:QM.user.id,id:H.attemptId,st:started,eb:0,lim:0,marks:cfg.marks||1,neg:cfg.neg,mock:1,live:1,ids:cfg.ids};retryIds=new Set(cfg.ids);H.cfg=cfg;H.ph='wait';H.ci=-1;H.last='';
 ['roomBackdrop','mockBackdrop','summaryBackdrop'].forEach(i=>$(i).hidden=true);$('testSubmit').textContent='Submit';setTab('quiz');applyFilters();setOrder(cfg.ids);paint();}
$('roomStart').addEventListener('click',async()=>{const H=LIVE;if(!H||!H.host||H.ph!=='lobby')return;H.ph='wait';H.cfg.watchStart=Date.now();H.i=-1;saveHost();cast({t:'start',cfg:H.cfg});await liveBegin(H.cfg);setTimeout(()=>{if(LIVE===H)nextQ();},1800);});
$('roomLeave').addEventListener('click',()=>{if(confirm(LIVE?.host?'Close this room for everyone?':'Leave this room?'))liveLeave();});$('lbClose').addEventListener('click',()=>liveLeave());$('lbSum').addEventListener('click',showSummary);
function liveAns(){const H=L();if(!H||H.ph!=='live'||H.pz)return;const q=currentQ(),a=q&&answers.get(q.id);if(!a||(mode==='practice'&&a.grade==='pending'))return;
 const sel=selKeys(a),k=q.id+sel.join(',');if(H.last===k)return;H.last=k;const m={t:'a',qid:q.id,sel,ms:Date.now()-(H.qs||Date.now())};if(H.host)recPick(H.name,m);else{try{localStorage.setItem(H.pendingKey,JSON.stringify(m));}catch(e){}H.conn.send(m);}}
const _pick=pick;pick=function(k){const H=L();if(H&&(H.ph!=='live'||H.pz)){toast(H.pz?'Paused by the host.':H.ph==='reveal'?'Time is up for this question.':'Waiting for the first question…');return;}_pick(k);liveAns();};
const _cm=checkMulti;checkMulti=function(){_cm();liveAns();};
const _sb=syncBar;syncBar=function(q){_sb(q);const H=L();if(!H)return;['prevBtn','clearBtn'].forEach(i=>$(i).disabled=true);
 $('nextBtn').disabled=!(H.host&&!H.pz&&(H.ph==='live'||H.ph==='reveal'));if(H.host)$('nextBtn').classList.add('primary');
 const p=$('pauseBtn');p.disabled=!H.host;p.textContent=H.pz?'▶':'❚❚';p.title=H.host?(H.pz?'Resume for everyone':'Pause for everyone'):'Only the host can pause';};
const _sp=setPaused;setPaused=function(p){if(L())return;_sp(p);paint();};
$('pauseBtn').addEventListener('click',e=>{const H=L();if(!H)return;e.stopImmediatePropagation();if(H.host)hostPause();},true);
$('nextBtn').addEventListener('click',e=>{const H=L();if(!H)return;e.stopImmediatePropagation();if(H.host&&!H.pz){if(H.ph==='reveal')nextQ();else if(H.ph==='live')toReveal();}},true);
const _rn=render;render=function(){_rn();liveUI();paint();};
function liveUI(){const H=L(),q=currentQ(),box=$('roomBox');
 if(!H||!H.cfg||!H.cfg.ids||!q||H.ci<0){if(!box.hidden){box.hidden=true;roomLayout();}return;}
 const prac=H.cfg.mode==='practice',pk=H.cpicks||{},nm=H.host?names():H.players,done=nm.filter(n=>Object.hasOwn(pk,n)).length;
 const was=box.hidden;box.hidden=false;
 $('roomTitle').textContent='Room '+H.code;
 $('roomSub').innerHTML=done+'/'+nm.length+' answered'+(H.pz?' · paused':'')+(prac?'':'<span id="lcd">'+H.show()+'</span>');
 $('roomToggle').innerHTML='Room <b>'+esc(H.code)+'</b> '+done+'/'+nm.length;
 const rows=nm.map(n=>{const s=Object.hasOwn(pk,n)?pk[n]:null;let st;
  if(!s)st='<i class="rs">…</i>';
  else if(!prac||H.ph!=='reveal')st='<i class="rs on">✔</i>';
  else{const ok=gradeOf(q,{sel:s})==='correct';st='<i class="rs '+(ok?'ok':'no')+'">'+(esc(lab(q,s))||'–')+' '+(ok?'✓':'✗')+'</i>';}
  return'<div class="rm">'+st+'<span class="rn">'+memberName(H,n)+(n===H.name?' (you)':'')+(H.host&&H.off.has(n)?' <small>reconnecting</small>':'')+'</span>'+moderationControls(H,n)+'</div>';}).join('');
 const l=$('roomList'),sc=l.scrollTop;l.innerHTML=rows;l.scrollTop=sc;if(was)roomLayout();}
function hostDashboard(H,q,picks,members){
 const answered=members.filter(n=>Object.hasOwn(picks,n));
 const summary='<p data-room-count>'+answered.length+' / '+members.length+' answered</p>';
 if(H.ph!=='reveal'||H.cfg.mode!=='practice')return summary;
 const choices=q.options.map(o=>{const count=answered.filter(n=>picks[n].includes(o.key)).length;return '<div>'+esc(o.sourceLabel.toUpperCase())+' <progress max="'+Math.max(answered.length,1)+'" value="'+count+'"></progress> '+count+'</div>';});
 return summary+'<div class="responseChart" aria-label="Anonymous response totals">'+choices.join('')+'</div>';
}
function hostPause(){const H=LIVE;if(!H||!H.host)return;if(H.pz){if(H.cfg.watchPausedAt)H.cfg.watchStart+=Date.now()-H.cfg.watchPausedAt;delete H.cfg.watchPausedAt;H.pz=0;H.end=Date.now()+H.pr;}else{H.cfg.watchPausedAt=Date.now();H.pr=Math.max(0,H.end-Date.now());H.pz=1;}castPh();}

/* ===== v5: sync hooks · reports · shared banks ===== */
{const ks=kv.set.bind(kv);kv.set=async(k,v)=>{const r=await ks(k,v);QM.touch&&QM.touch(k);return r;};const ss=store.set;store.set=(k,v)=>{ss(k,v);if(/^(pq-state|qm-state)/.test(k)&&QM.dirty)QM.dirty();};}
const _rn3=render;render=function(){_rn3();{const nt=$('navToggle');if(nt)nt.innerHTML='Questions <b>'+(order.length?current+1:0)+'/'+order.length+'</b>';}const q=currentQ(),hd=card.querySelector('.qhead');if(q&&hd&&!$('rptBtn')){const b=document.createElement('button');b.id='rptBtn';b.type='button';b.className='btn flagbtn';b.textContent='🚩';b.title='Report a wrong answer or typo';b.setAttribute('aria-label','Report this question');b.onclick=()=>{$('rptBackdrop').hidden=false;};hd.append(b);}};
$('rptCancel').addEventListener('click',()=>$('rptBackdrop').hidden=true);
$('rptSend').addEventListener('click',async()=>{const q=currentQ();if(!q)return;const ok=await QM.report({subject_id:q.origin?.sid||SUBJ.id,subject_name:(q.origin&&SUBJECTS.find(s=>s.id===q.origin.sid)?.name)||SUBJ.name,qid:q.origin?.id||q.id,chapter:q.chapter,qno:q.chapterNo+'.'+q.number,prompt:String(q.prompt).slice(0,400),reason:$('rptReason').value,note:$('rptNote').value.trim().slice(0,500)});
 $('rptBackdrop').hidden=true;$('rptNote').value='';toast(ok?'Thanks — report sent to the mentor.':'Saved. It will be sent when you are signed in and online.');});
$('mySubj').addEventListener('click',async e=>{const b=e.target.closest('[data-sh]');if(!b)return;if(!QM.user){toast('Sign in on the home page to share a subject.');return;}
 const s=SUBJECTS.find(x=>x.id===b.dataset.sh);await ensureData(s);const slug=s.id+'-'+Math.random().toString(36).slice(2,6);
 const{error}=await QM.client().from('shared_subjects').insert({slug,title:s.name,data:s.data});if(error){toast('Could not share: '+error.message);return;}
 const u=new URL('index.html?bank='+slug,location.href).href;try{await navigator.clipboard.writeText(u);}catch(x){}toast('Share link copied: '+u);});
const _os=openSubject;openSubject=async function(...a){const r=await _os(...a);let ch=0;for(const id in NOTES)if(!NTS[id]){NTS[id]=nMeta(id);ch=1;}if(ch)persistSoon();return r;};
document.addEventListener('visibilitychange',()=>{if(document.hidden){try{flushPersist()}catch(e){}}});
function parseMatch(p){
 if(!p||!/List[\s-]*I\b/i.test(p))return null;
 const lines=String(p).replace(/\r/g,'').split('\n');const LR=/^\(?([A-Fa-f]|[P-Sp-s])[.)]\s*(.*)$/,RR=/^\(?(\d{1,2}|i{1,3}|iv|vi{0,3}|v)[.)]\s*(.*)$/i;
 const pre=[],L=[],R=[];let tgt=null,started=false,stop=false;
 for(const raw of lines){if(stop)break;const ln=raw.trim();if(!ln)continue;
  if(/^Codes?\s*[:–-]?\s*$|^Codes?\s*[:–-]/i.test(ln)&&started){stop=true;break}
  const parts=ln.split(/\t+/).map(s=>s.trim()).filter(Boolean);let hit=false;
  for(const part of parts){let m;
   if((m=part.match(LR))){L.push({k:m[1].toUpperCase(),t:m[2]});tgt=L;hit=true;started=true;}
   else if(started&&(m=part.match(RR))){R.push({k:m[1],t:m[2]});tgt=R;hit=true;}
   else if(started&&tgt){const a=tgt[tgt.length-1];a.t=(a.t+' '+part).trim();}
  }
  if(parts.length>1&&L.length&&R.length)tgt=L;
  if(!started)pre.push(ln);
 }
 if(L.length<3||R.length<3)return null;
 // header / intro / subheads
 let hi=pre.findIndex(l=>/^List[\s-]*I\b/i.test(l)&&!/\bwith\b|\bmatch\b/i.test(l));
 const intro=(hi<0?pre:pre.slice(0,hi)).join(' ').replace(/\s+/g,' ').trim();
 let subL='',subR='';
 if(hi>=0){const sub=pre.slice(hi+1).filter(l=>!/^List[\s-]*I{1,2}\s*$/i.test(l));const sg=[];
  for(const l of sub){const ps=l.split(/\t+/).map(s=>s.trim()).filter(Boolean);if(ps.length>=2){subL+=' '+ps[0];subR+=' '+ps[1]}else sg.push(l)}
  if(!subL&&!subR&&sg.length===2){subL=sg[0];subR=sg[1]}else if(!subL&&!subR&&sg.length)subL=sg.join(' ');
 }
 const tidy=a=>a.map(x=>({k:x.k,t:x.t.replace(/\s+/g,' ').trim()}));
 return{intro,subL:subL.trim(),subR:subR.trim(),L:tidy(L),R:tidy(R)};
}
function mapOpt(t,m){if(!m)return null;const s=String(t||'');const pr=[...s.matchAll(/([A-F]|[P-S])\s*[-–→:]?\s*\(?(\d{1,2}|[ivx]+)\)?/g)].map(x=>[x[1],x[2]]);
 if(pr.length===m.L.length&&pr.every((p,i)=>p[0]===m.L[i].k))return pr;
 const tk=s.split(/[\s,;]+/).filter(Boolean);if(tk.length===m.L.length&&tk.every(x=>/^(\d{1,2}|[ivx]+)$/i.test(x)))return tk.map((x,i)=>[m.L[i].k,x]);return null}


function matchHTML(m){const c=(a,b)=>`<td>${a?'<b>'+esc(a.k)+'.</b>':''}</td><td>${a?esc(a.t):''}</td>`,sh=t=>t?`<small>${esc(t.replace(/^\(|\)$/g,''))}</small>`:'';let r='';
 for(let i=0;i<Math.max(m.L.length,m.R.length);i++)r+='<tr>'+c(m.L[i])+c(m.R[i])+'</tr>';
 return(m.intro?`<p class="prompt">${esc(m.intro)}</p>`:'')+`<div class="mtf"><table><thead><tr><th colspan="2">List I${sh(m.subL)}</th><th colspan="2">List II${sh(m.subR)}</th></tr></thead><tbody>${r}</tbody></table></div>`;}
const optMatch=(t,m)=>{const p=mapOpt(t,m);return p?p.map(x=>`<b>${esc(x[0])}</b>→${esc(x[1])}`).join('<i></i>'):null;};
document.addEventListener('click',e=>{const i=e.target.closest('.qimg,.oimg');if(!i)return;e.stopPropagation();e.preventDefault();let z=$('zoomB');if(!z){z=document.createElement('div');z.id='zoomB';z.innerHTML='<img alt="">';z.onclick=()=>z.hidden=true;document.body.append(z);}z.firstChild.src=i.src;z.hidden=false;},true);
/* ---------- storage health + error safety net ---------- */
(function(){let ok=true;try{localStorage.setItem('qm-probe','1');ok=localStorage.getItem('qm-probe')==='1';localStorage.removeItem('qm-probe');}catch(e){ok=false;}
 if(!ok){const w=$('warnBar');w.textContent='⚠ This browser is not letting the app save data (private mode or a restricted viewer). Progress will be lost when you close the page — open the file normally in Safari or Chrome.';w.hidden=false;}
 addEventListener('error',()=>toast('Something went wrong — your saved progress is safe. Reload if the page misbehaves.'));})();

/* boot */
const savedTheme=store.get('pq-theme');setTheme(savedTheme?savedTheme==='dark':matchMedia('(prefers-color-scheme:dark)').matches);
applyFont();setNavC(store.get('pq-navc')==='1');setRoomC(store.get('pq-roomc')==='1');
{const h=$('top'),set=()=>document.documentElement.style.setProperty('--topH',h.offsetHeight+'px');if(window.ResizeObserver)new ResizeObserver(set).observe(h);addEventListener('resize',set);set();}
new ResizeObserver(()=>document.documentElement.style.setProperty('--topH',$('top').offsetHeight+'px')).observe($('top'));
(async function boot(){
 const auth=QM.init(0).catch(()=>{});
 const params=new URLSearchParams(location.search);
 const browsing=location.pathname.endsWith('/builder.html')&&params.has('s')&&!params.has('retry')&&!params.has('custom')&&!localStorage.getItem('qm-room');
 if(!browsing)await QM.deadline(auth,8000);
 const linkedAtOpen=new URLSearchParams(location.search).get('join')?.trim().toUpperCase();
 const pointer=JSON.parse(localStorage.getItem('qm-room')||'null');
 const hostLookup=!browsing&&QM.user&&(linkedAtOpen||pointer?.role!=='g')?
  findHost(linkedAtOpen||null).catch(e=>{toast(e.message);return null;}):Promise.resolve(null);
 try{navigator.storage&&navigator.storage.persist&&navigator.storage.persist();}catch(e){}
 SUBJECTS.push({id:'polity',name:'Indian Polity & Governance',builtin:true,reflow:true,sourceHtml:POLITY_SRC},
  {id:'history',name:'Indian History',builtin:true,reflow:true,sourceHtml:'<b>Source:</b> Indian History — Complete Booklet (consolidated exam papers, printed pages B9–B760). Question text, options, answer key and explanations are extracted from the supplied booklet; questions with no printed answer key are not scored.'});
 for(const k of (QM.isAdmin?await kv.keys('subj:'):[])){const d=await kv.get(k);if(d&&d.questions)SUBJECTS.push({id:k.slice(5),name:d.title,builtin:false,data:d,sourceHtml:'<b>Source:</b> '+esc(d.source||'Imported subject')+'. Imported on this device.'});}
 const paperId=params.get('s');
 if(paperId?.startsWith('paper-')){const data=await QM.kvGet('cache:'+paperId);if(data)SUBJECTS.push({id:paperId,name:data.title,data});}
 const applyRows=rows=>{for(const r of rows){const i=SUBJECTS.findIndex(s=>s.id===r.id);if(r.status!=='live'){if(i>=0)SUBJECTS.splice(i,1);continue}if(r.status!=='live'||!r.path)continue;const o={id:r.id,name:r.name,builtin:false,cloud:r,sourceHtml:'<b>Source:</b> '+esc(r.subtitle||r.name)};if(i>=0)SUBJECTS[i]=o;else SUBJECTS.push(o)}};
 // Resolve the current published version before choosing the question bank.
 // QM.subjects() falls back to the stored catalog when the network is unavailable.
 let catalogSignature='';
 const cache=await QM.kvGet('cache:subjects')||[];
 const cachedSubject=cache.some(r=>r.id===params.get('s'))||['polity','history'].includes(params.get('s'));
 const rows=browsing&&cachedSubject?cache:await QM.subjects();
 applyRows(rows);catalogSignature=JSON.stringify(rows);
 let checking=false;
 async function refreshCatalog(){
  const idle=()=>DATA&&!L()&&!roomOpening&&document.body.dataset.stage==='setup'&&$('mockBackdrop').hidden&&!$('routeDialog').open;
  if(checking||!idle())return;
  checking=true;
  try{const rows=await QM.subjects();if(idle()&&JSON.stringify(rows)!==catalogSignature)location.reload();}
  finally{checking=false;}
 }
 async function refreshShelfRecords(){
  const subject=SUBJ;
  if(!subject||document.body.dataset.stage!=='setup')return;
  const [saved,history]=await Promise.all([kv.get('qs:'+subject.id),kv.get('sessions')]);
  if(SUBJ!==subject||document.body.dataset.stage!=='setup')return;
  for(const [id,value] of Object.entries(saved||{})){
   if(!QS[id]||(value.t||0)>(QS[id].t||0))QS[id]=value;
  }
  const merged=new Map(SESS.map(r=>[r.id,r]));
  for(const r of history||[])if(!merged.has(r.id)||(r.en||0)>(merged.get(r.id).en||0))merged.set(r.id,r);
  SESS=[...merged.values()];drawChapterShelf();refreshViewCounts();
 }
 QM.listen(event=>{
  if(event==='resume')refreshCatalog();
  if(event==='pulled')refreshShelfRecords().catch(()=>{});
 });
 addEventListener('online',refreshCatalog);

 SESS=(await kv.get('sessions'))||[];DAILY=(await kv.get('daily'))||{};Object.assign(PREFS,(await kv.get('prefs'))||{});
 if(browsing){const key=params.get('s')==='polity'?'pq-state-v2':'qm-state:'+params.get('s');
  let saved;try{saved=JSON.parse(store.get(key)||'null')}catch{}
  if(saved?.x?.id&&!saved.s)await QM.deadline(auth,8000);
 }
 const qp=new URLSearchParams(location.search),localHost=await hostLookup,last=localHost?.cfg?.subj||qp.get('s')||store.get(LS_LAST);await openSubject(SUBJECTS.some(s=>s.id===last)?last:(SUBJECTS[0]||{}).id,true);buildSubjectSelect();
 const linkedCode=(qp.get('join')||'').trim().toUpperCase();
 let savedRoom;
 try{savedRoom=JSON.parse(localStorage.getItem('qm-room')||'null');}catch(e){}
 const resume=savedRoom&&Date.now()-savedRoom.t<36*3600000&&(!linkedCode||linkedCode===savedRoom.code);
 if(qp.get('add')){if(QM.isAdmin)openAdd();else toast('Only admins can add subjects.');}
 let recovering=null;
 if(QM.user&&(!resume||savedRoom.role==='h'||linkedCode)){
  recovering=localHost;
 }
 if(recovering){toast('Restoring room '+recovering.code+'…');await hostRestore(recovering);}
 else if(QM.user&&resume&&savedRoom.role==='g'&&savedRoom.name){
  toast('Rejoining room '+savedRoom.code+'…');rejoin(savedRoom);
 }else{
  clearLiveAttempt();
  if(linkedCode){who='join';openCustom();$('mkCode').value=linkedCode;}
  else if(qp.get('retry')){
   const record=SESS.find(r=>r.id===qp.get('retry')&&r.subj===SUBJ.id);
   const url=new URL(location.href);url.searchParams.delete('retry');history.replaceState(history.state,'',url);
   if(record)await retryFromRec(record);else toast('This attempt is unavailable on this device.');
  }else if(qp.get('custom'))chooseRoute();
 }
 if(browsing)await refreshShelfRecords();
 if(params.get('study')==='priority'&&document.body.dataset.stage==='setup')await openStudy('Exam priorities');
 if(browsing&&cachedSubject)auth.then(()=>refreshCatalog()).catch(()=>{});
 if('serviceWorker' in navigator)navigator.serviceWorker.register('sw.js').catch(()=>{});
})().catch(()=>{
 document.body.dataset.stage='setup';
 $('poolCount').textContent='Could not finish loading your questions or saved progress.';
 $('startPortal').disabled=true;$('portalRetry').hidden=false;
});
$('portalRetry').onclick=()=>location.reload();

/* ===== v2 UI behaviour: filter sheet, responsive placement, swipe, filter badge ===== */
(function(){
 const open=v=>document.body.classList.toggle('fopen',v);
 $('fToggle').addEventListener('click',()=>open(!document.body.classList.contains('fopen')));
 $('fDone').addEventListener('click',()=>open(false));$('fScrim').addEventListener('click',()=>open(false));
 addEventListener('keydown',e=>{if(e.key==='Escape')open(false);});
 window.updateFCount=function(){let n=[groupFilter,examFilter,yearFilter,viewFilter].filter(s=>s.value!=='all').length+(search?1:0)+(retryIds?1:0);const c=$('fCount');c.textContent=n;c.hidden=!n;};
 const af=applyFilters;applyFilters=function(){af();updateFCount();refreshViewCounts();};
 $('fClear').addEventListener('click',()=>{chosenChapters.clear();groupFilter.value='all';fillChapters();[examFilter,yearFilter,viewFilter].forEach(s=>s.value='all');search='';$('searchBox').value='';userFilter();});
 /* swipe left / right to move between questions */
 let x0=null,y0=0,t0=0;const c=$('questionCard');
 c.addEventListener('touchstart',e=>{const t=e.touches[0];x0=t.clientX;y0=t.clientY;t0=Date.now();},{passive:true});
 c.addEventListener('touchend',e=>{if(x0==null)return;const t=e.changedTouches[0],dx=t.clientX-x0,dy=t.clientY-y0;x0=null;if(Math.abs(dx)>90&&Math.abs(dy)<45&&Date.now()-t0<600&&!paused&&tab==='quiz')go(current+(dx<0?1:-1));},{passive:true});
})();

document.addEventListener('click',async e=>{if(!e.target.closest('#copyCode'))return;try{await navigator.clipboard.writeText($('copyCode').textContent);toast('Room code copied');}catch{toast('Room code: '+$('copyCode').textContent);}});
function topPortalDialog(){
 const open=[...document.querySelectorAll('.backdrop:not([hidden])')];
 return open.sort((a,b)=>(parseInt(getComputedStyle(b).zIndex)||0)-(parseInt(getComputedStyle(a).zIndex)||0))[0];
}
(function manageDialogFocus(){
 let trigger=null,layer=null;
 document.addEventListener('click',e=>{if(!topPortalDialog())trigger=e.target.closest('button,a,summary');},true);
 function controls(el){return [...el.querySelectorAll('button:not(:disabled),a[href],input:not(:disabled),select:not(:disabled),textarea:not(:disabled),summary')].filter(n=>n.getClientRects().length);}
 function changed(){
  const next=topPortalDialog();
  if(next===layer)return;
  layer=next;
  if(next&&!next.contains(document.activeElement))controls(next)[0]?.focus();
  if(!next&&trigger?.isConnected&&trigger.getClientRects().length)trigger.focus({preventScroll:true});
 }
 const watcher=new MutationObserver(changed);
 for(const panel of document.querySelectorAll('.backdrop'))watcher.observe(panel,{attributes:true,attributeFilter:['hidden']});
 document.addEventListener('keydown',e=>{
  if(e.key!=='Tab'||document.querySelector('dialog[open]'))return;
  const panel=topPortalDialog();if(!panel)return;
  const list=controls(panel),first=list[0],last=list.at(-1);
  if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}
  if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}
 });
})();
